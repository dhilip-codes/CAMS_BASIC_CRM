using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using SamplePortalClient;
//using OpenQA.Selenium.Chrome;
//using OpenQA.Selenium;
using System.Data;
using System.Data.SqlClient;

namespace CallPopup
{
    /// <summary>
    /// Summary description for FToolbar.
    /// </summary>

    public class FToolbar : System.Windows.Forms.Form
    {
        // chat variable
        public static Boolean chat;
        public static Boolean Rechat;

        private System.Windows.Forms.Button btnHangup;
        private System.Windows.Forms.Button btnDial;
        private System.Windows.Forms.Button btnHold;
        private System.Windows.Forms.Button btn3Way;
        private System.Windows.Forms.Button btnRecord;
        private System.Windows.Forms.Button btnNextCall;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnReady;
        private System.Windows.Forms.Button btnAvailable;
        private SamplePortalClient.CApp mpApp;
        private System.Windows.Forms.Label lblMessage;
        private System.Threading.Timer mpMessageTimer;
        private Button btnUnavailable;
        private Label lblPhoneStatus;
        private Panel pnlState;
        private Label lblState;
        private ToolTip lblPhoneStatusToolTip;
        private IContainer components;
        private System.Threading.Timer mpUnloadTimer;
        private System.Threading.Timer mpPendingErrorTimer;
        private Hashtable moCallWindows;
        internal Label lblBottomBar;

        //private FCallData mCallDataForm;
        //public IWebDriver driver;
        int idleCnt = 0;

        public static string CustID = "";
        public static string CustPhoneNo = "";
        private Panel panel3;
        private TabControl tcCallDetails;
        private TabPage tpCDD;
        private TabPage tpPopup;
        private Label lblUDF2;
        private Label lblUDF1;
        private Label lblUDF10;
        private Label lblUDF9;
        private Label lblUDF8;
        private Label lblUDF7;
        private Label lblUDF6;
        private Label lblUDF5;
        private Label lblUDF4;
        private Label lblUDF3;
        private Label lblSep2;
        private TextBox txtUDF1;
        private TextBox txtUDF10;
        private TextBox txtUDF9;
        private TextBox txtUDF8;
        private TextBox txtUDF7;
        private TextBox txtUDF6;
        private TextBox txtUDF5;
        private TextBox txtUDF4;
        private TextBox txtUDF3;
        private TextBox txtUDF2;
        private Label lblUDF11;
        private Label lblUDF13;
        private Label lblUDF12;
        private Label lblUDF20;
        private Label lblUDF19;
        private Label lblUDF18;
        private Label lblUDF17;
        private Label lblUDF16;
        private Label lblUDF15;
        private Label lblUDF14;
        private TextBox txtUDF11;
        private TextBox txtUDF20;
        private TextBox txtUDF19;
        private TextBox txtUDF18;
        private TextBox txtUDF17;
        private TextBox txtUDF16;
        private TextBox txtUDF15;
        private TextBox txtUDF14;
        private TextBox txtUDF13;
        private TextBox txtUDF12;
        private Label lblSep3;
        private Label lblSep1;
        private Label lblAgent;
        private TextBox txtAgentName;
        private TextBox txtAgentID;
        private Label label49;
        private Label label50;
        private Label lblService;
        private TextBox txtServiceID;
        private TextBox txtServiceName;
        private Label label4;
        private TextBox txtDNIS;
        private Label lblDisposition;
        private ComboBox cmbDispDesc;
        private Button btnDispose;
        public static string CustEmail = "";

        //Code added by AMD on 29th June 2017
        public String callStartDtAssigned = "F";
        public DateTime callStartDt = DateTime.Now;
        private Button btnSearch;
        private DateTimePicker dtpCbkDtTm;
        private ComboBox cmbDisp;
        private Panel pnlCallback;
        private CheckBox cbSelfCbk;
        public DateTime callEndDt;
        private Timer tmrPreview;
        private String logContent = "";
        private Label lblAltCbkNo;
        private TextBox txtAltPhoneNo;
        private int previewCnt;
        private Timer tmrAutoDisp;
        public string INBCallType;
        public string AutoEmail;
        public string AutoSMS;
        private Timer tmrAssignedServices;
        private int WrapDur = 0;
        private Timer tmrCallDuration;
        private int CallDuration = 0;
        private Panel pnlPopup;
        private TextBox txtIFSCCode;
        private Label lblIFSC;
        private Label lblBrokerCode;
        private TextBox txtbrokercode;
        private TextBox txtemail;
        private Label lblemail;
        private Label lblphoneres;
        private TextBox txtphoneres;
        private TextBox txtmobileno;
        private Label lblmobile;
        private TextBox txtPanNumber;
        private Label lblPAN;
        private Label label1;
        private TextBox txtPhoneNumber;
        private Label label3;
        private TextBox txtguardian;
        private Label lblguardian;
        private TextBox txtpincode;
        private Label lblpincode;
        private TextBox txtcallremarks;
        private Label lblcallremark;
        private TextBox txtsipday;
        private Label lblSIPDay;
        private TextBox txtSIPAmount;
        private Label lblSIPAmount;
        private TextBox txtscheme;
        private Label lblschemename;
        private TextBox txtcity;
        private Label lblcity;
        private TextBox txtstate;
        private Label lblstatename;
        private Panel pnlInbound;
        private ComboBox cmbCurrentStatus;
        private Label lblCurrentStatus;
        private ComboBox cmbLanguage;
        private ComboBox cmbCallerType;
        private Label lblLanguage;
        private Label lblCallerType;
        private ComboBox cmbCallCategory;
        private Label lblCallCategory;
        private ComboBox cmbQuery;
        private Label lblQuery;
        private RadioButton rdoBrokerCode;
        private RadioButton rdoFolio;
        private Label lblType;
        private Label label7;
        private Label label8;
        private TextBox txtbranchname;
        private Label lblbranchname;
        private Label lblbankname;
        private TextBox txtbankname;
        private Label lblaccountnum;
        private TextBox txtaccountnum;
        private Label lblAmount;
        private TextBox txtAmount;
        private Label lblaccounttype;
        private TextBox txtaccounttype;
        private TextBox txtRemarks;
        private Label lblCallComments;
        private Label lbCallHistory;
        private TextBox txtstatus;
        private Label lbltax;
        private Label lblSep7;
        private Label lblSep6;
        private Label lblSep5;
        private Label lblSep4;
        private TextBox txtInvestorName;
        private Label lblInvestorName;
        private TextBox txtFolioNumber;
        private Label lblFolioNumber;
        private TextBox txtSrNo;
        private Label lblSrNo;
        private Label lblCustInfo;
        private Label lblCallDuration;
        private ComboBox cmbSuggestion;
        private Label lblSuggestion;
        private TabControl tabControl1;
        private TabPage tpCallHist_Cust;
        private DataGridView dgvCallHistory;
        private DataGridViewTextBoxColumn CallDate;
        private DataGridViewTextBoxColumn PhoneNo;
        private DataGridViewTextBoxColumn Agent;
        private DataGridViewTextBoxColumn CallDur;
        private DataGridViewTextBoxColumn Disp;
        private DataGridViewTextBoxColumn Remarks;
        private TabPage tpCallHist_Agent;
        private DataGridView dgvAgentCallHist;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;

        //End

        private const int CP_NOCLOSE_BUTTON = 0x200;
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams myCp = base.CreateParams;
                myCp.ClassStyle = myCp.ClassStyle | CP_NOCLOSE_BUTTON;
                return myCp;
            }
        }
        public FToolbar(CApp pApp)
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            mpApp = pApp;

            moCallWindows = new Hashtable();
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnHangup = new System.Windows.Forms.Button();
            this.btnDial = new System.Windows.Forms.Button();
            this.btnHold = new System.Windows.Forms.Button();
            this.btn3Way = new System.Windows.Forms.Button();
            this.btnRecord = new System.Windows.Forms.Button();
            this.btnNextCall = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnReady = new System.Windows.Forms.Button();
            this.lblMessage = new System.Windows.Forms.Label();
            this.btnAvailable = new System.Windows.Forms.Button();
            this.btnUnavailable = new System.Windows.Forms.Button();
            this.lblPhoneStatus = new System.Windows.Forms.Label();
            this.pnlState = new System.Windows.Forms.Panel();
            this.lblState = new System.Windows.Forms.Label();
            this.lblPhoneStatusToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.dtpCbkDtTm = new System.Windows.Forms.DateTimePicker();
            this.lblBottomBar = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnSearch = new System.Windows.Forms.Button();
            this.tcCallDetails = new System.Windows.Forms.TabControl();
            this.tpCDD = new System.Windows.Forms.TabPage();
            this.txtDNIS = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtServiceName = new System.Windows.Forms.TextBox();
            this.txtServiceID = new System.Windows.Forms.TextBox();
            this.lblService = new System.Windows.Forms.Label();
            this.txtAgentName = new System.Windows.Forms.TextBox();
            this.txtAgentID = new System.Windows.Forms.TextBox();
            this.lblAgent = new System.Windows.Forms.Label();
            this.lblSep1 = new System.Windows.Forms.Label();
            this.lblSep3 = new System.Windows.Forms.Label();
            this.txtUDF20 = new System.Windows.Forms.TextBox();
            this.txtUDF19 = new System.Windows.Forms.TextBox();
            this.txtUDF18 = new System.Windows.Forms.TextBox();
            this.txtUDF17 = new System.Windows.Forms.TextBox();
            this.txtUDF16 = new System.Windows.Forms.TextBox();
            this.txtUDF15 = new System.Windows.Forms.TextBox();
            this.txtUDF14 = new System.Windows.Forms.TextBox();
            this.txtUDF13 = new System.Windows.Forms.TextBox();
            this.txtUDF12 = new System.Windows.Forms.TextBox();
            this.txtUDF11 = new System.Windows.Forms.TextBox();
            this.lblUDF20 = new System.Windows.Forms.Label();
            this.lblUDF19 = new System.Windows.Forms.Label();
            this.lblUDF18 = new System.Windows.Forms.Label();
            this.lblUDF17 = new System.Windows.Forms.Label();
            this.lblUDF16 = new System.Windows.Forms.Label();
            this.lblUDF15 = new System.Windows.Forms.Label();
            this.lblUDF14 = new System.Windows.Forms.Label();
            this.lblUDF13 = new System.Windows.Forms.Label();
            this.lblUDF12 = new System.Windows.Forms.Label();
            this.lblUDF11 = new System.Windows.Forms.Label();
            this.txtUDF10 = new System.Windows.Forms.TextBox();
            this.txtUDF9 = new System.Windows.Forms.TextBox();
            this.txtUDF8 = new System.Windows.Forms.TextBox();
            this.txtUDF7 = new System.Windows.Forms.TextBox();
            this.txtUDF6 = new System.Windows.Forms.TextBox();
            this.txtUDF5 = new System.Windows.Forms.TextBox();
            this.txtUDF4 = new System.Windows.Forms.TextBox();
            this.txtUDF3 = new System.Windows.Forms.TextBox();
            this.txtUDF2 = new System.Windows.Forms.TextBox();
            this.txtUDF1 = new System.Windows.Forms.TextBox();
            this.lblSep2 = new System.Windows.Forms.Label();
            this.lblUDF10 = new System.Windows.Forms.Label();
            this.lblUDF9 = new System.Windows.Forms.Label();
            this.lblUDF8 = new System.Windows.Forms.Label();
            this.lblUDF7 = new System.Windows.Forms.Label();
            this.lblUDF6 = new System.Windows.Forms.Label();
            this.lblUDF5 = new System.Windows.Forms.Label();
            this.lblUDF4 = new System.Windows.Forms.Label();
            this.lblUDF3 = new System.Windows.Forms.Label();
            this.lblUDF2 = new System.Windows.Forms.Label();
            this.lblUDF1 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.tpPopup = new System.Windows.Forms.TabPage();
            this.btnDispose = new System.Windows.Forms.Button();
            this.cmbDispDesc = new System.Windows.Forms.ComboBox();
            this.lblDisposition = new System.Windows.Forms.Label();
            this.cmbDisp = new System.Windows.Forms.ComboBox();
            this.pnlCallback = new System.Windows.Forms.Panel();
            this.lblAltCbkNo = new System.Windows.Forms.Label();
            this.txtAltPhoneNo = new System.Windows.Forms.TextBox();
            this.cbSelfCbk = new System.Windows.Forms.CheckBox();
            this.tmrPreview = new System.Windows.Forms.Timer(this.components);
            this.tmrAutoDisp = new System.Windows.Forms.Timer(this.components);
            this.tmrAssignedServices = new System.Windows.Forms.Timer(this.components);
            this.tmrCallDuration = new System.Windows.Forms.Timer(this.components);
            this.lblCustInfo = new System.Windows.Forms.Label();
            this.lblSrNo = new System.Windows.Forms.Label();
            this.txtSrNo = new System.Windows.Forms.TextBox();
            this.lblFolioNumber = new System.Windows.Forms.Label();
            this.txtFolioNumber = new System.Windows.Forms.TextBox();
            this.lblInvestorName = new System.Windows.Forms.Label();
            this.txtInvestorName = new System.Windows.Forms.TextBox();
            this.lblSep4 = new System.Windows.Forms.Label();
            this.lblSep5 = new System.Windows.Forms.Label();
            this.lblSep6 = new System.Windows.Forms.Label();
            this.lblSep7 = new System.Windows.Forms.Label();
            this.lbltax = new System.Windows.Forms.Label();
            this.txtstatus = new System.Windows.Forms.TextBox();
            this.lbCallHistory = new System.Windows.Forms.Label();
            this.lblCallComments = new System.Windows.Forms.Label();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.txtaccounttype = new System.Windows.Forms.TextBox();
            this.lblaccounttype = new System.Windows.Forms.Label();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.lblAmount = new System.Windows.Forms.Label();
            this.txtaccountnum = new System.Windows.Forms.TextBox();
            this.lblaccountnum = new System.Windows.Forms.Label();
            this.txtbankname = new System.Windows.Forms.TextBox();
            this.lblbankname = new System.Windows.Forms.Label();
            this.lblbranchname = new System.Windows.Forms.Label();
            this.txtbranchname = new System.Windows.Forms.TextBox();
            this.pnlInbound = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblType = new System.Windows.Forms.Label();
            this.rdoFolio = new System.Windows.Forms.RadioButton();
            this.rdoBrokerCode = new System.Windows.Forms.RadioButton();
            this.lblQuery = new System.Windows.Forms.Label();
            this.cmbQuery = new System.Windows.Forms.ComboBox();
            this.lblCallCategory = new System.Windows.Forms.Label();
            this.cmbCallCategory = new System.Windows.Forms.ComboBox();
            this.lblCallerType = new System.Windows.Forms.Label();
            this.lblLanguage = new System.Windows.Forms.Label();
            this.cmbCallerType = new System.Windows.Forms.ComboBox();
            this.cmbLanguage = new System.Windows.Forms.ComboBox();
            this.lblCurrentStatus = new System.Windows.Forms.Label();
            this.cmbCurrentStatus = new System.Windows.Forms.ComboBox();
            this.lblstatename = new System.Windows.Forms.Label();
            this.txtstate = new System.Windows.Forms.TextBox();
            this.lblcity = new System.Windows.Forms.Label();
            this.txtcity = new System.Windows.Forms.TextBox();
            this.lblschemename = new System.Windows.Forms.Label();
            this.txtscheme = new System.Windows.Forms.TextBox();
            this.lblSIPAmount = new System.Windows.Forms.Label();
            this.txtSIPAmount = new System.Windows.Forms.TextBox();
            this.lblSIPDay = new System.Windows.Forms.Label();
            this.txtsipday = new System.Windows.Forms.TextBox();
            this.lblcallremark = new System.Windows.Forms.Label();
            this.txtcallremarks = new System.Windows.Forms.TextBox();
            this.lblpincode = new System.Windows.Forms.Label();
            this.txtpincode = new System.Windows.Forms.TextBox();
            this.lblguardian = new System.Windows.Forms.Label();
            this.txtguardian = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPhoneNumber = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblPAN = new System.Windows.Forms.Label();
            this.txtPanNumber = new System.Windows.Forms.TextBox();
            this.lblmobile = new System.Windows.Forms.Label();
            this.txtmobileno = new System.Windows.Forms.TextBox();
            this.txtphoneres = new System.Windows.Forms.TextBox();
            this.lblphoneres = new System.Windows.Forms.Label();
            this.lblemail = new System.Windows.Forms.Label();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.txtbrokercode = new System.Windows.Forms.TextBox();
            this.lblBrokerCode = new System.Windows.Forms.Label();
            this.lblIFSC = new System.Windows.Forms.Label();
            this.txtIFSCCode = new System.Windows.Forms.TextBox();
            this.pnlPopup = new System.Windows.Forms.Panel();
            this.lblCallDuration = new System.Windows.Forms.Label();
            this.cmbSuggestion = new System.Windows.Forms.ComboBox();
            this.lblSuggestion = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tpCallHist_Cust = new System.Windows.Forms.TabPage();
            this.dgvCallHistory = new System.Windows.Forms.DataGridView();
            this.CallDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PhoneNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Agent = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CallDur = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Disp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Remarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tpCallHist_Agent = new System.Windows.Forms.TabPage();
            this.dgvAgentCallHist = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnlState.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tcCallDetails.SuspendLayout();
            this.tpCDD.SuspendLayout();
            this.tpPopup.SuspendLayout();
            this.pnlCallback.SuspendLayout();
            this.pnlInbound.SuspendLayout();
            this.pnlPopup.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tpCallHist_Cust.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCallHistory)).BeginInit();
            this.tpCallHist_Agent.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAgentCallHist)).BeginInit();
            this.SuspendLayout();
            // 
            // btnHangup
            // 
            this.btnHangup.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnHangup.Font = new System.Drawing.Font("Arial", 8.25F);
            this.btnHangup.Location = new System.Drawing.Point(10, 8);
            this.btnHangup.Name = "btnHangup";
            this.btnHangup.Size = new System.Drawing.Size(61, 28);
            this.btnHangup.TabIndex = 1;
            this.btnHangup.Text = "Hangup";
            this.btnHangup.UseVisualStyleBackColor = false;
            this.btnHangup.Click += new System.EventHandler(this.btnHangup_Click);
            // 
            // btnDial
            // 
            this.btnDial.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnDial.Font = new System.Drawing.Font("Arial", 8.25F);
            this.btnDial.Location = new System.Drawing.Point(77, 8);
            this.btnDial.Name = "btnDial";
            this.btnDial.Size = new System.Drawing.Size(61, 28);
            this.btnDial.TabIndex = 2;
            this.btnDial.Text = "Dial";
            this.btnDial.UseVisualStyleBackColor = false;
            this.btnDial.Click += new System.EventHandler(this.btnDial_Click);
            // 
            // btnHold
            // 
            this.btnHold.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnHold.Font = new System.Drawing.Font("Arial", 8.25F);
            this.btnHold.Location = new System.Drawing.Point(144, 8);
            this.btnHold.Name = "btnHold";
            this.btnHold.Size = new System.Drawing.Size(60, 28);
            this.btnHold.TabIndex = 3;
            this.btnHold.Text = "Hold";
            this.btnHold.UseVisualStyleBackColor = false;
            this.btnHold.Click += new System.EventHandler(this.btnHold_Click);
            // 
            // btn3Way
            // 
            this.btn3Way.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btn3Way.Font = new System.Drawing.Font("Arial", 8.25F);
            this.btn3Way.Location = new System.Drawing.Point(210, 8);
            this.btn3Way.Name = "btn3Way";
            this.btn3Way.Size = new System.Drawing.Size(61, 28);
            this.btn3Way.TabIndex = 4;
            this.btn3Way.Text = "3Way";
            this.btn3Way.UseVisualStyleBackColor = false;
            this.btn3Way.Click += new System.EventHandler(this.btn3Way_Click);
            // 
            // btnRecord
            // 
            this.btnRecord.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnRecord.Font = new System.Drawing.Font("Arial", 8.25F);
            this.btnRecord.Location = new System.Drawing.Point(277, 8);
            this.btnRecord.Name = "btnRecord";
            this.btnRecord.Size = new System.Drawing.Size(61, 28);
            this.btnRecord.TabIndex = 5;
            this.btnRecord.Text = "Record";
            this.btnRecord.UseVisualStyleBackColor = false;
            // 
            // btnNextCall
            // 
            this.btnNextCall.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnNextCall.Font = new System.Drawing.Font("Arial", 8.25F);
            this.btnNextCall.Location = new System.Drawing.Point(907, 7);
            this.btnNextCall.Name = "btnNextCall";
            this.btnNextCall.Size = new System.Drawing.Size(61, 28);
            this.btnNextCall.TabIndex = 10;
            this.btnNextCall.Text = "Next Call";
            this.btnNextCall.UseVisualStyleBackColor = false;
            this.btnNextCall.Visible = false;
            this.btnNextCall.Click += new System.EventHandler(this.btnNextCall_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnLogout.Font = new System.Drawing.Font("Arial", 8.25F);
            this.btnLogout.Location = new System.Drawing.Point(429, 8);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(61, 28);
            this.btnLogout.TabIndex = 7;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // btnReady
            // 
            this.btnReady.AccessibleName = "";
            this.btnReady.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnReady.Font = new System.Drawing.Font("Arial", 8.25F);
            this.btnReady.Location = new System.Drawing.Point(974, 8);
            this.btnReady.Name = "btnReady";
            this.btnReady.Size = new System.Drawing.Size(59, 28);
            this.btnReady.TabIndex = 11;
            this.btnReady.Text = "Ready";
            this.btnReady.UseVisualStyleBackColor = false;
            this.btnReady.Click += new System.EventHandler(this.btnReady_Click);
            // 
            // lblMessage
            // 
            this.lblMessage.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblMessage.Location = new System.Drawing.Point(506, 8);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(527, 28);
            this.lblMessage.TabIndex = 8;
            this.lblMessage.Text = "label1";
            this.lblMessage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnAvailable
            // 
            this.btnAvailable.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnAvailable.Location = new System.Drawing.Point(346, 8);
            this.btnAvailable.Name = "btnAvailable";
            this.btnAvailable.Size = new System.Drawing.Size(77, 28);
            this.btnAvailable.TabIndex = 14;
            this.btnAvailable.Text = "Ready";
            this.btnAvailable.UseVisualStyleBackColor = false;
            this.btnAvailable.Click += new System.EventHandler(this.btnAvailable_Click);
            // 
            // btnUnavailable
            // 
            this.btnUnavailable.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnUnavailable.Font = new System.Drawing.Font("Arial", 8.25F);
            this.btnUnavailable.Location = new System.Drawing.Point(346, 8);
            this.btnUnavailable.Name = "btnUnavailable";
            this.btnUnavailable.Size = new System.Drawing.Size(77, 28);
            this.btnUnavailable.TabIndex = 6;
            this.btnUnavailable.Text = "Not Ready";
            this.btnUnavailable.UseVisualStyleBackColor = false;
            this.btnUnavailable.Click += new System.EventHandler(this.btnUnavailable_Click);
            // 
            // lblPhoneStatus
            // 
            this.lblPhoneStatus.BackColor = System.Drawing.Color.Red;
            this.lblPhoneStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPhoneStatus.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblPhoneStatus.Location = new System.Drawing.Point(0, 1);
            this.lblPhoneStatus.Name = "lblPhoneStatus";
            this.lblPhoneStatus.Size = new System.Drawing.Size(22, 29);
            this.lblPhoneStatus.TabIndex = 13;
            // 
            // pnlState
            // 
            this.pnlState.Controls.Add(this.lblState);
            this.pnlState.Controls.Add(this.lblPhoneStatus);
            this.pnlState.Location = new System.Drawing.Point(1039, 7);
            this.pnlState.Name = "pnlState";
            this.pnlState.Size = new System.Drawing.Size(145, 31);
            this.pnlState.TabIndex = 12;
            // 
            // lblState
            // 
            this.lblState.BackColor = System.Drawing.SystemColors.Control;
            this.lblState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblState.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.lblState.Location = new System.Drawing.Point(16, 1);
            this.lblState.Name = "lblState";
            this.lblState.Size = new System.Drawing.Size(129, 29);
            this.lblState.TabIndex = 14;
            this.lblState.Text = "Logging In";
            this.lblState.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dtpCbkDtTm
            // 
            this.dtpCbkDtTm.CalendarFont = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpCbkDtTm.CalendarMonthBackground = System.Drawing.SystemColors.Desktop;
            this.dtpCbkDtTm.CalendarTitleForeColor = System.Drawing.SystemColors.ControlText;
            this.dtpCbkDtTm.CustomFormat = "dd - MMM - yyyy HH : mm";
            this.dtpCbkDtTm.Font = new System.Drawing.Font("Arial", 8.25F);
            this.dtpCbkDtTm.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpCbkDtTm.Location = new System.Drawing.Point(2, 1);
            this.dtpCbkDtTm.Name = "dtpCbkDtTm";
            this.dtpCbkDtTm.Size = new System.Drawing.Size(135, 20);
            this.dtpCbkDtTm.TabIndex = 152;
            this.lblPhoneStatusToolTip.SetToolTip(this.dtpCbkDtTm, "Select Callback Date");
            this.dtpCbkDtTm.Value = new System.DateTime(2017, 6, 28, 17, 51, 48, 0);
            // 
            // lblBottomBar
            // 
            this.lblBottomBar.BackColor = System.Drawing.Color.DarkGray;
            this.lblBottomBar.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblBottomBar.ForeColor = System.Drawing.Color.Black;
            this.lblBottomBar.Location = new System.Drawing.Point(0, 704);
            this.lblBottomBar.Name = "lblBottomBar";
            this.lblBottomBar.Size = new System.Drawing.Size(1196, 20);
            this.lblBottomBar.TabIndex = 174;
            this.lblBottomBar.Text = " Designed By : CS Infocomm Pvt Ltd";
            this.lblBottomBar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkGray;
            this.panel3.Controls.Add(this.btnReady);
            this.panel3.Controls.Add(this.btnSearch);
            this.panel3.Controls.Add(this.btnHangup);
            this.panel3.Controls.Add(this.btnDial);
            this.panel3.Controls.Add(this.btnHold);
            this.panel3.Controls.Add(this.btn3Way);
            this.panel3.Controls.Add(this.pnlState);
            this.panel3.Controls.Add(this.btnRecord);
            this.panel3.Controls.Add(this.btnUnavailable);
            this.panel3.Controls.Add(this.btnNextCall);
            this.panel3.Controls.Add(this.btnAvailable);
            this.panel3.Controls.Add(this.btnLogout);
            this.panel3.Controls.Add(this.lblMessage);
            this.panel3.Location = new System.Drawing.Point(0, -1);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1196, 44);
            this.panel3.TabIndex = 0;
            // 
            // btnSearch
            // 
            this.btnSearch.AccessibleName = "";
            this.btnSearch.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnSearch.Font = new System.Drawing.Font("Arial", 8.25F);
            this.btnSearch.Location = new System.Drawing.Point(842, 7);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(59, 28);
            this.btnSearch.TabIndex = 9;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Visible = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // tcCallDetails
            // 
            this.tcCallDetails.Controls.Add(this.tpCDD);
            this.tcCallDetails.Controls.Add(this.tpPopup);
            this.tcCallDetails.Location = new System.Drawing.Point(0, 45);
            this.tcCallDetails.Name = "tcCallDetails";
            this.tcCallDetails.SelectedIndex = 0;
            this.tcCallDetails.Size = new System.Drawing.Size(1196, 621);
            this.tcCallDetails.TabIndex = 15;
            // 
            // tpCDD
            // 
            this.tpCDD.Controls.Add(this.txtDNIS);
            this.tpCDD.Controls.Add(this.label4);
            this.tpCDD.Controls.Add(this.txtServiceName);
            this.tpCDD.Controls.Add(this.txtServiceID);
            this.tpCDD.Controls.Add(this.lblService);
            this.tpCDD.Controls.Add(this.txtAgentName);
            this.tpCDD.Controls.Add(this.txtAgentID);
            this.tpCDD.Controls.Add(this.lblAgent);
            this.tpCDD.Controls.Add(this.lblSep1);
            this.tpCDD.Controls.Add(this.lblSep3);
            this.tpCDD.Controls.Add(this.txtUDF20);
            this.tpCDD.Controls.Add(this.txtUDF19);
            this.tpCDD.Controls.Add(this.txtUDF18);
            this.tpCDD.Controls.Add(this.txtUDF17);
            this.tpCDD.Controls.Add(this.txtUDF16);
            this.tpCDD.Controls.Add(this.txtUDF15);
            this.tpCDD.Controls.Add(this.txtUDF14);
            this.tpCDD.Controls.Add(this.txtUDF13);
            this.tpCDD.Controls.Add(this.txtUDF12);
            this.tpCDD.Controls.Add(this.txtUDF11);
            this.tpCDD.Controls.Add(this.lblUDF20);
            this.tpCDD.Controls.Add(this.lblUDF19);
            this.tpCDD.Controls.Add(this.lblUDF18);
            this.tpCDD.Controls.Add(this.lblUDF17);
            this.tpCDD.Controls.Add(this.lblUDF16);
            this.tpCDD.Controls.Add(this.lblUDF15);
            this.tpCDD.Controls.Add(this.lblUDF14);
            this.tpCDD.Controls.Add(this.lblUDF13);
            this.tpCDD.Controls.Add(this.lblUDF12);
            this.tpCDD.Controls.Add(this.lblUDF11);
            this.tpCDD.Controls.Add(this.txtUDF10);
            this.tpCDD.Controls.Add(this.txtUDF9);
            this.tpCDD.Controls.Add(this.txtUDF8);
            this.tpCDD.Controls.Add(this.txtUDF7);
            this.tpCDD.Controls.Add(this.txtUDF6);
            this.tpCDD.Controls.Add(this.txtUDF5);
            this.tpCDD.Controls.Add(this.txtUDF4);
            this.tpCDD.Controls.Add(this.txtUDF3);
            this.tpCDD.Controls.Add(this.txtUDF2);
            this.tpCDD.Controls.Add(this.txtUDF1);
            this.tpCDD.Controls.Add(this.lblSep2);
            this.tpCDD.Controls.Add(this.lblUDF10);
            this.tpCDD.Controls.Add(this.lblUDF9);
            this.tpCDD.Controls.Add(this.lblUDF8);
            this.tpCDD.Controls.Add(this.lblUDF7);
            this.tpCDD.Controls.Add(this.lblUDF6);
            this.tpCDD.Controls.Add(this.lblUDF5);
            this.tpCDD.Controls.Add(this.lblUDF4);
            this.tpCDD.Controls.Add(this.lblUDF3);
            this.tpCDD.Controls.Add(this.lblUDF2);
            this.tpCDD.Controls.Add(this.lblUDF1);
            this.tpCDD.Controls.Add(this.label50);
            this.tpCDD.Controls.Add(this.label49);
            this.tpCDD.Location = new System.Drawing.Point(4, 23);
            this.tpCDD.Name = "tpCDD";
            this.tpCDD.Padding = new System.Windows.Forms.Padding(3);
            this.tpCDD.Size = new System.Drawing.Size(1188, 594);
            this.tpCDD.TabIndex = 0;
            this.tpCDD.Text = "CDD";
            this.tpCDD.UseVisualStyleBackColor = true;
            // 
            // txtDNIS
            // 
            this.txtDNIS.BackColor = System.Drawing.SystemColors.Info;
            this.txtDNIS.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtDNIS.Location = new System.Drawing.Point(729, 45);
            this.txtDNIS.Name = "txtDNIS";
            this.txtDNIS.ReadOnly = true;
            this.txtDNIS.Size = new System.Drawing.Size(338, 20);
            this.txtDNIS.TabIndex = 27;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 8.25F);
            this.label4.Location = new System.Drawing.Point(639, 48);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 14);
            this.label4.TabIndex = 26;
            this.label4.Text = "DNIS";
            // 
            // txtServiceName
            // 
            this.txtServiceName.BackColor = System.Drawing.SystemColors.Info;
            this.txtServiceName.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtServiceName.Location = new System.Drawing.Point(204, 45);
            this.txtServiceName.Name = "txtServiceName";
            this.txtServiceName.ReadOnly = true;
            this.txtServiceName.Size = new System.Drawing.Size(338, 20);
            this.txtServiceName.TabIndex = 23;
            // 
            // txtServiceID
            // 
            this.txtServiceID.BackColor = System.Drawing.SystemColors.Info;
            this.txtServiceID.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtServiceID.Location = new System.Drawing.Point(90, 45);
            this.txtServiceID.Name = "txtServiceID";
            this.txtServiceID.ReadOnly = true;
            this.txtServiceID.Size = new System.Drawing.Size(108, 20);
            this.txtServiceID.TabIndex = 22;
            // 
            // lblService
            // 
            this.lblService.AutoSize = true;
            this.lblService.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblService.Location = new System.Drawing.Point(38, 48);
            this.lblService.Name = "lblService";
            this.lblService.Size = new System.Drawing.Size(44, 14);
            this.lblService.TabIndex = 21;
            this.lblService.Text = "Service";
            // 
            // txtAgentName
            // 
            this.txtAgentName.BackColor = System.Drawing.SystemColors.Info;
            this.txtAgentName.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtAgentName.Location = new System.Drawing.Point(204, 19);
            this.txtAgentName.Name = "txtAgentName";
            this.txtAgentName.ReadOnly = true;
            this.txtAgentName.Size = new System.Drawing.Size(338, 20);
            this.txtAgentName.TabIndex = 20;
            // 
            // txtAgentID
            // 
            this.txtAgentID.BackColor = System.Drawing.SystemColors.Info;
            this.txtAgentID.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtAgentID.Location = new System.Drawing.Point(90, 19);
            this.txtAgentID.Name = "txtAgentID";
            this.txtAgentID.ReadOnly = true;
            this.txtAgentID.Size = new System.Drawing.Size(108, 20);
            this.txtAgentID.TabIndex = 19;
            // 
            // lblAgent
            // 
            this.lblAgent.AutoSize = true;
            this.lblAgent.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblAgent.Location = new System.Drawing.Point(38, 22);
            this.lblAgent.Name = "lblAgent";
            this.lblAgent.Size = new System.Drawing.Size(36, 14);
            this.lblAgent.TabIndex = 18;
            this.lblAgent.Text = "Agent";
            // 
            // lblSep1
            // 
            this.lblSep1.BackColor = System.Drawing.SystemColors.ControlText;
            this.lblSep1.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblSep1.Location = new System.Drawing.Point(17, 98);
            this.lblSep1.Name = "lblSep1";
            this.lblSep1.Size = new System.Drawing.Size(1154, 2);
            this.lblSep1.TabIndex = 30;
            // 
            // lblSep3
            // 
            this.lblSep3.BackColor = System.Drawing.SystemColors.ControlText;
            this.lblSep3.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblSep3.Location = new System.Drawing.Point(17, 588);
            this.lblSep3.Name = "lblSep3";
            this.lblSep3.Size = new System.Drawing.Size(1154, 2);
            this.lblSep3.TabIndex = 41;
            // 
            // txtUDF20
            // 
            this.txtUDF20.BackColor = System.Drawing.SystemColors.Info;
            this.txtUDF20.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtUDF20.Location = new System.Drawing.Point(766, 539);
            this.txtUDF20.Multiline = true;
            this.txtUDF20.Name = "txtUDF20";
            this.txtUDF20.ReadOnly = true;
            this.txtUDF20.Size = new System.Drawing.Size(388, 42);
            this.txtUDF20.TabIndex = 71;
            // 
            // txtUDF19
            // 
            this.txtUDF19.BackColor = System.Drawing.SystemColors.Info;
            this.txtUDF19.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtUDF19.Location = new System.Drawing.Point(766, 491);
            this.txtUDF19.Multiline = true;
            this.txtUDF19.Name = "txtUDF19";
            this.txtUDF19.ReadOnly = true;
            this.txtUDF19.Size = new System.Drawing.Size(388, 42);
            this.txtUDF19.TabIndex = 69;
            // 
            // txtUDF18
            // 
            this.txtUDF18.BackColor = System.Drawing.SystemColors.Info;
            this.txtUDF18.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtUDF18.Location = new System.Drawing.Point(766, 443);
            this.txtUDF18.Multiline = true;
            this.txtUDF18.Name = "txtUDF18";
            this.txtUDF18.ReadOnly = true;
            this.txtUDF18.Size = new System.Drawing.Size(388, 42);
            this.txtUDF18.TabIndex = 67;
            // 
            // txtUDF17
            // 
            this.txtUDF17.BackColor = System.Drawing.SystemColors.Info;
            this.txtUDF17.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtUDF17.Location = new System.Drawing.Point(766, 395);
            this.txtUDF17.Multiline = true;
            this.txtUDF17.Name = "txtUDF17";
            this.txtUDF17.ReadOnly = true;
            this.txtUDF17.Size = new System.Drawing.Size(388, 42);
            this.txtUDF17.TabIndex = 65;
            // 
            // txtUDF16
            // 
            this.txtUDF16.BackColor = System.Drawing.SystemColors.Info;
            this.txtUDF16.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtUDF16.Location = new System.Drawing.Point(766, 347);
            this.txtUDF16.Multiline = true;
            this.txtUDF16.Name = "txtUDF16";
            this.txtUDF16.ReadOnly = true;
            this.txtUDF16.Size = new System.Drawing.Size(388, 42);
            this.txtUDF16.TabIndex = 63;
            // 
            // txtUDF15
            // 
            this.txtUDF15.BackColor = System.Drawing.SystemColors.Info;
            this.txtUDF15.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtUDF15.Location = new System.Drawing.Point(766, 299);
            this.txtUDF15.Multiline = true;
            this.txtUDF15.Name = "txtUDF15";
            this.txtUDF15.ReadOnly = true;
            this.txtUDF15.Size = new System.Drawing.Size(388, 42);
            this.txtUDF15.TabIndex = 61;
            // 
            // txtUDF14
            // 
            this.txtUDF14.BackColor = System.Drawing.SystemColors.Info;
            this.txtUDF14.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtUDF14.Location = new System.Drawing.Point(766, 251);
            this.txtUDF14.Multiline = true;
            this.txtUDF14.Name = "txtUDF14";
            this.txtUDF14.ReadOnly = true;
            this.txtUDF14.Size = new System.Drawing.Size(388, 42);
            this.txtUDF14.TabIndex = 59;
            // 
            // txtUDF13
            // 
            this.txtUDF13.BackColor = System.Drawing.SystemColors.Info;
            this.txtUDF13.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtUDF13.Location = new System.Drawing.Point(766, 203);
            this.txtUDF13.Multiline = true;
            this.txtUDF13.Name = "txtUDF13";
            this.txtUDF13.ReadOnly = true;
            this.txtUDF13.Size = new System.Drawing.Size(388, 42);
            this.txtUDF13.TabIndex = 57;
            // 
            // txtUDF12
            // 
            this.txtUDF12.BackColor = System.Drawing.SystemColors.Info;
            this.txtUDF12.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtUDF12.Location = new System.Drawing.Point(766, 155);
            this.txtUDF12.Multiline = true;
            this.txtUDF12.Name = "txtUDF12";
            this.txtUDF12.ReadOnly = true;
            this.txtUDF12.Size = new System.Drawing.Size(388, 42);
            this.txtUDF12.TabIndex = 55;
            // 
            // txtUDF11
            // 
            this.txtUDF11.BackColor = System.Drawing.SystemColors.Info;
            this.txtUDF11.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtUDF11.Location = new System.Drawing.Point(766, 107);
            this.txtUDF11.Multiline = true;
            this.txtUDF11.Name = "txtUDF11";
            this.txtUDF11.ReadOnly = true;
            this.txtUDF11.Size = new System.Drawing.Size(388, 42);
            this.txtUDF11.TabIndex = 53;
            // 
            // lblUDF20
            // 
            this.lblUDF20.AutoSize = true;
            this.lblUDF20.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblUDF20.Location = new System.Drawing.Point(618, 542);
            this.lblUDF20.Name = "lblUDF20";
            this.lblUDF20.Size = new System.Drawing.Size(85, 14);
            this.lblUDF20.TabIndex = 70;
            this.lblUDF20.Text = "User Defined 20";
            // 
            // lblUDF19
            // 
            this.lblUDF19.AutoSize = true;
            this.lblUDF19.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblUDF19.Location = new System.Drawing.Point(618, 494);
            this.lblUDF19.Name = "lblUDF19";
            this.lblUDF19.Size = new System.Drawing.Size(85, 14);
            this.lblUDF19.TabIndex = 68;
            this.lblUDF19.Text = "User Defined 19";
            // 
            // lblUDF18
            // 
            this.lblUDF18.AutoSize = true;
            this.lblUDF18.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblUDF18.Location = new System.Drawing.Point(618, 446);
            this.lblUDF18.Name = "lblUDF18";
            this.lblUDF18.Size = new System.Drawing.Size(85, 14);
            this.lblUDF18.TabIndex = 66;
            this.lblUDF18.Text = "User Defined 18";
            // 
            // lblUDF17
            // 
            this.lblUDF17.AutoSize = true;
            this.lblUDF17.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblUDF17.Location = new System.Drawing.Point(618, 398);
            this.lblUDF17.Name = "lblUDF17";
            this.lblUDF17.Size = new System.Drawing.Size(85, 14);
            this.lblUDF17.TabIndex = 64;
            this.lblUDF17.Text = "User Defined 17";
            // 
            // lblUDF16
            // 
            this.lblUDF16.AutoSize = true;
            this.lblUDF16.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblUDF16.Location = new System.Drawing.Point(618, 350);
            this.lblUDF16.Name = "lblUDF16";
            this.lblUDF16.Size = new System.Drawing.Size(85, 14);
            this.lblUDF16.TabIndex = 62;
            this.lblUDF16.Text = "User Defined 16";
            // 
            // lblUDF15
            // 
            this.lblUDF15.AutoSize = true;
            this.lblUDF15.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblUDF15.Location = new System.Drawing.Point(618, 302);
            this.lblUDF15.Name = "lblUDF15";
            this.lblUDF15.Size = new System.Drawing.Size(85, 14);
            this.lblUDF15.TabIndex = 60;
            this.lblUDF15.Text = "User Defined 15";
            // 
            // lblUDF14
            // 
            this.lblUDF14.AutoSize = true;
            this.lblUDF14.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblUDF14.Location = new System.Drawing.Point(618, 254);
            this.lblUDF14.Name = "lblUDF14";
            this.lblUDF14.Size = new System.Drawing.Size(85, 14);
            this.lblUDF14.TabIndex = 58;
            this.lblUDF14.Text = "User Defined 14";
            // 
            // lblUDF13
            // 
            this.lblUDF13.AutoSize = true;
            this.lblUDF13.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblUDF13.Location = new System.Drawing.Point(618, 206);
            this.lblUDF13.Name = "lblUDF13";
            this.lblUDF13.Size = new System.Drawing.Size(85, 14);
            this.lblUDF13.TabIndex = 56;
            this.lblUDF13.Text = "User Defined 13";
            // 
            // lblUDF12
            // 
            this.lblUDF12.AutoSize = true;
            this.lblUDF12.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblUDF12.Location = new System.Drawing.Point(618, 158);
            this.lblUDF12.Name = "lblUDF12";
            this.lblUDF12.Size = new System.Drawing.Size(85, 14);
            this.lblUDF12.TabIndex = 54;
            this.lblUDF12.Text = "User Defined 12";
            // 
            // lblUDF11
            // 
            this.lblUDF11.AutoSize = true;
            this.lblUDF11.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblUDF11.Location = new System.Drawing.Point(618, 110);
            this.lblUDF11.Name = "lblUDF11";
            this.lblUDF11.Size = new System.Drawing.Size(84, 14);
            this.lblUDF11.TabIndex = 52;
            this.lblUDF11.Text = "User Defined 11";
            // 
            // txtUDF10
            // 
            this.txtUDF10.BackColor = System.Drawing.SystemColors.Info;
            this.txtUDF10.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtUDF10.Location = new System.Drawing.Point(172, 539);
            this.txtUDF10.Multiline = true;
            this.txtUDF10.Name = "txtUDF10";
            this.txtUDF10.ReadOnly = true;
            this.txtUDF10.Size = new System.Drawing.Size(388, 42);
            this.txtUDF10.TabIndex = 50;
            // 
            // txtUDF9
            // 
            this.txtUDF9.BackColor = System.Drawing.SystemColors.Info;
            this.txtUDF9.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtUDF9.Location = new System.Drawing.Point(172, 491);
            this.txtUDF9.Multiline = true;
            this.txtUDF9.Name = "txtUDF9";
            this.txtUDF9.ReadOnly = true;
            this.txtUDF9.Size = new System.Drawing.Size(388, 42);
            this.txtUDF9.TabIndex = 48;
            // 
            // txtUDF8
            // 
            this.txtUDF8.BackColor = System.Drawing.SystemColors.Info;
            this.txtUDF8.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtUDF8.Location = new System.Drawing.Point(172, 443);
            this.txtUDF8.Multiline = true;
            this.txtUDF8.Name = "txtUDF8";
            this.txtUDF8.ReadOnly = true;
            this.txtUDF8.Size = new System.Drawing.Size(388, 42);
            this.txtUDF8.TabIndex = 46;
            // 
            // txtUDF7
            // 
            this.txtUDF7.BackColor = System.Drawing.SystemColors.Info;
            this.txtUDF7.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtUDF7.Location = new System.Drawing.Point(172, 395);
            this.txtUDF7.Multiline = true;
            this.txtUDF7.Name = "txtUDF7";
            this.txtUDF7.ReadOnly = true;
            this.txtUDF7.Size = new System.Drawing.Size(388, 42);
            this.txtUDF7.TabIndex = 44;
            // 
            // txtUDF6
            // 
            this.txtUDF6.BackColor = System.Drawing.SystemColors.Info;
            this.txtUDF6.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtUDF6.Location = new System.Drawing.Point(172, 347);
            this.txtUDF6.Multiline = true;
            this.txtUDF6.Name = "txtUDF6";
            this.txtUDF6.ReadOnly = true;
            this.txtUDF6.Size = new System.Drawing.Size(388, 42);
            this.txtUDF6.TabIndex = 42;
            // 
            // txtUDF5
            // 
            this.txtUDF5.BackColor = System.Drawing.SystemColors.Info;
            this.txtUDF5.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtUDF5.Location = new System.Drawing.Point(172, 299);
            this.txtUDF5.Multiline = true;
            this.txtUDF5.Name = "txtUDF5";
            this.txtUDF5.ReadOnly = true;
            this.txtUDF5.Size = new System.Drawing.Size(388, 42);
            this.txtUDF5.TabIndex = 40;
            // 
            // txtUDF4
            // 
            this.txtUDF4.BackColor = System.Drawing.SystemColors.Info;
            this.txtUDF4.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtUDF4.Location = new System.Drawing.Point(172, 251);
            this.txtUDF4.Multiline = true;
            this.txtUDF4.Name = "txtUDF4";
            this.txtUDF4.ReadOnly = true;
            this.txtUDF4.Size = new System.Drawing.Size(388, 42);
            this.txtUDF4.TabIndex = 38;
            // 
            // txtUDF3
            // 
            this.txtUDF3.BackColor = System.Drawing.SystemColors.Info;
            this.txtUDF3.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtUDF3.Location = new System.Drawing.Point(172, 203);
            this.txtUDF3.Multiline = true;
            this.txtUDF3.Name = "txtUDF3";
            this.txtUDF3.ReadOnly = true;
            this.txtUDF3.Size = new System.Drawing.Size(388, 42);
            this.txtUDF3.TabIndex = 36;
            // 
            // txtUDF2
            // 
            this.txtUDF2.BackColor = System.Drawing.SystemColors.Info;
            this.txtUDF2.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtUDF2.Location = new System.Drawing.Point(172, 155);
            this.txtUDF2.Multiline = true;
            this.txtUDF2.Name = "txtUDF2";
            this.txtUDF2.ReadOnly = true;
            this.txtUDF2.Size = new System.Drawing.Size(388, 42);
            this.txtUDF2.TabIndex = 34;
            // 
            // txtUDF1
            // 
            this.txtUDF1.BackColor = System.Drawing.SystemColors.Info;
            this.txtUDF1.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtUDF1.Location = new System.Drawing.Point(172, 107);
            this.txtUDF1.Multiline = true;
            this.txtUDF1.Name = "txtUDF1";
            this.txtUDF1.ReadOnly = true;
            this.txtUDF1.Size = new System.Drawing.Size(388, 42);
            this.txtUDF1.TabIndex = 32;
            // 
            // lblSep2
            // 
            this.lblSep2.BackColor = System.Drawing.SystemColors.ControlText;
            this.lblSep2.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblSep2.Location = new System.Drawing.Point(593, 99);
            this.lblSep2.Name = "lblSep2";
            this.lblSep2.Size = new System.Drawing.Size(2, 489);
            this.lblSep2.TabIndex = 51;
            // 
            // lblUDF10
            // 
            this.lblUDF10.AutoSize = true;
            this.lblUDF10.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblUDF10.Location = new System.Drawing.Point(23, 542);
            this.lblUDF10.Name = "lblUDF10";
            this.lblUDF10.Size = new System.Drawing.Size(85, 14);
            this.lblUDF10.TabIndex = 49;
            this.lblUDF10.Text = "User Defined 10";
            // 
            // lblUDF9
            // 
            this.lblUDF9.AutoSize = true;
            this.lblUDF9.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblUDF9.Location = new System.Drawing.Point(23, 494);
            this.lblUDF9.Name = "lblUDF9";
            this.lblUDF9.Size = new System.Drawing.Size(79, 14);
            this.lblUDF9.TabIndex = 47;
            this.lblUDF9.Text = "User Defined 9";
            // 
            // lblUDF8
            // 
            this.lblUDF8.AutoSize = true;
            this.lblUDF8.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblUDF8.Location = new System.Drawing.Point(23, 446);
            this.lblUDF8.Name = "lblUDF8";
            this.lblUDF8.Size = new System.Drawing.Size(79, 14);
            this.lblUDF8.TabIndex = 45;
            this.lblUDF8.Text = "User Defined 8";
            // 
            // lblUDF7
            // 
            this.lblUDF7.AutoSize = true;
            this.lblUDF7.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblUDF7.Location = new System.Drawing.Point(23, 398);
            this.lblUDF7.Name = "lblUDF7";
            this.lblUDF7.Size = new System.Drawing.Size(79, 14);
            this.lblUDF7.TabIndex = 43;
            this.lblUDF7.Text = "User Defined 7";
            // 
            // lblUDF6
            // 
            this.lblUDF6.AutoSize = true;
            this.lblUDF6.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblUDF6.Location = new System.Drawing.Point(23, 350);
            this.lblUDF6.Name = "lblUDF6";
            this.lblUDF6.Size = new System.Drawing.Size(79, 14);
            this.lblUDF6.TabIndex = 41;
            this.lblUDF6.Text = "User Defined 6";
            // 
            // lblUDF5
            // 
            this.lblUDF5.AutoSize = true;
            this.lblUDF5.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblUDF5.Location = new System.Drawing.Point(23, 302);
            this.lblUDF5.Name = "lblUDF5";
            this.lblUDF5.Size = new System.Drawing.Size(79, 14);
            this.lblUDF5.TabIndex = 39;
            this.lblUDF5.Text = "User Defined 5";
            // 
            // lblUDF4
            // 
            this.lblUDF4.AutoSize = true;
            this.lblUDF4.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblUDF4.Location = new System.Drawing.Point(23, 254);
            this.lblUDF4.Name = "lblUDF4";
            this.lblUDF4.Size = new System.Drawing.Size(79, 14);
            this.lblUDF4.TabIndex = 37;
            this.lblUDF4.Text = "User Defined 4";
            // 
            // lblUDF3
            // 
            this.lblUDF3.AutoSize = true;
            this.lblUDF3.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblUDF3.Location = new System.Drawing.Point(23, 206);
            this.lblUDF3.Name = "lblUDF3";
            this.lblUDF3.Size = new System.Drawing.Size(79, 14);
            this.lblUDF3.TabIndex = 35;
            this.lblUDF3.Text = "User Defined 3";
            // 
            // lblUDF2
            // 
            this.lblUDF2.AutoSize = true;
            this.lblUDF2.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblUDF2.Location = new System.Drawing.Point(23, 158);
            this.lblUDF2.Name = "lblUDF2";
            this.lblUDF2.Size = new System.Drawing.Size(79, 14);
            this.lblUDF2.TabIndex = 33;
            this.lblUDF2.Text = "User Defined 2";
            // 
            // lblUDF1
            // 
            this.lblUDF1.AutoSize = true;
            this.lblUDF1.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblUDF1.Location = new System.Drawing.Point(23, 110);
            this.lblUDF1.Name = "lblUDF1";
            this.lblUDF1.Size = new System.Drawing.Size(79, 14);
            this.lblUDF1.TabIndex = 31;
            this.lblUDF1.Text = "User Defined 1";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Arial", 8.25F);
            this.label50.Location = new System.Drawing.Point(354, 3);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(36, 14);
            this.label50.TabIndex = 17;
            this.label50.Text = "NAME";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Arial", 8.25F);
            this.label49.Location = new System.Drawing.Point(135, 3);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(16, 14);
            this.label49.TabIndex = 16;
            this.label49.Text = "ID";
            // 
            // tpPopup
            // 
            this.tpPopup.Controls.Add(this.pnlPopup);
            this.tpPopup.Location = new System.Drawing.Point(4, 23);
            this.tpPopup.Name = "tpPopup";
            this.tpPopup.Padding = new System.Windows.Forms.Padding(3);
            this.tpPopup.Size = new System.Drawing.Size(1188, 594);
            this.tpPopup.TabIndex = 1;
            this.tpPopup.Text = "Popup";
            this.tpPopup.UseVisualStyleBackColor = true;
            // 
            // btnDispose
            // 
            this.btnDispose.AccessibleName = "";
            this.btnDispose.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnDispose.Font = new System.Drawing.Font("Arial", 8.25F);
            this.btnDispose.Location = new System.Drawing.Point(1116, 672);
            this.btnDispose.Name = "btnDispose";
            this.btnDispose.Size = new System.Drawing.Size(59, 25);
            this.btnDispose.TabIndex = 156;
            this.btnDispose.Text = "Dispose";
            this.btnDispose.UseVisualStyleBackColor = false;
            this.btnDispose.Click += new System.EventHandler(this.btnDispose_Click);
            // 
            // cmbDispDesc
            // 
            this.cmbDispDesc.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.cmbDispDesc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDispDesc.Font = new System.Drawing.Font("Arial", 8.25F);
            this.cmbDispDesc.FormattingEnabled = true;
            this.cmbDispDesc.Location = new System.Drawing.Point(118, 674);
            this.cmbDispDesc.Name = "cmbDispDesc";
            this.cmbDispDesc.Size = new System.Drawing.Size(265, 22);
            this.cmbDispDesc.TabIndex = 150;
            this.cmbDispDesc.SelectedIndexChanged += new System.EventHandler(this.cmbDispDesc_SelectedIndexChanged);
            // 
            // lblDisposition
            // 
            this.lblDisposition.AutoSize = true;
            this.lblDisposition.Font = new System.Drawing.Font("Arial", 8.25F);
            this.lblDisposition.Location = new System.Drawing.Point(21, 677);
            this.lblDisposition.Name = "lblDisposition";
            this.lblDisposition.Size = new System.Drawing.Size(59, 14);
            this.lblDisposition.TabIndex = 149;
            this.lblDisposition.Text = "&Disposition";
            // 
            // cmbDisp
            // 
            this.cmbDisp.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.cmbDisp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDisp.Font = new System.Drawing.Font("Arial", 8.25F);
            this.cmbDisp.FormattingEnabled = true;
            this.cmbDisp.Location = new System.Drawing.Point(303, 704);
            this.cmbDisp.Name = "cmbDisp";
            this.cmbDisp.Size = new System.Drawing.Size(80, 22);
            this.cmbDisp.TabIndex = 167;
            this.cmbDisp.Visible = false;
            // 
            // pnlCallback
            // 
            this.pnlCallback.Controls.Add(this.lblAltCbkNo);
            this.pnlCallback.Controls.Add(this.txtAltPhoneNo);
            this.pnlCallback.Controls.Add(this.cbSelfCbk);
            this.pnlCallback.Controls.Add(this.dtpCbkDtTm);
            this.pnlCallback.Location = new System.Drawing.Point(389, 674);
            this.pnlCallback.Name = "pnlCallback";
            this.pnlCallback.Size = new System.Drawing.Size(427, 22);
            this.pnlCallback.TabIndex = 151;
            // 
            // lblAltCbkNo
            // 
            this.lblAltCbkNo.AutoSize = true;
            this.lblAltCbkNo.BackColor = System.Drawing.SystemColors.Control;
            this.lblAltCbkNo.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAltCbkNo.Location = new System.Drawing.Point(243, 4);
            this.lblAltCbkNo.Name = "lblAltCbkNo";
            this.lblAltCbkNo.Size = new System.Drawing.Size(91, 14);
            this.lblAltCbkNo.TabIndex = 154;
            this.lblAltCbkNo.Text = "Alternate Number";
            // 
            // txtAltPhoneNo
            // 
            this.txtAltPhoneNo.Location = new System.Drawing.Point(336, 1);
            this.txtAltPhoneNo.Name = "txtAltPhoneNo";
            this.txtAltPhoneNo.Size = new System.Drawing.Size(88, 20);
            this.txtAltPhoneNo.TabIndex = 155;
            // 
            // cbSelfCbk
            // 
            this.cbSelfCbk.AutoSize = true;
            this.cbSelfCbk.Checked = true;
            this.cbSelfCbk.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbSelfCbk.Font = new System.Drawing.Font("Arial", 8.25F);
            this.cbSelfCbk.Location = new System.Drawing.Point(143, 2);
            this.cbSelfCbk.Name = "cbSelfCbk";
            this.cbSelfCbk.Size = new System.Drawing.Size(88, 18);
            this.cbSelfCbk.TabIndex = 153;
            this.cbSelfCbk.Text = "Self Callback";
            this.cbSelfCbk.UseVisualStyleBackColor = true;
            // 
            // tmrPreview
            // 
            this.tmrPreview.Interval = 1000;
            this.tmrPreview.Tick += new System.EventHandler(this.tmrPreview_Tick);
            // 
            // tmrAutoDisp
            // 
            this.tmrAutoDisp.Interval = 1000;
            this.tmrAutoDisp.Tick += new System.EventHandler(this.tmrAutoDisp_Tick);
            // 
            // tmrAssignedServices
            // 
            this.tmrAssignedServices.Interval = 1000;
            this.tmrAssignedServices.Tick += new System.EventHandler(this.tmrAssignedServices_Tick);
            // 
            // tmrCallDuration
            // 
            this.tmrCallDuration.Tick += new System.EventHandler(this.tmrCallDuration_Tick);
            // 
            // lblCustInfo
            // 
            this.lblCustInfo.AutoSize = true;
            this.lblCustInfo.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblCustInfo.Location = new System.Drawing.Point(7, 47);
            this.lblCustInfo.Name = "lblCustInfo";
            this.lblCustInfo.Size = new System.Drawing.Size(130, 14);
            this.lblCustInfo.TabIndex = 78;
            this.lblCustInfo.Text = "Customer Information";
            // 
            // lblSrNo
            // 
            this.lblSrNo.AutoSize = true;
            this.lblSrNo.BackColor = System.Drawing.SystemColors.Control;
            this.lblSrNo.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSrNo.Location = new System.Drawing.Point(12, 78);
            this.lblSrNo.Name = "lblSrNo";
            this.lblSrNo.Size = new System.Drawing.Size(34, 14);
            this.lblSrNo.TabIndex = 80;
            this.lblSrNo.Text = "Sr No";
            // 
            // txtSrNo
            // 
            this.txtSrNo.BackColor = System.Drawing.SystemColors.Info;
            this.txtSrNo.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSrNo.Location = new System.Drawing.Point(108, 75);
            this.txtSrNo.Name = "txtSrNo";
            this.txtSrNo.ReadOnly = true;
            this.txtSrNo.Size = new System.Drawing.Size(265, 20);
            this.txtSrNo.TabIndex = 81;
            this.lblPhoneStatusToolTip.SetToolTip(this.txtSrNo, "Information. Cannot Modify.");
            // 
            // lblFolioNumber
            // 
            this.lblFolioNumber.AutoSize = true;
            this.lblFolioNumber.BackColor = System.Drawing.SystemColors.Control;
            this.lblFolioNumber.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFolioNumber.Location = new System.Drawing.Point(12, 104);
            this.lblFolioNumber.Name = "lblFolioNumber";
            this.lblFolioNumber.Size = new System.Drawing.Size(69, 14);
            this.lblFolioNumber.TabIndex = 82;
            this.lblFolioNumber.Text = "Folio Number";
            // 
            // txtFolioNumber
            // 
            this.txtFolioNumber.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtFolioNumber.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFolioNumber.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtFolioNumber.Location = new System.Drawing.Point(108, 103);
            this.txtFolioNumber.MaxLength = 20;
            this.txtFolioNumber.Name = "txtFolioNumber";
            this.txtFolioNumber.Size = new System.Drawing.Size(265, 20);
            this.txtFolioNumber.TabIndex = 83;
            this.lblPhoneStatusToolTip.SetToolTip(this.txtFolioNumber, "Information. Editable Field.");
            // 
            // lblInvestorName
            // 
            this.lblInvestorName.AutoSize = true;
            this.lblInvestorName.BackColor = System.Drawing.SystemColors.Control;
            this.lblInvestorName.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvestorName.Location = new System.Drawing.Point(12, 130);
            this.lblInvestorName.Name = "lblInvestorName";
            this.lblInvestorName.Size = new System.Drawing.Size(76, 14);
            this.lblInvestorName.TabIndex = 84;
            this.lblInvestorName.Text = "Investor Name";
            // 
            // txtInvestorName
            // 
            this.txtInvestorName.BackColor = System.Drawing.SystemColors.Info;
            this.txtInvestorName.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInvestorName.Location = new System.Drawing.Point(108, 131);
            this.txtInvestorName.MaxLength = 50;
            this.txtInvestorName.Name = "txtInvestorName";
            this.txtInvestorName.ReadOnly = true;
            this.txtInvestorName.Size = new System.Drawing.Size(265, 20);
            this.txtInvestorName.TabIndex = 85;
            this.lblPhoneStatusToolTip.SetToolTip(this.txtInvestorName, "Information. Cannot Modify.");
            // 
            // lblSep4
            // 
            this.lblSep4.BackColor = System.Drawing.SystemColors.ControlText;
            this.lblSep4.Location = new System.Drawing.Point(7, 64);
            this.lblSep4.Name = "lblSep4";
            this.lblSep4.Size = new System.Drawing.Size(380, 2);
            this.lblSep4.TabIndex = 79;
            // 
            // lblSep5
            // 
            this.lblSep5.BackColor = System.Drawing.SystemColors.ControlText;
            this.lblSep5.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSep5.Location = new System.Drawing.Point(394, 4);
            this.lblSep5.Name = "lblSep5";
            this.lblSep5.Size = new System.Drawing.Size(2, 410);
            this.lblSep5.TabIndex = 104;
            this.lblSep5.Visible = false;
            // 
            // lblSep6
            // 
            this.lblSep6.BackColor = System.Drawing.SystemColors.ControlText;
            this.lblSep6.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSep6.Location = new System.Drawing.Point(790, 4);
            this.lblSep6.Name = "lblSep6";
            this.lblSep6.Size = new System.Drawing.Size(2, 410);
            this.lblSep6.TabIndex = 134;
            this.lblSep6.Visible = false;
            // 
            // lblSep7
            // 
            this.lblSep7.BackColor = System.Drawing.SystemColors.ControlText;
            this.lblSep7.Location = new System.Drawing.Point(12, 415);
            this.lblSep7.Name = "lblSep7";
            this.lblSep7.Size = new System.Drawing.Size(1154, 2);
            this.lblSep7.TabIndex = 157;
            // 
            // lbltax
            // 
            this.lbltax.AutoSize = true;
            this.lbltax.BackColor = System.Drawing.SystemColors.Control;
            this.lbltax.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltax.Location = new System.Drawing.Point(9, 302);
            this.lbltax.Name = "lbltax";
            this.lbltax.Size = new System.Drawing.Size(58, 14);
            this.lbltax.TabIndex = 96;
            this.lbltax.Text = "Tax Status";
            // 
            // txtstatus
            // 
            this.txtstatus.BackColor = System.Drawing.SystemColors.Info;
            this.txtstatus.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstatus.Location = new System.Drawing.Point(105, 299);
            this.txtstatus.Name = "txtstatus";
            this.txtstatus.ReadOnly = true;
            this.txtstatus.Size = new System.Drawing.Size(265, 20);
            this.txtstatus.TabIndex = 97;
            this.lblPhoneStatusToolTip.SetToolTip(this.txtstatus, "Information. Cannot Modify.");
            // 
            // lbCallHistory
            // 
            this.lbCallHistory.AutoSize = true;
            this.lbCallHistory.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lbCallHistory.Location = new System.Drawing.Point(7, 435);
            this.lbCallHistory.Name = "lbCallHistory";
            this.lbCallHistory.Size = new System.Drawing.Size(69, 14);
            this.lbCallHistory.TabIndex = 145;
            this.lbCallHistory.Text = "Call History";
            // 
            // lblCallComments
            // 
            this.lblCallComments.AutoSize = true;
            this.lblCallComments.BackColor = System.Drawing.SystemColors.Control;
            this.lblCallComments.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblCallComments.Location = new System.Drawing.Point(800, 256);
            this.lblCallComments.Name = "lblCallComments";
            this.lblCallComments.Size = new System.Drawing.Size(92, 14);
            this.lblCallComments.TabIndex = 143;
            this.lblCallComments.Text = "Call Comments";
            // 
            // txtRemarks
            // 
            this.txtRemarks.BackColor = System.Drawing.SystemColors.Window;
            this.txtRemarks.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemarks.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtRemarks.Location = new System.Drawing.Point(801, 275);
            this.txtRemarks.Multiline = true;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRemarks.Size = new System.Drawing.Size(372, 130);
            this.txtRemarks.TabIndex = 144;
            this.lblPhoneStatusToolTip.SetToolTip(this.txtRemarks, "Editable Field");
            // 
            // txtaccounttype
            // 
            this.txtaccounttype.BackColor = System.Drawing.SystemColors.Info;
            this.txtaccounttype.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccounttype.Location = new System.Drawing.Point(497, 73);
            this.txtaccounttype.Name = "txtaccounttype";
            this.txtaccounttype.ReadOnly = true;
            this.txtaccounttype.Size = new System.Drawing.Size(265, 20);
            this.txtaccounttype.TabIndex = 105;
            this.lblPhoneStatusToolTip.SetToolTip(this.txtaccounttype, "Information. Cannot Modify.");
            // 
            // lblaccounttype
            // 
            this.lblaccounttype.AutoSize = true;
            this.lblaccounttype.BackColor = System.Drawing.SystemColors.Control;
            this.lblaccounttype.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblaccounttype.Location = new System.Drawing.Point(401, 76);
            this.lblaccounttype.Name = "lblaccounttype";
            this.lblaccounttype.Size = new System.Drawing.Size(74, 14);
            this.lblaccounttype.TabIndex = 104;
            this.lblaccounttype.Text = "Account Type";
            // 
            // txtAmount
            // 
            this.txtAmount.BackColor = System.Drawing.SystemColors.Info;
            this.txtAmount.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAmount.Location = new System.Drawing.Point(105, 327);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.ReadOnly = true;
            this.txtAmount.Size = new System.Drawing.Size(265, 20);
            this.txtAmount.TabIndex = 99;
            this.lblPhoneStatusToolTip.SetToolTip(this.txtAmount, "Information. Cannot Modify.");
            // 
            // lblAmount
            // 
            this.lblAmount.AutoSize = true;
            this.lblAmount.BackColor = System.Drawing.SystemColors.Control;
            this.lblAmount.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAmount.Location = new System.Drawing.Point(12, 330);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new System.Drawing.Size(44, 14);
            this.lblAmount.TabIndex = 98;
            this.lblAmount.Text = "Amount";
            // 
            // txtaccountnum
            // 
            this.txtaccountnum.BackColor = System.Drawing.SystemColors.Info;
            this.txtaccountnum.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaccountnum.Location = new System.Drawing.Point(108, 385);
            this.txtaccountnum.Name = "txtaccountnum";
            this.txtaccountnum.ReadOnly = true;
            this.txtaccountnum.Size = new System.Drawing.Size(265, 20);
            this.txtaccountnum.TabIndex = 103;
            this.lblPhoneStatusToolTip.SetToolTip(this.txtaccountnum, "Information. Cannot Modify.");
            // 
            // lblaccountnum
            // 
            this.lblaccountnum.AutoSize = true;
            this.lblaccountnum.BackColor = System.Drawing.SystemColors.Control;
            this.lblaccountnum.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblaccountnum.Location = new System.Drawing.Point(12, 388);
            this.lblaccountnum.Name = "lblaccountnum";
            this.lblaccountnum.Size = new System.Drawing.Size(88, 14);
            this.lblaccountnum.TabIndex = 102;
            this.lblaccountnum.Text = "Account Number";
            // 
            // txtbankname
            // 
            this.txtbankname.BackColor = System.Drawing.SystemColors.Info;
            this.txtbankname.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbankname.Location = new System.Drawing.Point(497, 131);
            this.txtbankname.Name = "txtbankname";
            this.txtbankname.ReadOnly = true;
            this.txtbankname.Size = new System.Drawing.Size(265, 20);
            this.txtbankname.TabIndex = 109;
            this.lblPhoneStatusToolTip.SetToolTip(this.txtbankname, "Information. Cannot Modify.");
            // 
            // lblbankname
            // 
            this.lblbankname.AutoSize = true;
            this.lblbankname.BackColor = System.Drawing.SystemColors.Control;
            this.lblbankname.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbankname.Location = new System.Drawing.Point(401, 131);
            this.lblbankname.Name = "lblbankname";
            this.lblbankname.Size = new System.Drawing.Size(61, 14);
            this.lblbankname.TabIndex = 108;
            this.lblbankname.Text = "Bank Name";
            // 
            // lblbranchname
            // 
            this.lblbranchname.AutoSize = true;
            this.lblbranchname.BackColor = System.Drawing.SystemColors.Control;
            this.lblbranchname.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbranchname.Location = new System.Drawing.Point(401, 160);
            this.lblbranchname.Name = "lblbranchname";
            this.lblbranchname.Size = new System.Drawing.Size(72, 14);
            this.lblbranchname.TabIndex = 110;
            this.lblbranchname.Text = "Branch Name";
            // 
            // txtbranchname
            // 
            this.txtbranchname.BackColor = System.Drawing.SystemColors.Info;
            this.txtbranchname.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbranchname.Location = new System.Drawing.Point(497, 159);
            this.txtbranchname.Multiline = true;
            this.txtbranchname.Name = "txtbranchname";
            this.txtbranchname.ReadOnly = true;
            this.txtbranchname.Size = new System.Drawing.Size(265, 22);
            this.txtbranchname.TabIndex = 111;
            this.lblPhoneStatusToolTip.SetToolTip(this.txtbranchname, "Information. Cannot Modify.");
            // 
            // pnlInbound
            // 
            this.pnlInbound.Controls.Add(this.cmbSuggestion);
            this.pnlInbound.Controls.Add(this.lblSuggestion);
            this.pnlInbound.Controls.Add(this.cmbCurrentStatus);
            this.pnlInbound.Controls.Add(this.lblCurrentStatus);
            this.pnlInbound.Controls.Add(this.cmbLanguage);
            this.pnlInbound.Controls.Add(this.cmbCallerType);
            this.pnlInbound.Controls.Add(this.lblLanguage);
            this.pnlInbound.Controls.Add(this.lblCallerType);
            this.pnlInbound.Controls.Add(this.cmbCallCategory);
            this.pnlInbound.Controls.Add(this.lblCallCategory);
            this.pnlInbound.Controls.Add(this.cmbQuery);
            this.pnlInbound.Controls.Add(this.lblQuery);
            this.pnlInbound.Controls.Add(this.rdoBrokerCode);
            this.pnlInbound.Controls.Add(this.rdoFolio);
            this.pnlInbound.Controls.Add(this.lblType);
            this.pnlInbound.Controls.Add(this.label7);
            this.pnlInbound.Controls.Add(this.label8);
            this.pnlInbound.Location = new System.Drawing.Point(798, 7);
            this.pnlInbound.Name = "pnlInbound";
            this.pnlInbound.Size = new System.Drawing.Size(381, 241);
            this.pnlInbound.TabIndex = 135;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(1, 3);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(129, 14);
            this.label8.TabIndex = 126;
            this.label8.Text = "Additional Information";
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.SystemColors.ControlText;
            this.label7.Location = new System.Drawing.Point(4, 19);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(384, 2);
            this.label7.TabIndex = 137;
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.BackColor = System.Drawing.SystemColors.Control;
            this.lblType.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblType.Location = new System.Drawing.Point(8, 29);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(30, 14);
            this.lblType.TabIndex = 127;
            this.lblType.Text = "Type";
            // 
            // rdoFolio
            // 
            this.rdoFolio.AutoSize = true;
            this.rdoFolio.Location = new System.Drawing.Point(103, 24);
            this.rdoFolio.Name = "rdoFolio";
            this.rdoFolio.Size = new System.Drawing.Size(47, 18);
            this.rdoFolio.TabIndex = 128;
            this.rdoFolio.TabStop = true;
            this.rdoFolio.Text = "Folio";
            this.rdoFolio.UseVisualStyleBackColor = true;
            this.rdoFolio.CheckedChanged += new System.EventHandler(this.rdoFolio_CheckedChanged);
            // 
            // rdoBrokerCode
            // 
            this.rdoBrokerCode.AutoSize = true;
            this.rdoBrokerCode.Location = new System.Drawing.Point(184, 24);
            this.rdoBrokerCode.Name = "rdoBrokerCode";
            this.rdoBrokerCode.Size = new System.Drawing.Size(85, 18);
            this.rdoBrokerCode.TabIndex = 129;
            this.rdoBrokerCode.TabStop = true;
            this.rdoBrokerCode.Text = "Broker Code";
            this.rdoBrokerCode.UseVisualStyleBackColor = true;
            this.rdoBrokerCode.CheckedChanged += new System.EventHandler(this.rdoBrokerCode_CheckedChanged);
            // 
            // lblQuery
            // 
            this.lblQuery.AutoSize = true;
            this.lblQuery.BackColor = System.Drawing.SystemColors.Control;
            this.lblQuery.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuery.Location = new System.Drawing.Point(8, 110);
            this.lblQuery.Name = "lblQuery";
            this.lblQuery.Size = new System.Drawing.Size(37, 14);
            this.lblQuery.TabIndex = 135;
            this.lblQuery.Text = "Query";
            // 
            // cmbQuery
            // 
            this.cmbQuery.BackColor = System.Drawing.SystemColors.Window;
            this.cmbQuery.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbQuery.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbQuery.ForeColor = System.Drawing.SystemColors.WindowText;
            this.cmbQuery.FormattingEnabled = true;
            this.cmbQuery.Items.AddRange(new object[] {
            "",
            "Request",
            "Query",
            "Complaint",
            "Grievance",
            "Appreciation",
            "Suggestion"});
            this.cmbQuery.Location = new System.Drawing.Point(103, 111);
            this.cmbQuery.Name = "cmbQuery";
            this.cmbQuery.Size = new System.Drawing.Size(265, 22);
            this.cmbQuery.TabIndex = 136;
            this.lblPhoneStatusToolTip.SetToolTip(this.cmbQuery, "Editable Field");
            // 
            // lblCallCategory
            // 
            this.lblCallCategory.AutoSize = true;
            this.lblCallCategory.BackColor = System.Drawing.SystemColors.Control;
            this.lblCallCategory.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCallCategory.Location = new System.Drawing.Point(4, 141);
            this.lblCallCategory.Name = "lblCallCategory";
            this.lblCallCategory.Size = new System.Drawing.Size(71, 14);
            this.lblCallCategory.TabIndex = 137;
            this.lblCallCategory.Text = "Call Category";
            // 
            // cmbCallCategory
            // 
            this.cmbCallCategory.BackColor = System.Drawing.SystemColors.Window;
            this.cmbCallCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCallCategory.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCallCategory.ForeColor = System.Drawing.SystemColors.WindowText;
            this.cmbCallCategory.FormattingEnabled = true;
            this.cmbCallCategory.Items.AddRange(new object[] {
            "",
            "Completed",
            "Pending"});
            this.cmbCallCategory.Location = new System.Drawing.Point(102, 142);
            this.cmbCallCategory.Name = "cmbCallCategory";
            this.cmbCallCategory.Size = new System.Drawing.Size(265, 22);
            this.cmbCallCategory.TabIndex = 138;
            this.lblPhoneStatusToolTip.SetToolTip(this.cmbCallCategory, "Editable Field");
            // 
            // lblCallerType
            // 
            this.lblCallerType.AutoSize = true;
            this.lblCallerType.BackColor = System.Drawing.SystemColors.Control;
            this.lblCallerType.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCallerType.Location = new System.Drawing.Point(8, 81);
            this.lblCallerType.Name = "lblCallerType";
            this.lblCallerType.Size = new System.Drawing.Size(60, 14);
            this.lblCallerType.TabIndex = 132;
            this.lblCallerType.Text = "Caller Type";
            // 
            // lblLanguage
            // 
            this.lblLanguage.AutoSize = true;
            this.lblLanguage.BackColor = System.Drawing.SystemColors.Control;
            this.lblLanguage.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLanguage.Location = new System.Drawing.Point(8, 50);
            this.lblLanguage.Name = "lblLanguage";
            this.lblLanguage.Size = new System.Drawing.Size(55, 14);
            this.lblLanguage.TabIndex = 130;
            this.lblLanguage.Text = "Language";
            // 
            // cmbCallerType
            // 
            this.cmbCallerType.BackColor = System.Drawing.SystemColors.Window;
            this.cmbCallerType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCallerType.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCallerType.ForeColor = System.Drawing.SystemColors.WindowText;
            this.cmbCallerType.FormattingEnabled = true;
            this.cmbCallerType.Items.AddRange(new object[] {
            "",
            "Investor",
            "Distributor",
            "Third party",
            "Claimant",
            "Prospect ",
            "Nominee"});
            this.cmbCallerType.Location = new System.Drawing.Point(102, 79);
            this.cmbCallerType.Name = "cmbCallerType";
            this.cmbCallerType.Size = new System.Drawing.Size(265, 22);
            this.cmbCallerType.TabIndex = 133;
            this.lblPhoneStatusToolTip.SetToolTip(this.cmbCallerType, "Editable Field");
            // 
            // cmbLanguage
            // 
            this.cmbLanguage.BackColor = System.Drawing.SystemColors.Window;
            this.cmbLanguage.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLanguage.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbLanguage.ForeColor = System.Drawing.SystemColors.WindowText;
            this.cmbLanguage.FormattingEnabled = true;
            this.cmbLanguage.Items.AddRange(new object[] {
            "",
            "Investor",
            "Distributor",
            "Third party",
            "Claimant",
            "Prospect ",
            "Nominee"});
            this.cmbLanguage.Location = new System.Drawing.Point(103, 49);
            this.cmbLanguage.Name = "cmbLanguage";
            this.cmbLanguage.Size = new System.Drawing.Size(265, 22);
            this.cmbLanguage.TabIndex = 131;
            this.lblPhoneStatusToolTip.SetToolTip(this.cmbLanguage, "Editable Field");
            // 
            // lblCurrentStatus
            // 
            this.lblCurrentStatus.AutoSize = true;
            this.lblCurrentStatus.BackColor = System.Drawing.SystemColors.Control;
            this.lblCurrentStatus.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentStatus.Location = new System.Drawing.Point(8, 208);
            this.lblCurrentStatus.Name = "lblCurrentStatus";
            this.lblCurrentStatus.Size = new System.Drawing.Size(74, 14);
            this.lblCurrentStatus.TabIndex = 141;
            this.lblCurrentStatus.Text = "CurrentStatus";
            // 
            // cmbCurrentStatus
            // 
            this.cmbCurrentStatus.BackColor = System.Drawing.SystemColors.Window;
            this.cmbCurrentStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCurrentStatus.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCurrentStatus.ForeColor = System.Drawing.SystemColors.WindowText;
            this.cmbCurrentStatus.FormattingEnabled = true;
            this.cmbCurrentStatus.Items.AddRange(new object[] {
            "",
            "Investor",
            "Distributor",
            "Third party",
            "Claimant",
            "Prospect ",
            "Nominee"});
            this.cmbCurrentStatus.Location = new System.Drawing.Point(102, 207);
            this.cmbCurrentStatus.Name = "cmbCurrentStatus";
            this.cmbCurrentStatus.Size = new System.Drawing.Size(265, 22);
            this.cmbCurrentStatus.TabIndex = 142;
            this.lblPhoneStatusToolTip.SetToolTip(this.cmbCurrentStatus, "Editable Field");
            // 
            // lblstatename
            // 
            this.lblstatename.AutoSize = true;
            this.lblstatename.BackColor = System.Drawing.SystemColors.Control;
            this.lblstatename.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstatename.Location = new System.Drawing.Point(401, 189);
            this.lblstatename.Name = "lblstatename";
            this.lblstatename.Size = new System.Drawing.Size(62, 14);
            this.lblstatename.TabIndex = 112;
            this.lblstatename.Text = "State Name";
            // 
            // txtstate
            // 
            this.txtstate.BackColor = System.Drawing.SystemColors.Info;
            this.txtstate.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstate.Location = new System.Drawing.Point(497, 187);
            this.txtstate.Name = "txtstate";
            this.txtstate.ReadOnly = true;
            this.txtstate.Size = new System.Drawing.Size(265, 20);
            this.txtstate.TabIndex = 113;
            this.lblPhoneStatusToolTip.SetToolTip(this.txtstate, "Information. Cannot Modify.");
            // 
            // lblcity
            // 
            this.lblcity.AutoSize = true;
            this.lblcity.BackColor = System.Drawing.SystemColors.Control;
            this.lblcity.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcity.Location = new System.Drawing.Point(401, 217);
            this.lblcity.Name = "lblcity";
            this.lblcity.Size = new System.Drawing.Size(55, 14);
            this.lblcity.TabIndex = 114;
            this.lblcity.Text = "City Name";
            // 
            // txtcity
            // 
            this.txtcity.BackColor = System.Drawing.SystemColors.Info;
            this.txtcity.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcity.Location = new System.Drawing.Point(497, 214);
            this.txtcity.Name = "txtcity";
            this.txtcity.ReadOnly = true;
            this.txtcity.Size = new System.Drawing.Size(265, 20);
            this.txtcity.TabIndex = 115;
            this.lblPhoneStatusToolTip.SetToolTip(this.txtcity, "Information. Cannot Modify.");
            // 
            // lblschemename
            // 
            this.lblschemename.AutoSize = true;
            this.lblschemename.BackColor = System.Drawing.SystemColors.Control;
            this.lblschemename.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblschemename.Location = new System.Drawing.Point(9, 360);
            this.lblschemename.Name = "lblschemename";
            this.lblschemename.Size = new System.Drawing.Size(76, 14);
            this.lblschemename.TabIndex = 100;
            this.lblschemename.Text = "Scheme Name";
            // 
            // txtscheme
            // 
            this.txtscheme.BackColor = System.Drawing.SystemColors.Info;
            this.txtscheme.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtscheme.Location = new System.Drawing.Point(105, 355);
            this.txtscheme.Name = "txtscheme";
            this.txtscheme.ReadOnly = true;
            this.txtscheme.Size = new System.Drawing.Size(265, 20);
            this.txtscheme.TabIndex = 101;
            this.lblPhoneStatusToolTip.SetToolTip(this.txtscheme, "Information. Cannot Modify.");
            // 
            // lblSIPAmount
            // 
            this.lblSIPAmount.AutoSize = true;
            this.lblSIPAmount.BackColor = System.Drawing.SystemColors.Control;
            this.lblSIPAmount.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSIPAmount.Location = new System.Drawing.Point(401, 326);
            this.lblSIPAmount.Name = "lblSIPAmount";
            this.lblSIPAmount.Size = new System.Drawing.Size(61, 14);
            this.lblSIPAmount.TabIndex = 122;
            this.lblSIPAmount.Text = "SIP Amount";
            // 
            // txtSIPAmount
            // 
            this.txtSIPAmount.BackColor = System.Drawing.SystemColors.Info;
            this.txtSIPAmount.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSIPAmount.Location = new System.Drawing.Point(497, 328);
            this.txtSIPAmount.Name = "txtSIPAmount";
            this.txtSIPAmount.ReadOnly = true;
            this.txtSIPAmount.Size = new System.Drawing.Size(265, 20);
            this.txtSIPAmount.TabIndex = 123;
            this.lblPhoneStatusToolTip.SetToolTip(this.txtSIPAmount, "Information. Cannot Modify.");
            // 
            // lblSIPDay
            // 
            this.lblSIPDay.AutoSize = true;
            this.lblSIPDay.BackColor = System.Drawing.SystemColors.Control;
            this.lblSIPDay.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSIPDay.Location = new System.Drawing.Point(401, 360);
            this.lblSIPDay.Name = "lblSIPDay";
            this.lblSIPDay.Size = new System.Drawing.Size(44, 14);
            this.lblSIPDay.TabIndex = 124;
            this.lblSIPDay.Text = "SIP Day";
            // 
            // txtsipday
            // 
            this.txtsipday.BackColor = System.Drawing.SystemColors.Info;
            this.txtsipday.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsipday.Location = new System.Drawing.Point(497, 357);
            this.txtsipday.Name = "txtsipday";
            this.txtsipday.ReadOnly = true;
            this.txtsipday.Size = new System.Drawing.Size(265, 20);
            this.txtsipday.TabIndex = 125;
            this.lblPhoneStatusToolTip.SetToolTip(this.txtsipday, "Information. Cannot Modify.");
            // 
            // lblcallremark
            // 
            this.lblcallremark.AutoSize = true;
            this.lblcallremark.BackColor = System.Drawing.SystemColors.Control;
            this.lblcallremark.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcallremark.Location = new System.Drawing.Point(402, 300);
            this.lblcallremark.Name = "lblcallremark";
            this.lblcallremark.Size = new System.Drawing.Size(69, 14);
            this.lblcallremark.TabIndex = 120;
            this.lblcallremark.Text = "Call Remarks";
            // 
            // txtcallremarks
            // 
            this.txtcallremarks.BackColor = System.Drawing.SystemColors.Info;
            this.txtcallremarks.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcallremarks.Location = new System.Drawing.Point(497, 299);
            this.txtcallremarks.Name = "txtcallremarks";
            this.txtcallremarks.ReadOnly = true;
            this.txtcallremarks.Size = new System.Drawing.Size(265, 20);
            this.txtcallremarks.TabIndex = 121;
            this.lblPhoneStatusToolTip.SetToolTip(this.txtcallremarks, "Information. Cannot Modify.");
            // 
            // lblpincode
            // 
            this.lblpincode.AutoSize = true;
            this.lblpincode.BackColor = System.Drawing.SystemColors.Control;
            this.lblpincode.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpincode.Location = new System.Drawing.Point(401, 244);
            this.lblpincode.Name = "lblpincode";
            this.lblpincode.Size = new System.Drawing.Size(49, 14);
            this.lblpincode.TabIndex = 116;
            this.lblpincode.Text = "Pin Code";
            // 
            // txtpincode
            // 
            this.txtpincode.BackColor = System.Drawing.SystemColors.Info;
            this.txtpincode.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpincode.Location = new System.Drawing.Point(497, 241);
            this.txtpincode.Name = "txtpincode";
            this.txtpincode.ReadOnly = true;
            this.txtpincode.Size = new System.Drawing.Size(265, 20);
            this.txtpincode.TabIndex = 117;
            this.lblPhoneStatusToolTip.SetToolTip(this.txtpincode, "Information. Cannot Modify.");
            // 
            // lblguardian
            // 
            this.lblguardian.AutoSize = true;
            this.lblguardian.BackColor = System.Drawing.SystemColors.Control;
            this.lblguardian.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblguardian.Location = new System.Drawing.Point(402, 272);
            this.lblguardian.Name = "lblguardian";
            this.lblguardian.Size = new System.Drawing.Size(81, 14);
            this.lblguardian.TabIndex = 118;
            this.lblguardian.Text = "Guardian Name";
            // 
            // txtguardian
            // 
            this.txtguardian.BackColor = System.Drawing.SystemColors.Info;
            this.txtguardian.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtguardian.Location = new System.Drawing.Point(497, 269);
            this.txtguardian.Name = "txtguardian";
            this.txtguardian.ReadOnly = true;
            this.txtguardian.Size = new System.Drawing.Size(265, 20);
            this.txtguardian.TabIndex = 119;
            this.lblPhoneStatusToolTip.SetToolTip(this.txtguardian, "Information. Cannot Modify.");
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 8.25F);
            this.label3.Location = new System.Drawing.Point(9, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 14);
            this.label3.TabIndex = 73;
            this.label3.Text = "Phone Number";
            // 
            // txtPhoneNumber
            // 
            this.txtPhoneNumber.BackColor = System.Drawing.SystemColors.Info;
            this.txtPhoneNumber.Font = new System.Drawing.Font("Arial", 8.25F);
            this.txtPhoneNumber.Location = new System.Drawing.Point(108, 12);
            this.txtPhoneNumber.Name = "txtPhoneNumber";
            this.txtPhoneNumber.ReadOnly = true;
            this.txtPhoneNumber.Size = new System.Drawing.Size(153, 20);
            this.txtPhoneNumber.TabIndex = 74;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(7, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(380, 2);
            this.label1.TabIndex = 77;
            // 
            // lblPAN
            // 
            this.lblPAN.AutoSize = true;
            this.lblPAN.BackColor = System.Drawing.SystemColors.Control;
            this.lblPAN.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPAN.Location = new System.Drawing.Point(11, 158);
            this.lblPAN.Name = "lblPAN";
            this.lblPAN.Size = new System.Drawing.Size(67, 14);
            this.lblPAN.TabIndex = 86;
            this.lblPAN.Text = "PAN Number";
            // 
            // txtPanNumber
            // 
            this.txtPanNumber.BackColor = System.Drawing.SystemColors.Info;
            this.txtPanNumber.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPanNumber.Location = new System.Drawing.Point(107, 159);
            this.txtPanNumber.Name = "txtPanNumber";
            this.txtPanNumber.ReadOnly = true;
            this.txtPanNumber.Size = new System.Drawing.Size(265, 20);
            this.txtPanNumber.TabIndex = 87;
            this.lblPhoneStatusToolTip.SetToolTip(this.txtPanNumber, "Information. Cannot Modify.");
            // 
            // lblmobile
            // 
            this.lblmobile.AutoSize = true;
            this.lblmobile.BackColor = System.Drawing.SystemColors.Control;
            this.lblmobile.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmobile.Location = new System.Drawing.Point(9, 187);
            this.lblmobile.Name = "lblmobile";
            this.lblmobile.Size = new System.Drawing.Size(77, 14);
            this.lblmobile.TabIndex = 88;
            this.lblmobile.Text = "Mobile Number";
            // 
            // txtmobileno
            // 
            this.txtmobileno.BackColor = System.Drawing.SystemColors.Info;
            this.txtmobileno.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmobileno.Location = new System.Drawing.Point(107, 187);
            this.txtmobileno.Name = "txtmobileno";
            this.txtmobileno.ReadOnly = true;
            this.txtmobileno.Size = new System.Drawing.Size(265, 20);
            this.txtmobileno.TabIndex = 89;
            this.lblPhoneStatusToolTip.SetToolTip(this.txtmobileno, "Information. Cannot Modify.");
            // 
            // txtphoneres
            // 
            this.txtphoneres.BackColor = System.Drawing.SystemColors.Info;
            this.txtphoneres.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtphoneres.Location = new System.Drawing.Point(107, 215);
            this.txtphoneres.Name = "txtphoneres";
            this.txtphoneres.ReadOnly = true;
            this.txtphoneres.Size = new System.Drawing.Size(265, 20);
            this.txtphoneres.TabIndex = 91;
            this.lblPhoneStatusToolTip.SetToolTip(this.txtphoneres, "Information. Cannot Modify.");
            // 
            // lblphoneres
            // 
            this.lblphoneres.AutoSize = true;
            this.lblphoneres.BackColor = System.Drawing.SystemColors.Control;
            this.lblphoneres.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblphoneres.Location = new System.Drawing.Point(11, 217);
            this.lblphoneres.Name = "lblphoneres";
            this.lblphoneres.Size = new System.Drawing.Size(59, 14);
            this.lblphoneres.TabIndex = 90;
            this.lblphoneres.Text = "Phone Res";
            // 
            // lblemail
            // 
            this.lblemail.AutoSize = true;
            this.lblemail.BackColor = System.Drawing.SystemColors.Control;
            this.lblemail.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblemail.Location = new System.Drawing.Point(11, 244);
            this.lblemail.Name = "lblemail";
            this.lblemail.Size = new System.Drawing.Size(31, 14);
            this.lblemail.TabIndex = 92;
            this.lblemail.Text = "Email";
            // 
            // txtemail
            // 
            this.txtemail.BackColor = System.Drawing.SystemColors.Info;
            this.txtemail.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtemail.Location = new System.Drawing.Point(106, 242);
            this.txtemail.Name = "txtemail";
            this.txtemail.ReadOnly = true;
            this.txtemail.Size = new System.Drawing.Size(265, 20);
            this.txtemail.TabIndex = 93;
            this.lblPhoneStatusToolTip.SetToolTip(this.txtemail, "Information. Cannot Modify.");
            // 
            // txtbrokercode
            // 
            this.txtbrokercode.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbrokercode.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtbrokercode.Location = new System.Drawing.Point(105, 271);
            this.txtbrokercode.MaxLength = 20;
            this.txtbrokercode.Name = "txtbrokercode";
            this.txtbrokercode.Size = new System.Drawing.Size(265, 20);
            this.txtbrokercode.TabIndex = 95;
            this.lblPhoneStatusToolTip.SetToolTip(this.txtbrokercode, "Editable Field");
            // 
            // lblBrokerCode
            // 
            this.lblBrokerCode.AutoSize = true;
            this.lblBrokerCode.BackColor = System.Drawing.SystemColors.Control;
            this.lblBrokerCode.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBrokerCode.Location = new System.Drawing.Point(9, 273);
            this.lblBrokerCode.Name = "lblBrokerCode";
            this.lblBrokerCode.Size = new System.Drawing.Size(64, 14);
            this.lblBrokerCode.TabIndex = 94;
            this.lblBrokerCode.Text = "BrokerCode";
            // 
            // lblIFSC
            // 
            this.lblIFSC.AutoSize = true;
            this.lblIFSC.BackColor = System.Drawing.SystemColors.Control;
            this.lblIFSC.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIFSC.Location = new System.Drawing.Point(402, 103);
            this.lblIFSC.Name = "lblIFSC";
            this.lblIFSC.Size = new System.Drawing.Size(57, 14);
            this.lblIFSC.TabIndex = 106;
            this.lblIFSC.Text = "IFSC Code";
            // 
            // txtIFSCCode
            // 
            this.txtIFSCCode.BackColor = System.Drawing.SystemColors.Info;
            this.txtIFSCCode.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIFSCCode.Location = new System.Drawing.Point(497, 101);
            this.txtIFSCCode.Multiline = true;
            this.txtIFSCCode.Name = "txtIFSCCode";
            this.txtIFSCCode.ReadOnly = true;
            this.txtIFSCCode.Size = new System.Drawing.Size(265, 22);
            this.txtIFSCCode.TabIndex = 107;
            this.lblPhoneStatusToolTip.SetToolTip(this.txtIFSCCode, "Information. Cannot Modify.");
            // 
            // pnlPopup
            // 
            this.pnlPopup.Controls.Add(this.tabControl1);
            this.pnlPopup.Controls.Add(this.lblCallDuration);
            this.pnlPopup.Controls.Add(this.txtIFSCCode);
            this.pnlPopup.Controls.Add(this.lblIFSC);
            this.pnlPopup.Controls.Add(this.lblBrokerCode);
            this.pnlPopup.Controls.Add(this.txtbrokercode);
            this.pnlPopup.Controls.Add(this.txtemail);
            this.pnlPopup.Controls.Add(this.lblemail);
            this.pnlPopup.Controls.Add(this.lblphoneres);
            this.pnlPopup.Controls.Add(this.txtphoneres);
            this.pnlPopup.Controls.Add(this.txtmobileno);
            this.pnlPopup.Controls.Add(this.lblmobile);
            this.pnlPopup.Controls.Add(this.txtPanNumber);
            this.pnlPopup.Controls.Add(this.lblPAN);
            this.pnlPopup.Controls.Add(this.label1);
            this.pnlPopup.Controls.Add(this.txtPhoneNumber);
            this.pnlPopup.Controls.Add(this.label3);
            this.pnlPopup.Controls.Add(this.txtguardian);
            this.pnlPopup.Controls.Add(this.lblguardian);
            this.pnlPopup.Controls.Add(this.txtpincode);
            this.pnlPopup.Controls.Add(this.lblpincode);
            this.pnlPopup.Controls.Add(this.txtcallremarks);
            this.pnlPopup.Controls.Add(this.lblcallremark);
            this.pnlPopup.Controls.Add(this.txtsipday);
            this.pnlPopup.Controls.Add(this.lblSIPDay);
            this.pnlPopup.Controls.Add(this.txtSIPAmount);
            this.pnlPopup.Controls.Add(this.lblSIPAmount);
            this.pnlPopup.Controls.Add(this.txtscheme);
            this.pnlPopup.Controls.Add(this.lblschemename);
            this.pnlPopup.Controls.Add(this.txtcity);
            this.pnlPopup.Controls.Add(this.lblcity);
            this.pnlPopup.Controls.Add(this.txtstate);
            this.pnlPopup.Controls.Add(this.lblstatename);
            this.pnlPopup.Controls.Add(this.pnlInbound);
            this.pnlPopup.Controls.Add(this.txtbranchname);
            this.pnlPopup.Controls.Add(this.lblbranchname);
            this.pnlPopup.Controls.Add(this.lblbankname);
            this.pnlPopup.Controls.Add(this.txtbankname);
            this.pnlPopup.Controls.Add(this.lblaccountnum);
            this.pnlPopup.Controls.Add(this.txtaccountnum);
            this.pnlPopup.Controls.Add(this.lblAmount);
            this.pnlPopup.Controls.Add(this.txtAmount);
            this.pnlPopup.Controls.Add(this.lblaccounttype);
            this.pnlPopup.Controls.Add(this.txtaccounttype);
            this.pnlPopup.Controls.Add(this.txtRemarks);
            this.pnlPopup.Controls.Add(this.lblCallComments);
            this.pnlPopup.Controls.Add(this.lbCallHistory);
            this.pnlPopup.Controls.Add(this.txtstatus);
            this.pnlPopup.Controls.Add(this.lbltax);
            this.pnlPopup.Controls.Add(this.lblSep7);
            this.pnlPopup.Controls.Add(this.lblSep6);
            this.pnlPopup.Controls.Add(this.lblSep5);
            this.pnlPopup.Controls.Add(this.lblSep4);
            this.pnlPopup.Controls.Add(this.txtInvestorName);
            this.pnlPopup.Controls.Add(this.lblInvestorName);
            this.pnlPopup.Controls.Add(this.txtFolioNumber);
            this.pnlPopup.Controls.Add(this.lblFolioNumber);
            this.pnlPopup.Controls.Add(this.txtSrNo);
            this.pnlPopup.Controls.Add(this.lblSrNo);
            this.pnlPopup.Controls.Add(this.lblCustInfo);
            this.pnlPopup.Location = new System.Drawing.Point(6, 9);
            this.pnlPopup.Name = "pnlPopup";
            this.pnlPopup.Size = new System.Drawing.Size(1179, 583);
            this.pnlPopup.TabIndex = 72;
            this.pnlPopup.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlPopup_Paint);
            // 
            // lblCallDuration
            // 
            this.lblCallDuration.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.lblCallDuration.ForeColor = System.Drawing.Color.Red;
            this.lblCallDuration.Location = new System.Drawing.Point(267, 12);
            this.lblCallDuration.Name = "lblCallDuration";
            this.lblCallDuration.Size = new System.Drawing.Size(106, 20);
            this.lblCallDuration.TabIndex = 76;
            this.lblCallDuration.Text = "00:00:00";
            this.lblCallDuration.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cmbSuggestion
            // 
            this.cmbSuggestion.BackColor = System.Drawing.SystemColors.Window;
            this.cmbSuggestion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSuggestion.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSuggestion.ForeColor = System.Drawing.SystemColors.WindowText;
            this.cmbSuggestion.FormattingEnabled = true;
            this.cmbSuggestion.Items.AddRange(new object[] {
            "",
            "Completed",
            "Pending"});
            this.cmbSuggestion.Location = new System.Drawing.Point(102, 173);
            this.cmbSuggestion.Name = "cmbSuggestion";
            this.cmbSuggestion.Size = new System.Drawing.Size(265, 22);
            this.cmbSuggestion.TabIndex = 140;
            this.lblPhoneStatusToolTip.SetToolTip(this.cmbSuggestion, "Editable Field");
            // 
            // lblSuggestion
            // 
            this.lblSuggestion.AutoSize = true;
            this.lblSuggestion.BackColor = System.Drawing.SystemColors.Control;
            this.lblSuggestion.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSuggestion.Location = new System.Drawing.Point(7, 175);
            this.lblSuggestion.Name = "lblSuggestion";
            this.lblSuggestion.Size = new System.Drawing.Size(61, 14);
            this.lblSuggestion.TabIndex = 139;
            this.lblSuggestion.Text = "Suggestion";
            // 
            // tabControl1
            // 
            this.tabControl1.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.tabControl1.Controls.Add(this.tpCallHist_Cust);
            this.tabControl1.Controls.Add(this.tpCallHist_Agent);
            this.tabControl1.Location = new System.Drawing.Point(88, 420);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1084, 152);
            this.tabControl1.TabIndex = 146;
            // 
            // tpCallHist_Cust
            // 
            this.tpCallHist_Cust.Controls.Add(this.dgvCallHistory);
            this.tpCallHist_Cust.Location = new System.Drawing.Point(23, 4);
            this.tpCallHist_Cust.Name = "tpCallHist_Cust";
            this.tpCallHist_Cust.Padding = new System.Windows.Forms.Padding(3);
            this.tpCallHist_Cust.Size = new System.Drawing.Size(1057, 144);
            this.tpCallHist_Cust.TabIndex = 0;
            this.tpCallHist_Cust.Text = "Customer";
            this.tpCallHist_Cust.UseVisualStyleBackColor = true;
            // 
            // dgvCallHistory
            // 
            this.dgvCallHistory.AllowUserToAddRows = false;
            this.dgvCallHistory.AllowUserToDeleteRows = false;
            this.dgvCallHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCallHistory.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CallDate,
            this.PhoneNo,
            this.Agent,
            this.CallDur,
            this.Disp,
            this.Remarks});
            this.dgvCallHistory.Location = new System.Drawing.Point(2, 1);
            this.dgvCallHistory.Name = "dgvCallHistory";
            this.dgvCallHistory.ReadOnly = true;
            this.dgvCallHistory.RowHeadersVisible = false;
            this.dgvCallHistory.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCallHistory.Size = new System.Drawing.Size(1054, 142);
            this.dgvCallHistory.TabIndex = 147;
            this.lblPhoneStatusToolTip.SetToolTip(this.dgvCallHistory, "Call History");
            // 
            // CallDate
            // 
            this.CallDate.DataPropertyName = "CallDate";
            this.CallDate.Frozen = true;
            this.CallDate.HeaderText = "Call Date";
            this.CallDate.Name = "CallDate";
            this.CallDate.ReadOnly = true;
            this.CallDate.Width = 150;
            // 
            // PhoneNo
            // 
            this.PhoneNo.DataPropertyName = "PhoneNo";
            this.PhoneNo.Frozen = true;
            this.PhoneNo.HeaderText = "Phone Number";
            this.PhoneNo.Name = "PhoneNo";
            this.PhoneNo.ReadOnly = true;
            this.PhoneNo.Width = 120;
            // 
            // Agent
            // 
            this.Agent.DataPropertyName = "Agent";
            this.Agent.Frozen = true;
            this.Agent.HeaderText = "Agent";
            this.Agent.Name = "Agent";
            this.Agent.ReadOnly = true;
            this.Agent.Width = 150;
            // 
            // CallDur
            // 
            this.CallDur.DataPropertyName = "CallDur";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.CallDur.DefaultCellStyle = dataGridViewCellStyle5;
            this.CallDur.Frozen = true;
            this.CallDur.HeaderText = "Call Duration";
            this.CallDur.Name = "CallDur";
            this.CallDur.ReadOnly = true;
            // 
            // Disp
            // 
            this.Disp.DataPropertyName = "Disp";
            this.Disp.Frozen = true;
            this.Disp.HeaderText = "Disposition";
            this.Disp.Name = "Disp";
            this.Disp.ReadOnly = true;
            this.Disp.Width = 150;
            // 
            // Remarks
            // 
            this.Remarks.DataPropertyName = "Remarks";
            this.Remarks.Frozen = true;
            this.Remarks.HeaderText = "Remarks";
            this.Remarks.Name = "Remarks";
            this.Remarks.ReadOnly = true;
            this.Remarks.Width = 350;
            // 
            // tpCallHist_Agent
            // 
            this.tpCallHist_Agent.Controls.Add(this.dgvAgentCallHist);
            this.tpCallHist_Agent.Location = new System.Drawing.Point(23, 4);
            this.tpCallHist_Agent.Name = "tpCallHist_Agent";
            this.tpCallHist_Agent.Padding = new System.Windows.Forms.Padding(3);
            this.tpCallHist_Agent.Size = new System.Drawing.Size(1057, 144);
            this.tpCallHist_Agent.TabIndex = 1;
            this.tpCallHist_Agent.Text = "Agent";
            this.tpCallHist_Agent.UseVisualStyleBackColor = true;
            // 
            // dgvAgentCallHist
            // 
            this.dgvAgentCallHist.AllowUserToAddRows = false;
            this.dgvAgentCallHist.AllowUserToDeleteRows = false;
            this.dgvAgentCallHist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAgentCallHist.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.dgvAgentCallHist.Location = new System.Drawing.Point(1, 1);
            this.dgvAgentCallHist.Name = "dgvAgentCallHist";
            this.dgvAgentCallHist.ReadOnly = true;
            this.dgvAgentCallHist.RowHeadersVisible = false;
            this.dgvAgentCallHist.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAgentCallHist.Size = new System.Drawing.Size(1054, 142);
            this.dgvAgentCallHist.TabIndex = 148;
            this.lblPhoneStatusToolTip.SetToolTip(this.dgvAgentCallHist, "Call History");
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "CallDate";
            this.dataGridViewTextBoxColumn1.Frozen = true;
            this.dataGridViewTextBoxColumn1.HeaderText = "Call Date";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 150;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "PhoneNo";
            this.dataGridViewTextBoxColumn2.Frozen = true;
            this.dataGridViewTextBoxColumn2.HeaderText = "Phone Number";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 120;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Agent";
            this.dataGridViewTextBoxColumn3.Frozen = true;
            this.dataGridViewTextBoxColumn3.HeaderText = "Agent";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 150;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "CallDur";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridViewTextBoxColumn4.Frozen = true;
            this.dataGridViewTextBoxColumn4.HeaderText = "Call Duration";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Disp";
            this.dataGridViewTextBoxColumn5.Frozen = true;
            this.dataGridViewTextBoxColumn5.HeaderText = "Disposition";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 150;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Remarks";
            this.dataGridViewTextBoxColumn6.Frozen = true;
            this.dataGridViewTextBoxColumn6.HeaderText = "Remarks";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 350;
            // 
            // FToolbar
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(1194, 724);
            this.Controls.Add(this.pnlCallback);
            this.Controls.Add(this.cmbDisp);
            this.Controls.Add(this.tcCallDetails);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.btnDispose);
            this.Controls.Add(this.lblBottomBar);
            this.Controls.Add(this.cmbDispDesc);
            this.Controls.Add(this.lblDisposition);
            this.Font = new System.Drawing.Font("Arial", 8.25F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FToolbar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Agent Toolbar";
            this.Load += new System.EventHandler(this.FToolbar_Load);
            this.pnlState.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.tcCallDetails.ResumeLayout(false);
            this.tpCDD.ResumeLayout(false);
            this.tpCDD.PerformLayout();
            this.tpPopup.ResumeLayout(false);
            this.pnlCallback.ResumeLayout(false);
            this.pnlCallback.PerformLayout();
            this.pnlInbound.ResumeLayout(false);
            this.pnlInbound.PerformLayout();
            this.pnlPopup.ResumeLayout(false);
            this.pnlPopup.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tpCallHist_Cust.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCallHistory)).EndInit();
            this.tpCallHist_Agent.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAgentCallHist)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private void FToolbar_Load(object sender, System.EventArgs e)
        {
            tmrCallDuration.Enabled = false;

            txtbrokercode.BackColor = Color.FromArgb(58, 110, 165);
            txtbrokercode.ForeColor = Color.White;
            cmbLanguage.BackColor = Color.FromArgb(58, 110, 165);
            cmbLanguage.ForeColor = Color.White;
            cmbQuery.BackColor = Color.FromArgb(58, 110, 165);
            cmbQuery.ForeColor = Color.White;
            cmbCallCategory.BackColor = Color.FromArgb(58, 110, 165);
            cmbCallCategory.ForeColor = Color.White;
            cmbCallerType.BackColor = Color.FromArgb(58, 110, 165);
            cmbCallerType.ForeColor = Color.White;
            cmbCurrentStatus.BackColor = Color.FromArgb(58, 110, 165);
            cmbCurrentStatus.ForeColor = Color.White;
            txtRemarks.BackColor = Color.FromArgb(58, 110, 165);
            txtRemarks.ForeColor = Color.White;

            tmrAssignedServices.Enabled = false;
            try
            {
                logContent = PadDateCrLf("Login Successful. Loading Toolbar");
                logContent += PadDateCrLf("    Agent ID                        : " + mpApp.CurrentAgent.AgentId);
                logContent += PadDateCrLf("    Agent Index                     : " + mpApp.CurrentAgent.AgentIndex);
                logContent += PadDateCrLf("    Agent Name                      : " + (mpApp.CurrentAgent.FirstName + " " + mpApp.CurrentAgent.LastName).Trim());
                logContent += PadDateCrLf("    Agent Type                      : " + mpApp.CurrentAgent.AgentType);
                logContent += PadDateCrLf("    Allow 3Way                      : " + mpApp.CurrentAgent.Allow3Way);
                logContent += PadDateCrLf("    Allow Blink Xfer                : " + mpApp.CurrentAgent.AllowBlindXfer);
                logContent += PadDateCrLf("    Allow Conference                : " + mpApp.CurrentAgent.AllowConference);
                logContent += PadDateCrLf("    Allow Consult                   : " + mpApp.CurrentAgent.AllowConsult);
                logContent += PadDateCrLf("    Allow Consult Hangup            : " + mpApp.CurrentAgent.AllowConsultHangup);
                logContent += PadDateCrLf("    Allow Dial                      : " + mpApp.CurrentAgent.AllowDial);
                logContent += PadDateCrLf("    Allow Hangup                    : " + mpApp.CurrentAgent.AllowHangup);
                logContent += PadDateCrLf("    Allow Hold                      : " + mpApp.CurrentAgent.AllowHold);
                logContent += PadDateCrLf("    Allow Next Call                 : " + mpApp.CurrentAgent.AllowNextCall);
                logContent += PadDateCrLf("    Allow PARK                      : " + mpApp.CurrentAgent.AllowPark);
                logContent += PadDateCrLf("    Allow Play                      : " + mpApp.CurrentAgent.AllowPlay);
                logContent += PadDateCrLf("    Allow Record                    : " + mpApp.CurrentAgent.AllowRecord);
                logContent += PadDateCrLf("    Allow Self Callbacks            : " + mpApp.CurrentAgent.AllowSelfCallbacks);
                logContent += PadDateCrLf("    Allow Warm Xfer                 : " + mpApp.CurrentAgent.AllowWarmXfer);
                logContent += PadDateCrLf("    No Disp Max Wrap Secs           : " + mpApp.CurrentAgent.NoDispMaxWrapSecs);
                logContent += PadDateCrLf("    Park Alarm Secs                 : " + mpApp.CurrentAgent.ParkAlarmSecs);
                logContent += PadDateCrLf("    Require Disposition             : " + mpApp.CurrentAgent.RequireDisposition);
                logContent += PadDateCrLf("    Require Service For Manual Dial : " + mpApp.CurrentAgent.RequireServiceForManualDial);
                logContent += PadDateCrLf("    Require Wrap                    : " + mpApp.CurrentAgent.RequireWrap);
                logContent += PadDateCrLf("    Show Call Data                  : " + mpApp.CurrentAgent.ShowCallData);

                logContent += PadDateCrLf("Registering for State Change Event");
                mpApp.StateChange += new StateChangeHandler(this.CApp_StateChange);
                logContent += PadDateCrLf("Registering for Unfocused Call State Change Event");
                mpApp.UnfocusedCallStateChange += new UnfocusedCallStateChangeHandler(mpApp_UnfocusedCallStateChange);
                logContent += PadDateCrLf("Registering for Unfocused State Change Event");
                mpApp.UnfocusedStateChange += new UnfocusedStateChangeHandler(mpApp_UnfocusedStateChange);
                logContent += PadDateCrLf("Registering for Screenpop Data Arrival Event");
                mpApp.Screenpop += new ScreenpopHandler(this.CApp_Screenpop);
                logContent += PadDateCrLf("Registering for Passcode Event");
                mpApp.Passcode += new PasscodeHandler(this.CApp_Passcode);
                logContent += PadDateCrLf("Registering for Logour Pending Event");
                mpApp.LogoutPending += new LogoutPendingHandler(this.CApp_LogoutPending);
                logContent += PadDateCrLf("Registerting for Call State Chagne Event");
                mpApp.CallStateChange += new CallStateChangeHandler(this.CApp_CallStateChange);
                logContent += PadDateCrLf("Registering for Phone Status");
                mpApp.PhoneStatus += new PhoneStatusHandler(this.CApp_PhoneStatus);
                logContent += PadDateCrLf("Registering to Error Event");
                mpApp.Error += new ErrorHandler(this.CApp_Error);
                logContent += PadDateCrLf("Registering for Logged In Event");
                mpApp.LoggedIn += new LoggedInHandler(this.CApp_LoggedIn);

                pnlState.Visible = false;
                lblMessage.Visible = false;

                //btnReady.Left = this.Width - btnReady.Width - 6;
                //pnlState.Left = this.Width - pnlState.Width;
                //lblMessage.Left = btnLogout.Left + btnLogout.Width + 20;
                //lblMessage.Width = this.Width - lblMessage.Left;

                //this.TopMost = true;

                //gbBanking.Top = (this.Height - tabBrowser.Top - 30 - gbBanking.Height) / 2;
                //gbBanking.Left = 10;// (this.Width - gbBanking.Width) / 2;
                //gbCreditCard.Top = (this.Height - tabBrowser.Top - 30 - gbCreditCard.Height) / 2;
                //gbCreditCard.Left = 10;// (this.Width - gbCreditCard.Width) / 2;

                idleCnt = 0;

                DoubleBuffered = true;



                //browserServiceFirst.Url = new Uri(Properties.Settings.Default.URL_ServiceFirst);
                //browserCTS.Url = new Uri(Properties.Settings.Default.URL_CTS);

                //ChromeDriverService cds = ChromeDriverService.CreateDefaultService(Application.StartupPath);
                //cds.HideCommandPromptWindow = true;
                //driver = new ChromeDriver(cds, new ChromeOptions());
                //Uri sUrl = new Uri(Properties.Settings.Default.crmNextLoginURL);
                //driver.Url = sUrl.ToString();

                //ws_InsChatHistory.Service wc = new ws_InsChatHistory.Service();
                //DataSet ds = wc.GetSubDisposition();
                //cmbSubDisposition.DataSource = ds.Tables[0];
                //cmbSubDisposition.DisplayMember = "SubDisposition_Description";
                //cmbSubDisposition.ValueMember = "SubDisposition_Code";

                //Code added by AMD on 28th Jun 217
                this.StartPosition = FormStartPosition.CenterScreen;
                btnReady_Click(null, null);
                tcCallDetails.SelectedTab = tcCallDetails.TabPages[0];
                txtAgentID.Text = mpApp.CurrentAgent.AgentId;
                txtAgentName.Text = (mpApp.CurrentAgent.FirstName + " " + mpApp.CurrentAgent.LastName).Trim();
                //End
                //Code added by AMD on 1st Jul 2017
                pnlCallback.Enabled = false;
                //End
                fillLanguage();
                fillRemarks();
            }
            catch (Exception ex)
            {
                logContent += PadDateCrLf("Error : " + ex.Message);
                MessageBox.Show("Error :" + ex.Message);
            }
            finally
            {
                WriteLog(mpApp.CurrentAgent.AgentId, logContent);
            }
        }

        void mpApp_UnfocusedStateChange(object pSender, CUnfocusedStateChangeArgs pArgs)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new UnfocusedStateChangeHandler(this.mpApp_UnfocusedStateChange), new Object[] { pSender, pArgs });
                return;
            }

            WriteLog(mpApp.CurrentAgent.AgentId, PadDateCrLf("Unfocused State Change"));
            handleStateChange(pArgs);
        }

        void mpApp_UnfocusedCallStateChange(object pSender, CUnfocusedCallStateChangeArgs pArgs)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new UnfocusedCallStateChangeHandler(this.mpApp_UnfocusedCallStateChange), new Object[] { pSender, pArgs });
                return;
            }
            handleCallStateChange(pArgs);
        }

        private void handleCallStateChange(CCallStateChangeArgs pArgs)
        {
            try
            {
                logContent = PadDateCrLf("Unfocused Call State Change");
                CState pNewState = pArgs.NewState;
                lblState.Text = pNewState.Description;
                lblState.BackColor = pNewState.BackColor;
                lblState.ForeColor = pNewState.ForeColor;
                logContent += PadDateCrLf("   State : " + pNewState.Description);
            }
            catch (Exception ex)
            {
                logContent += PadDateCrLf("Error : " + ex.Message);
            }
            finally
            {
                WriteLog(mpApp.CurrentAgent.AgentId, logContent);
            }
        }

        private void showAssignedServices()
        {
            //lstAssignedServices.Items.Clear();
            //for (int i=0; i<mpApp.AssignedServices.Count; i++)
            //{
            //    lstAssignedServices.Items.Add(mpApp.AssignedServices[i].ServiceName);
            //}
        }

        private void handleStateChange(CStateChangeArgs pArgs)
        {
            try
            {
                logContent = PadDateCrLf("    State : " + pArgs.NewState.Description);
                //This is the main thread. Update the UI.
                CState pNewState = pArgs.NewState;
                //lblState.Text = pNewState.Description;
                //lblState.BackColor = pNewState.BackColor;
                //lblState.ForeColor = pNewState.ForeColor;
                //lblState.Text = pNewState.Description;
                //lblState.BackColor = pNewState.BackColor;
                //lblState.ForeColor = pNewState.ForeColor;

                //if (mpApp.CurrentCall != null && mpApp.CurrentCall.CallType == AgentCallType.acCHAT)
                //{
                //    lblStateChat.Text = pNewState.Description;
                //    lblStateChat.BackColor = pNewState.BackColor;
                //    lblStateChat.ForeColor = pNewState.ForeColor;
                //}
                //else
                //{

                //}
                if (pArgs.NewState is CCallState)
                {
                    CCallState callState = pArgs.NewState as CCallState;
                    if (callState.Call != null)
                    {
                        if (callState.Call is CCallVoice)
                        {
                            lblState.Text = pNewState.Description;
                            lblState.BackColor = pNewState.BackColor;
                            lblState.ForeColor = pNewState.ForeColor;
                        }
                        else if (callState.Call is CCallChat)
                        {
                            //lblStateChat.Text = pNewState.Description;
                            //lblStateChat.BackColor = pNewState.BackColor;
                            //lblStateChat.ForeColor = pNewState.ForeColor;
                        }
                    }
                }
                else if (pArgs.NewState is CState)
                {
                    lblState.Text = pNewState.Description;
                    lblState.BackColor = pNewState.BackColor;
                    lblState.ForeColor = pNewState.ForeColor;
                }
                btnHangup.Enabled = pNewState.EnableHangup;
                btnDial.Enabled = pNewState.EnableDial;
                btnHold.Enabled = pNewState.EnableHold;
                btn3Way.Enabled = pNewState.Enable3Way;
                btnRecord.Enabled = pNewState.EnableRecord;
                btnNextCall.Enabled = pNewState.EnableNextCall;
                btnLogout.Enabled = pNewState.EnableLogout;

                //btnCallInfo.Enabled = false;

                //btnAvailable.Enabled = pNewState.EnableAvailable;
                btnAvailable.Enabled = false;
                //if (btnAvailable.Enabled)
                //    btnUnavailable.SendToBack();

                //btnUnavailable.Enabled = pNewState.EnableUnavailable;
                btnUnavailable.Enabled = true;
                if (btnUnavailable.Enabled)
                    btnAvailable.SendToBack();

                switch (pArgs.NewState.Id)
                {
                    case AgentStateId.asIDLE:
                        //lblStateChat.BackColor = SystemColors.Control;
                        //lblStateChat.Text = "";
                        clearData();
                        callStartDtAssigned = "F";
                        tmrAssignedServices.Interval = 1000;
                        tmrAssignedServices.Enabled = false;

                        if (idleCnt == 0)
                        {
                            //CNotReadyReason oReason = new CNotReadyReason(0, "[None]");
                            //mpApp.BecomeUnavailable(oReason, false);
                            idleCnt = 1;
                        }
                        break;

                    case AgentStateId.asLOGGED_OUT:
                        //driver.Quit();
                        if (mpUnloadTimer == null)
                        {   //Start timer that fires every second 
                            System.Threading.TimerCallback timerDelegate = new System.Threading.TimerCallback(mpUnloadTimer_Fire);
                            mpUnloadTimer = new System.Threading.Timer(timerDelegate, this, 100, 1000);
                        }
                        Application.ExitThread();
                        break;

                    case AgentStateId.asACTIVE:
                        tmrCallDuration.Interval = 1000;
                        tmrCallDuration.Enabled = true;

                        btnHold.Text = "Hold";
                        if (chat == true)
                        {
                            mpApp.setstartrecording();
                        }
                        //btnCallInfo.Enabled = true;
                        break;

                    case AgentStateId.asHELD:
                        btnHold.Text = "Pick up";
                        break;

                    case AgentStateId.asCHATTING:
                        btnDial.Enabled = true;
                        chat = true;
                        LoadChatWindow();
                        //if (Rechat == true)
                        //{
                        //    //do not need again load chat window
                        //}
                        //else
                        //{

                        //}
                        break;

                    case AgentStateId.asINACTIVE:
                        //if (mpApp.CurrentCall.CallType == AgentCallType.acCHAT)
                        //UnloadChatWindow();
                        break;

                    case AgentStateId.asWRAP:
                        try
                        {
                            if (mpApp.CurrentCall.CallType == AgentCallType.acACD && Basic_CRM.Properties.Settings.Default["AutoDispInb"].ToString() == "T")
                            {
                                tmrAutoDisp.Interval = 1000;
                                tmrAutoDisp.Enabled = true;
                            }
                            else if (mpApp.CurrentCall.CallType == AgentCallType.acAOD && Basic_CRM.Properties.Settings.Default["AutoDispOb"].ToString() == "T")
                            {
                                tmrAutoDisp.Interval = 1000;
                                tmrAutoDisp.Enabled = true;
                            }
                            else if (mpApp.CurrentCall.CallType == 0 && Basic_CRM.Properties.Settings.Default["AutoDispOb"].ToString() == "T")
                            {
                                tmrAutoDisp.Interval = 1000;
                                tmrAutoDisp.Enabled = true;
                            }
                        }
                        catch (Exception ex)
                        {

                        }
                        //if (chat == false)
                        //{

                        //}
                        chat = false;
                        //UnloadChatWindow();
                        if (mpApp.CurrentService.RequireDisposition)
                        {
                            cmbDispDesc.Items.Clear();
                            cmbDisp.Items.Clear();
                            for (int i = 0; i < mpApp.CurrentService.DispositionPlan.Dispositions.Count; i++)
                            {
                                //mpApp.CurrentService.DispositionPlan.Dispositions[0].Id
                                cmbDispDesc.Items.Add(mpApp.CurrentService.DispositionPlan.Dispositions[i].Description);
                                cmbDisp.Items.Add(mpApp.CurrentService.DispositionPlan.Dispositions[i]);
                            }
                            cmbDispDesc.Enabled = true;
                            btnDispose.Enabled = true;
                        }
                        break;

                    case AgentStateId.asPREVIEW:
                        //    //Logcontent = Logcontent + System.DateTime.Now.ToString("dd-MMM-yyyy HH:mm:ss.fff") + " : Agent Preview :" + DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss tt") + Environment.NewLine;
                        //    mpApp.Dial(mpApp.CurrentCall.PhoneNumber, mpApp.CurrentCall.ServiceID, 0);
                        if (mpApp.CurrentService.RequireDisposition)
                        {
                            cmbDispDesc.Items.Clear();
                            cmbDisp.Items.Clear();
                            for (int i = 0; i < mpApp.CurrentService.DispositionPlan.Dispositions.Count; i++)
                            {
                                //mpApp.CurrentService.DispositionPlan.Dispositions[0].Id
                                cmbDispDesc.Items.Add(mpApp.CurrentService.DispositionPlan.Dispositions[i].Description);
                                cmbDisp.Items.Add(mpApp.CurrentService.DispositionPlan.Dispositions[i]);
                            }
                            cmbDispDesc.Enabled = true;
                            btnDispose.Enabled = true;
                        }
                        if (Basic_CRM.Properties.Settings.Default["TP"].ToString() == "T")
                        {
                            tmrPreview.Interval = 1000;
                            tmrPreview.Enabled = true;
                        }
                        break;

                    case AgentStateId.asNOT_READY:
                        //MessageBox.Show(convertSS_HHMMSS(12345));
                        //txtLead_SrNo.Text = "1";
                        //PopupDataFromDB();
                        clearData();
                        btnAvailable.Enabled = true;
                        btnUnavailable.Enabled = false;
                        if (btnAvailable.Enabled)
                            btnUnavailable.SendToBack();
                        break;

                    case AgentStateId.asPARKED:
                        //MessageBox.Show(convertSS_HHMMSS(12345));
                        //txtLead_SrNo.Text = "1";
                        //PopupDataFromDB();
                        clearData();
                        btnAvailable.Enabled = true;
                        btnUnavailable.Enabled = false;
                        if (btnAvailable.Enabled)
                            btnUnavailable.SendToBack();
                        break;

                    default:
                        break;
                }
            }
            catch (Exception pError)
            {
                Console.WriteLine(pError.StackTrace);
                logContent = PadDateCrLf("Error : " + pError.Message);
                MessageBox.Show("Error :" + pError.StackTrace);
            }
            finally
            {
                WriteLog(mpApp.CurrentAgent.AgentId, logContent);
            }
        }

        public void CApp_StateChange(Object pSender, CStateChangeArgs pArgs)
        {
            //Form updates can/should only be performed by the thread that created the form (in this case, the main thread).
            //If this is not the main thread then invoke this method on the main thread and return.
            if (this.InvokeRequired)
            {
                this.Invoke(new StateChangeHandler(this.CApp_StateChange), new Object[] { pSender, pArgs });
                return;
            }

            WriteLog(mpApp.CurrentAgent.AgentId, PadDateCrLf("State Change"));
            handleStateChange(pArgs);
        }

        private void LoadChatWindow()
        {
            FChat pChatWindow;

            try
            {
                //Show the chat dialog associated with the current chat call
                if (moCallWindows.ContainsKey(mpApp.CurrentCall.CallID))
                {
                    pChatWindow = (FChat)moCallWindows[mpApp.CurrentCall.CallID];
                }
                else
                {
                    pChatWindow = new FChat(mpApp, (CCallChat)mpApp.CurrentCall);
                    moCallWindows.Add(mpApp.CurrentCall.CallID, pChatWindow);
                    pChatWindow.Show(this);
                    //Rechat = true;
                }
            }
            catch (Exception pError)
            {
                Console.WriteLine(pError.StackTrace);
                //MessageBox.Show("Error :" + pError.StackTrace);
                // Logcontent = Logcontent + System.DateTime.Now.ToString("dd-MMM-yyyy HH:mm:ss.fff") + " : Load Chat Window Error :" + pError.Message + Environment.NewLine;
            }
        }

        private void UnloadChatWindow()
        {
            FChat pChatWindow;

            try
            {
                //Show the chat dialog associated with the current chat call
                if (moCallWindows.ContainsKey(mpApp.CurrentCall.CallID))
                {
                    pChatWindow = (FChat)moCallWindows[mpApp.CurrentCall.CallID];

                    moCallWindows.Remove(mpApp.CurrentCall.CallID);

                    pChatWindow.Close();
                }
            }
            catch (Exception pError)
            {
                Console.WriteLine(pError.StackTrace);
                MessageBox.Show("Error :" + pError.StackTrace);
            }
        }

        public void CApp_LoggedIn(Object pSender)
        {
            //Form updates can/should only be performed by the thread that created the form (in this case, the main thread).
            //If this is not the main thread then invoke this method on the main thread and return.
            if (this.InvokeRequired)
            {
                this.Invoke(new LoggedInHandler(this.CApp_LoggedIn), new Object[] { pSender });
                return;
            }

            WriteLog(mpApp.CurrentAgent.AgentId, PadDateCrLf("Loggedin"));

            //Clear any message remaining on the toolbar
            ClearMessage();
        }

        private void mpUnloadTimer_Fire(Object state)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new System.Threading.TimerCallback(this.mpUnloadTimer_Fire), new Object[] { state });
                return;
            }

            //If there are no messages being shown, close the form. Otherwise, wait.
            if (mpMessageTimer == null)
            {
                mpUnloadTimer.Dispose();
                mpUnloadTimer = null;
                this.Close();
            }
        }

        //Toolbar's hangup and hold commands should reflect state of FirstParty call
        public void CApp_CallStateChange(Object pSender, CCallStateChangeArgs pArgs)
        {
            //Form updates can/should only be performed by the thread that created the form (in this case, the main thread).
            //If this is not the main thread then invoke this method on the main thread and return.
            if (this.InvokeRequired)
            {
                this.Invoke(new CallStateChangeHandler(this.CApp_CallStateChange), new Object[] { pSender, pArgs });
                return;
            }

            //This is the main thread. Update the UI.
            if (pArgs.Call is C3WayCall1stParty)
            {
                btnHold.Enabled = pArgs.Call.CurrentState.EnableHold;
                btnHangup.Enabled = pArgs.Call.CurrentState.EnableHangup;
                btnHold.Text = (pArgs.Call.CurrentState is CStateHeld ? "Pick Up" : "Hold");
            }

            handleCallStateChange(pArgs);
        }

        public void CApp_Screenpop(Object pSender, CScreenpopArgs pArgs)
        {
            try
            {
                this.TopMost = true;
                this.TopMost = false;

                //Code for Call Popup goes here
                if (this.InvokeRequired)
                {
                    this.Invoke(new ScreenpopHandler(this.CApp_Screenpop), new object[] { pSender, pArgs });
                    return;
                }

               
                logContent = PadDateCrLf("Screenpop Data Arrival");
                logContent += PadDateCrLf("    Service ID     : " + pArgs.Call.ServiceID);
                if (pArgs.Call.CallType == AgentCallType.acACD)
                {
                    txtPhoneNumber.Text = pArgs.Call.Ani;
                    lblMessage.Text = "Inbound Call (" + mpApp.AssignedServices.GetByKey(pArgs.Call.ServiceID).ServiceName + ")";
                }
                else if (pArgs.Call.CallType == AgentCallType.acAOD)
                {
                    txtPhoneNumber.Text = pArgs.Call.PhoneNumber;
                    lblMessage.Text = "Outbound Call (" + mpApp.AssignedServices.GetByKey(pArgs.Call.ServiceID).ServiceName + ")";
                }
                logContent += PadDateCrLf("    Phone Number   : " + txtPhoneNumber.Text);
                logContent += PadDateCrLf("    DNIS           : " + pArgs.Call.Dnis);
                logContent += PadDateCrLf("    Cbk Requested  : " + pArgs.Call.CallbackRequested);
                logContent += PadDateCrLf("    Call Category  : " + pArgs.Call.CallCategory);
                logContent += PadDateCrLf("    Call ID        : " + pArgs.Call.CallID);
                logContent += PadDateCrLf("    Call Type      : " + pArgs.Call.CallType);
                logContent += PadDateCrLf("    Event Code     : " + pArgs.Call.EventCode);
                logContent += PadDateCrLf("    Exc Requested  : " + pArgs.Call.ExclusionRequested);
                logContent += PadDateCrLf("    1st Party Call : " + pArgs.Call.FirstPartyCall);
                logContent += PadDateCrLf("    PlayAudioAlert : " + pArgs.Call.PlayAudioAlert);
                logContent += PadDateCrLf("    Rej Reason Req : " + pArgs.Call.RejectionReasonRequired);
                for (int i = 0; i < 20; i++)
                {
                    logContent += PadDateCrLf("    UDF" + (i + 1).ToString("00") + "        : " + pArgs.Call.UserDefinedItems[i].key + " - " + pArgs.Call.UserDefinedItems[i].value);
                }
                //End

               
                lblUDF1.Text = pArgs.Call.UserDefinedItems[0].key;
                lblUDF2.Text = pArgs.Call.UserDefinedItems[1].key;
                lblUDF3.Text = pArgs.Call.UserDefinedItems[2].key;
                lblUDF4.Text = pArgs.Call.UserDefinedItems[3].key;
                lblUDF5.Text = pArgs.Call.UserDefinedItems[4].key;
                lblUDF6.Text = pArgs.Call.UserDefinedItems[5].key;
                lblUDF7.Text = pArgs.Call.UserDefinedItems[6].key;
                lblUDF8.Text = pArgs.Call.UserDefinedItems[7].key;
                lblUDF9.Text = pArgs.Call.UserDefinedItems[8].key;
                lblUDF10.Text = pArgs.Call.UserDefinedItems[9].key;
                lblUDF11.Text = pArgs.Call.UserDefinedItems[10].key;
                lblUDF12.Text = pArgs.Call.UserDefinedItems[11].key;
                lblUDF13.Text = pArgs.Call.UserDefinedItems[12].key;
                lblUDF14.Text = pArgs.Call.UserDefinedItems[13].key;
                lblUDF15.Text = pArgs.Call.UserDefinedItems[14].key;
                lblUDF16.Text = pArgs.Call.UserDefinedItems[15].key;
                lblUDF17.Text = pArgs.Call.UserDefinedItems[16].key;
                lblUDF18.Text = pArgs.Call.UserDefinedItems[17].key;
                lblUDF19.Text = pArgs.Call.UserDefinedItems[18].key;
                lblUDF20.Text = pArgs.Call.UserDefinedItems[19].key;

                txtUDF1.Text = pArgs.Call.UserDefinedItems[0].value;
                txtUDF2.Text = pArgs.Call.UserDefinedItems[1].value;
                txtUDF3.Text = pArgs.Call.UserDefinedItems[2].value;
                txtUDF4.Text = pArgs.Call.UserDefinedItems[3].value;
                txtUDF5.Text = pArgs.Call.UserDefinedItems[4].value;
                txtUDF6.Text = pArgs.Call.UserDefinedItems[5].value;
                txtUDF7.Text = pArgs.Call.UserDefinedItems[6].value;
                txtUDF8.Text = pArgs.Call.UserDefinedItems[7].value;
                txtUDF9.Text = pArgs.Call.UserDefinedItems[8].value;
                txtUDF10.Text = pArgs.Call.UserDefinedItems[9].value;
                txtUDF11.Text = pArgs.Call.UserDefinedItems[10].value;
                txtUDF12.Text = pArgs.Call.UserDefinedItems[11].value;
                txtUDF13.Text = pArgs.Call.UserDefinedItems[12].value;
                txtUDF14.Text = pArgs.Call.UserDefinedItems[13].value;
                txtUDF15.Text = pArgs.Call.UserDefinedItems[14].value;
                txtUDF16.Text = pArgs.Call.UserDefinedItems[15].value;
                txtUDF17.Text = pArgs.Call.UserDefinedItems[16].value;
                txtUDF18.Text = pArgs.Call.UserDefinedItems[17].value;
                txtUDF19.Text = pArgs.Call.UserDefinedItems[18].value;
                txtUDF20.Text = pArgs.Call.UserDefinedItems[19].value;

                txtServiceID.Text = pArgs.Call.ServiceID.ToString();
                txtServiceName.Text = mpApp.AssignedServices.GetByKey(pArgs.Call.ServiceID).ServiceName;
                txtDNIS.Text = pArgs.Call.Dnis;
                callStartDt = DateTime.Now;
                callStartDtAssigned = "T";

                txtSrNo.Text = pArgs.Call.UserDefinedItems[0].value;
                txtFolioNumber.Text = pArgs.Call.UserDefinedItems[1].value;
                txtInvestorName.Text = pArgs.Call.UserDefinedItems[2].value;             
                txtstatus.Text = pArgs.Call.UserDefinedItems[4].value;
                txtemail.Text = pArgs.Call.UserDefinedItems[5].value;               
                txtmobileno.Text = pArgs.Call.UserDefinedItems[6].value;
                txtphoneres.Text = pArgs.Call.UserDefinedItems[7].value;
                txtAmount.Text = pArgs.Call.UserDefinedItems[8].value;
                txtaccountnum.Text = pArgs.Call.UserDefinedItems[9].value;
                txtaccounttype.Text = pArgs.Call.UserDefinedItems[10].value;
                txtbankname.Text = pArgs.Call.UserDefinedItems[11].value;
                txtbranchname.Text = pArgs.Call.UserDefinedItems[12].value;
                txtIFSCCode.Text = pArgs.Call.UserDefinedItems[13].value;
                txtstate.Text = pArgs.Call.UserDefinedItems[14].value;
                txtcity.Text = pArgs.Call.UserDefinedItems[15].value;
                txtscheme.Text = pArgs.Call.UserDefinedItems[16].value;
                txtSIPAmount.Text = pArgs.Call.UserDefinedItems[17].value;
                txtsipday.Text = pArgs.Call.UserDefinedItems[18].value;
                cmbLanguage.Text = pArgs.Call.UserDefinedItems[19].value;

                tcCallDetails.SelectedTab = tcCallDetails.TabPages[1];


                try
                {
                    WriteLog(mpApp.CurrentAgent.AgentId, logContent);
                }
                catch (Exception ex)
                {
                    //Do Nothing
                }

                PopupDataFromDB();

                popupAgentCallHist();
                //End
            }
            catch (Exception ex)
            {
            }
            finally
            {
            }
        }

        private void PopupDataFromDB()
        {
            try
            {
                logContent = PadDateCrLf("Populate Data from CRM DB");
                logContent += PadDateCrLf("    Service ID : " + txtServiceID.Text);
                logContent += PadDateCrLf("    Lead SrNo  : " + txtSrNo.Text);

                if(txtSrNo.Text.Trim() != "")
                {
                    String qry = "select *, DATEDIFF(second, CallStartDt1, CallEndDt1) as CallDur1";
                    qry += ", DATEDIFF(second, CallStartDt2, CallEndDt2) as CallDur2";
                    qry += ", DATEDIFF(second, CallStartDt3, CallEndDt3) as CallDur3";
                    qry += ", DATEDIFF(second, CallStartDt4, CallEndDt4) as CallDur4";
                    qry += ", DATEDIFF(second, CallStartDt5, CallEndDt5) as CallDur5";
                    qry += " from CRM_Data with (NOLOCK) where SrNo='" + txtSrNo.Text + "'";

                    logContent += PadDateCrLf("Query : " + qry);

                    DataSet ds = ExecuteDataSet(Basic_CRM.Properties.Settings.Default["ConnStr"].ToString(), qry);

                    logContent += PadDateCrLf("Result : " + ds.Tables[0].Rows.Count);

                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        txtSrNo.Text = ds.Tables[0].Rows[0]["SrNo"].ToString();
                        txtFolioNumber.Text = ds.Tables[0].Rows[0]["FOLIO_NO"].ToString();
                        txtInvestorName.Text = ds.Tables[0].Rows[0]["INVESTOR_FIRST_NAME"].ToString();
                        txtstatus.Text = ds.Tables[0].Rows[0]["TAX_STATUS"].ToString();
                        txtemail.Text = ds.Tables[0].Rows[0]["EMAIL"].ToString();
                        txtmobileno.Text = ds.Tables[0].Rows[0]["Mobile_Number"].ToString();
                        txtphoneres.Text = ds.Tables[0].Rows[0]["PHONE_RES"].ToString();
                        txtAmount.Text = ds.Tables[0].Rows[0]["AMOUNT"].ToString();
                        txtaccountnum.Text = ds.Tables[0].Rows[0]["AC_NO"].ToString();
                        txtaccounttype.Text = ds.Tables[0].Rows[0]["AC_TYPE"].ToString();
                        txtbankname.Text = ds.Tables[0].Rows[0]["BANK_NAME"].ToString();
                        txtbranchname.Text = ds.Tables[0].Rows[0]["BRANCH_NAME"].ToString();
                        txtIFSCCode.Text = ds.Tables[0].Rows[0]["IFSC_CODE"].ToString();
                        txtstate.Text = ds.Tables[0].Rows[0]["STATE_NAME"].ToString();
                        txtcity.Text = ds.Tables[0].Rows[0]["CITY_NAME"].ToString();
                        txtscheme.Text = ds.Tables[0].Rows[0]["SCHEME_NAME"].ToString();
                        txtSIPAmount.Text = ds.Tables[0].Rows[0]["RECORD_DATE"].ToString();
                        txtsipday.Text = ds.Tables[0].Rows[0]["INSTRM_NO"].ToString();
                        txtcallremarks.Text = ds.Tables[0].Rows[0]["Call_Remarks"].ToString();
                        txtpincode.Text = ds.Tables[0].Rows[0]["PINCODE"].ToString();
                        txtguardian.Text = ds.Tables[0].Rows[0]["GUARDIAN_Name"].ToString();
                        txtbrokercode.Text= ds.Tables[0].Rows[0]["BrokerCode"].ToString();

                        if (ds.Tables[0].Rows[0]["Type"].ToString() == "F")
                        {
                            rdoFolio.Checked = true;
                        }
                        else if (ds.Tables[0].Rows[0]["Type"].ToString() == "B")
                        {
                            rdoBrokerCode.Checked = true;
                        }
                        cmbLanguage.Text = ds.Tables[0].Rows[0]["Language"].ToString();                      
                        cmbQuery.Text = ds.Tables[0].Rows[0]["ServiceType"].ToString();
                        cmbCallCategory.Text = ds.Tables[0].Rows[0]["CurrentStatus"].ToString();
                        cmbCallerType.Text = ds.Tables[0].Rows[0]["CallerType"].ToString();
                        cmbCurrentStatus.Text = ds.Tables[0].Rows[0]["Remarks"].ToString();

                        DataTable dt = new DataTable();
                        dt.Columns.Add("CallDate");
                        dt.Columns.Add("PhoneNo");
                        dt.Columns.Add("Agent");
                        dt.Columns.Add("CallDur");
                        dt.Columns.Add("Disp");
                        dt.Columns.Add("Remarks");

                        //Code added by AMD on 3rd July 2017
                        logContent += PadDateCrLf("    Sr No           : " + ds.Tables[0].Rows[0]["SrNo"].ToString());
                        logContent += PadDateCrLf("    Folio Number    : " + ds.Tables[0].Rows[0]["FOLIO_NO"].ToString());
                        logContent += PadDateCrLf("    First Name      : " + ds.Tables[0].Rows[0]["INVESTOR_FIRST_NAME"].ToString());
                        logContent += PadDateCrLf("    TAX Number      : " + ds.Tables[0].Rows[0]["TAX_NO"].ToString());
                        logContent += PadDateCrLf("    TAX Status      : " + ds.Tables[0].Rows[0]["TAX_STATUS"].ToString());
                        logContent += PadDateCrLf("    Email           : " + ds.Tables[0].Rows[0]["EMAIL"].ToString());
                        logContent += PadDateCrLf("    Mobile Number   : " + ds.Tables[0].Rows[0]["Mobile_Number"].ToString());
                        logContent += PadDateCrLf("    Phone Res       : " + ds.Tables[0].Rows[0]["PHONE_RES"].ToString());
                        logContent += PadDateCrLf("   Amount           : " + ds.Tables[0].Rows[0]["AMOUNT"].ToString());
                        logContent += PadDateCrLf("   Account Number   : " + ds.Tables[0].Rows[0]["AC_NO"].ToString());
                        logContent += PadDateCrLf("   Account Type     : " + ds.Tables[0].Rows[0]["AC_TYPE"].ToString());
                        logContent += PadDateCrLf("   Bank Name        : " + ds.Tables[0].Rows[0]["BANK_NAME"].ToString());
                        logContent += PadDateCrLf("   Branch Name      : " + ds.Tables[0].Rows[0]["BRANCH_NAME"].ToString());
                        logContent += PadDateCrLf("   Bank Name        : " + ds.Tables[0].Rows[0]["IFSC_CODE"].ToString());
                        logContent += PadDateCrLf("   State Name       : " + ds.Tables[0].Rows[0]["STATE_NAME"].ToString());
                        logContent += PadDateCrLf("   City Name        : " + ds.Tables[0].Rows[0]["CITY_NAME"].ToString());
                        logContent += PadDateCrLf("   Scheme Name      : " + ds.Tables[0].Rows[0]["SCHEME_NAME"].ToString());
                        logContent += PadDateCrLf("   Record Date      : " + ds.Tables[0].Rows[0]["RECORD_DATE"].ToString());
                        logContent += PadDateCrLf("   Instrument No    : " + ds.Tables[0].Rows[0]["INSTRM_NO"].ToString());
                        logContent += PadDateCrLf("   Call Remarks     : " + ds.Tables[0].Rows[0]["Call_Remarks"].ToString());
                        logContent += PadDateCrLf("   PinCode          : " + ds.Tables[0].Rows[0]["PINCODE"].ToString());
                        logContent += PadDateCrLf("   Trxn Desc Suffix : " + ds.Tables[0].Rows[0]["TRXN_DESC_SUFFIX"].ToString());
                        logContent += PadDateCrLf("   Payout MEC       : " + ds.Tables[0].Rows[0]["PAYOUT_MEC"].ToString());
                        logContent += PadDateCrLf("   Guardian Name    : " + ds.Tables[0].Rows[0]["GUARDIAN_Name"].ToString());
                        logContent += PadDateCrLf("   SIP Day          : " + ds.Tables[0].Rows[0]["SIP_DAY"].ToString());
                        logContent += PadDateCrLf("   Message ID       : " + ds.Tables[0].Rows[0]["MessageID"].ToString());
                        logContent += PadDateCrLf("   Broker Code      : " + ds.Tables[0].Rows[0]["BrokerCode"].ToString());

                        //End

                        for (int i = 1; i <= 5; i++)
                        {
                            if (ds.Tables[0].Rows[0]["DialedNo" + i] != System.DBNull.Value && ds.Tables[0].Rows[0]["DialedNo" + i].ToString() != "")
                            {
                                DataRow dr = dt.NewRow();
                                dr["CallDate"] = ds.Tables[0].Rows[0]["CallStartDt" + i].ToString();
                                dr["PhoneNo"] = ds.Tables[0].Rows[0]["DialedNo" + i].ToString();
                                dr["Agent"] = ds.Tables[0].Rows[0]["AgentName" + i].ToString();
                                dr["CallDur"] = convertSS_HHMMSS(Decimal.Parse(ds.Tables[0].Rows[0]["CallDur" + i].ToString()));
                                dr["Disp"] = ds.Tables[0].Rows[0]["DispDesc" + i].ToString();
                                dr["Remarks"] = ds.Tables[0].Rows[0]["Remarks" + i].ToString();
                                dt.Rows.Add(dr);
                                //Code added by AMD on 3rd July 2017
                                logContent += PadDateCrLf("    Call Date " + i + "   : " + dr["CallDate"]);
                                logContent += PadDateCrLf("    Phone No " + i + "    : " + dr["PhoneNo"]);
                                logContent += PadDateCrLf("    Agent " + i + "       : " + dr["Agent"]);
                                logContent += PadDateCrLf("    Call Dur " + i + "    : " + dr["CallDur"]);
                                logContent += PadDateCrLf("    Disposition " + i + " : " + dr["Disp"]);
                                logContent += PadDateCrLf("    Remarks " + i + "     : " + dr["Remarks"]);
                                //End
                            }
                        }

                        dgvCallHistory.DataSource = dt.Copy();
                    }
                }
                else
                {
                    String PhNo = txtPhoneNumber.Text.Trim();
                    if(PhNo.Length > 10)
                    {
                        PhNo = PhNo.Substring(PhNo.Length - 10, 10);
                    }
                    String qry2 = "select top 22 *, DATEDIFF(second, CallStartDt1, CallEndDt1) as CallDur1";
                    qry2 += " from CRM_Data where DialedNo1 like '%" + PhNo + "' order by CallStartDt1 desc";
                    DataSet dsCallHist = ExecuteDataSet(Basic_CRM.Properties.Settings.Default["ConnStr"].ToString(), qry2);

                    DataTable dt = new DataTable();
                    dt.Columns.Add("CallDate");
                    dt.Columns.Add("PhoneNo");
                    dt.Columns.Add("Agent");
                    dt.Columns.Add("CallDur");
                    dt.Columns.Add("Disp");
                    dt.Columns.Add("Remarks");

                    for (int i = 0; i < dsCallHist.Tables[0].Rows.Count; i++)
                    {
                        DataRow dr = dt.NewRow();
                        dr["CallDate"] = dsCallHist.Tables[0].Rows[i]["CallStartDt1"].ToString();
                        dr["PhoneNo"] = dsCallHist.Tables[0].Rows[i]["DialedNo1"].ToString();
                        dr["Agent"] = dsCallHist.Tables[0].Rows[i]["AgentName1"].ToString();
                        dr["CallDur"] = convertSS_HHMMSS(Decimal.Parse(dsCallHist.Tables[0].Rows[i]["CallDur1"].ToString()));
                        dr["Disp"] = dsCallHist.Tables[0].Rows[i]["DispDesc1"].ToString();
                        dr["Remarks"] = dsCallHist.Tables[0].Rows[i]["Remarks1"].ToString();
                        dt.Rows.Add(dr);
                        //Code added by AMD on 3rd July 2017
                        logContent += PadDateCrLf("    Call Date 1" + "   : " + dr["CallDate"]);
                        logContent += PadDateCrLf("    Phone No 1" + "    : " + dr["PhoneNo"]);
                        logContent += PadDateCrLf("    Agent 1" + "       : " + dr["Agent"]);
                        logContent += PadDateCrLf("    Call Dur 1" + "    : " + dr["CallDur"]);
                        logContent += PadDateCrLf("    Disposition 1" + " : " + dr["Disp"]);
                        logContent += PadDateCrLf("    Remarks 1" + "     : " + dr["Remarks"]);
                        //End
                    }

                    dgvCallHistory.DataSource = dt.Copy();
                }
            }
            catch (Exception ex)
            {
                logContent += PadDateCrLf("Error : " + ex.Message);
            }
            finally
            {
                WriteLog(mpApp.CurrentAgent.AgentId, logContent);
            }
        }

        private void popupAgentCallHist()
        {
            try
            {
                logContent = PadDateCrLf("Populate Agent Call History from CRM DB");

                String qry = "select final.CallStartDt1 as CallDate, final.DialedNo1 as PhoneNo, final.AgentName1 as Agent";
                qry += " , cast(DATEDIFF(SECOND, final.CallStartDt1, CallEndDt1) as varchar) as CallDur, final.DispDesc1 as Disp, final.Remarks1 as Remarks";
                qry += " from (";
                qry += " SELECT [DialedNo1], [CallStartDt1], [CallEndDt1], [AgentID1], [AgentName1], [DispCode1], [DispDesc1], [Remarks1]";
                qry += " FROM [HDFCMF].[dbo].[CRM_Data] where AgentID1 = '" + mpApp.CurrentAgent.AgentId + "'";
                qry += " union all";
                qry += " SELECT [DialedNo2], [CallStartDt2], [CallEndDt2], [AgentID2], [AgentName2], [DispCode2], [DispDesc2], [Remarks2]";
                qry += " FROM [HDFCMF].[dbo].[CRM_Data] where AgentID2 = '" + mpApp.CurrentAgent.AgentId + "'";
                qry += " union all";
                qry += " SELECT [DialedNo3], [CallStartDt3], [CallEndDt3], [AgentID3], [AgentName3], [DispCode3], [DispDesc3], [Remarks3]";
                qry += " FROM [HDFCMF].[dbo].[CRM_Data] where AgentID3 = '" + mpApp.CurrentAgent.AgentId + "'";
                qry += " union all";
                qry += " SELECT [DialedNo4], [CallStartDt4], [CallEndDt4], [AgentID4], [AgentName4], [DispCode4], [DispDesc4], [Remarks4]";
                qry += " FROM [HDFCMF].[dbo].[CRM_Data] where AgentID4 = '" + mpApp.CurrentAgent.AgentId + "'";
                qry += " union all";
                qry += " SELECT [DialedNo5], [CallStartDt5], [CallEndDt5], [AgentID5], [AgentName5], [DispCode5], [DispDesc5], [Remarks5]";
                qry += " FROM [HDFCMF].[dbo].[CRM_Data] where AgentID5 = '" + mpApp.CurrentAgent.AgentId + "'";
                qry += " ) FINAL";
                qry += " where convert(varchar, final.CallStartDt1, 112) = convert(varchar, getDate(), 112)";
                qry += " order by CallStartDt1 desc";
                DataSet dsCallHist = ExecuteDataSet(Basic_CRM.Properties.Settings.Default["ConnStr"].ToString(), qry);

                //dsCallHist.Tables[0].Columns.Add("CallDur", typeof(System.String));

                for (int i = 0; i < dsCallHist.Tables[0].Rows.Count; i++)
                {
                    dsCallHist.Tables[0].Rows[i]["CallDur"] = convertSS_HHMMSS(Decimal.Parse(dsCallHist.Tables[0].Rows[i]["CallDur"].ToString()));
                    //dsCallHist.Tables[0].Rows[i]["CallDur"] = convertSS_HHMMSS(Decimal.Parse(dsCallHist.Tables[0].Rows[i]["CallDurTmp"].ToString()));
                }

                dgvCallHistory.DataSource = dsCallHist.Tables[0];
            }
            catch (Exception ex)
            {
                logContent += PadDateCrLf("Error : " + ex.Message);
            }
            finally
            {
                WriteLog(mpApp.CurrentAgent.AgentId, logContent);
            }
        }

        private String convertSS_HHMMSS(Decimal secs)
        {
            try
            {
                int HH = 0;
                int MM = 0;
                int SS = 0;

                if (secs > 3600)
                {
                    HH = int.Parse(Math.Floor(secs / 3600).ToString());
                    secs = (secs - (HH * 3600));
                }
                if (secs > 60)
                {
                    MM = int.Parse(Math.Floor(secs / 60).ToString());
                    secs = (secs - (MM * 60));
                }
                SS = int.Parse(secs.ToString());

                return HH.ToString("00") + ":" + MM.ToString("00") + ":" + SS.ToString("00");
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public void CApp_PhoneStatus(Object pSender, CPhoneStatusArgs pArgs)
        {
            try
            {
                if (this.InvokeRequired)
                {
                    this.Invoke(new PhoneStatusHandler(this.CApp_PhoneStatus), new object[] { pSender, pArgs });
                    return;
                }

                logContent = PadDateCrLf("Phone Status Event");
                if (pArgs.Connected)
                {
                    logContent += PadDateCrLf("Phone Connected");
                    lblPhoneStatus.BackColor = Color.LimeGreen;
                    this.lblPhoneStatusToolTip.SetToolTip(this.lblPhoneStatus, "Phone Connected");
                }
                else
                {
                    logContent += PadDateCrLf("Phone Disconnected");
                    lblPhoneStatus.BackColor = Color.Red;
                    lblPhoneStatusToolTip.SetToolTip(this.lblPhoneStatus, "Phone Disconnected");
                }
            }
            catch (Exception ex)
            {
                logContent += PadDateCrLf("Error : " + ex.Message);
            }
            finally
            {
                WriteLog(mpApp.CurrentAgent.AgentId, logContent);
            }
        }

        public void CApp_Error(Object pSender, CErrorArgs pArgs)
        {
            try
            {
                if (this.InvokeRequired)
                {
                    this.Invoke(new ErrorHandler(this.CApp_Error), new object[] { pSender, pArgs });
                    return;
                }

                logContent = PadDateCrLf("Error Event");
                logContent += PadDateCrLf("    Error " + (int)pArgs.Code + "  (" + pArgs.Description.Replace("<error>", "").Trim() + ")");

                //Display error
                DisplayMessage(" Event Error Details" + (int)pArgs.Code + "  (" + pArgs.Description.Replace("<error>", "").Trim() + ")", true);
                //MessageBox.Show("Error : " + (int)pArgs.Code + "  (" + pArgs.Description.Replace("<error>", "").Trim()+")");
            }
            catch (Exception ex)
            {
                logContent += PadDateCrLf("Error : " + ex.Message);
            }
            finally
            {
                WriteLog(mpApp.CurrentAgent.AgentId, logContent);
            }
        }

        public void CApp_Passcode(Object pSender, CPasscodeArgs pArgs)
        {
            try
            {
                if (this.InvokeRequired)
                {
                    this.Invoke(new PasscodeHandler(this.CApp_Passcode), new Object[] { pSender, pArgs });
                    return;
                }

                logContent = PadDateCrLf("Passcode Event");
                if (pArgs.Valid)
                {
                    logContent += PadDateCrLf("Enter passcode " + pArgs.Passcode);
                    DisplayMessage("Enter passcode " + pArgs.Passcode, false);
                }
                else
                {
                    logContent += PadDateCrLf("Invalid passcode. Enter passcode " + pArgs.Passcode);
                    DisplayMessage("Invalid passcode. Enter passcode " + pArgs.Passcode, false);
                }
            }
            catch (Exception ex)
            {
                logContent += PadDateCrLf("Error : " + ex.Message);
            }
            finally
            {
                WriteLog(mpApp.CurrentAgent.AgentId, logContent);
            }
        }

        public void CApp_LogoutPending(Object pSender)
        {
            try
            {
                if (this.InvokeRequired)
                {
                    this.Invoke(new LogoutPendingHandler(this.CApp_LogoutPending), new Object[] { pSender });
                    return;
                }

                logContent = PadDateCrLf("Logout Pending Event. Terminate the current call to logout.");
                FMessage oMsgForm = new FMessage("Terminate the current call to log out", -1);
                oMsgForm.Show();
            }
            catch (Exception ex)
            {
                logContent += "Error : " + ex.Message;
            }
            finally
            {
                WriteLog(mpApp.CurrentAgent.AgentId, logContent);
            }
        }

        private void DisplayMessage(String sMsg, Boolean bTimeout)
        {

            try
            {
                pnlState.Visible = false;

                lblMessage.Text = sMsg;
                lblMessage.Visible = true;

                if (bTimeout)
                {
                    //Reset the timer if already exists
                    if (mpMessageTimer != null)
                        mpMessageTimer.Change(4000, System.Threading.Timeout.Infinite);

                    //Otherwise, set the timer for display of error
                    else
                    {
                        System.Threading.TimerCallback timerDelegate = new System.Threading.TimerCallback(mpMessageTimer_Fire);
                        mpMessageTimer = new System.Threading.Timer(timerDelegate, this, 5000, System.Threading.Timeout.Infinite);
                    }
                }
                else if (!bTimeout && mpMessageTimer != null)
                {
                    mpMessageTimer.Dispose();
                    mpMessageTimer = null;
                }

            }
            catch (Exception pError)
            {
                Console.WriteLine(pError.StackTrace);
                MessageBox.Show("Error :" + pError.StackTrace);
            }
        }

        private void mpMessageTimer_Fire(Object state)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new System.Threading.TimerCallback(this.mpMessageTimer_Fire), new Object[] { state });
                return;
            }

            ClearMessage();
        }

        private void ClearMessage()
        {
            if (mpMessageTimer != null)
            {
                mpMessageTimer.Dispose();
                mpMessageTimer = null;
            }

            lblMessage.Visible = false;
            pnlState.Visible = true;
        }

        private void btnLogout_Click(object sender, System.EventArgs e)
        {
            try
            {
                FList LogoutForm = new FList(mpApp, mpApp.LogoutReasons);
                LogoutForm.Text = "Choose a Logout Reason";
                if (LogoutForm.ShowDialog() == DialogResult.OK)
                {
                    logContent = PadDateCrLf("Placing Logout Request");
                    mpApp.Logout((CLogoutReason)LogoutForm.SelectedItem);
                }

            }
            catch (Exception pError)
            {
                logContent += PadDateCrLf("Error : " + pError.Message);
                MessageBox.Show(pError.Message);
                MessageBox.Show("Error :" + pError.StackTrace);
            }
            finally
            {
                WriteLog(mpApp.CurrentAgent.AgentId, logContent);
            }
        }

        private void btnReady_Click(object sender, System.EventArgs e)
        {
            try
            {
                logContent = PadDateCrLf("Placing Ready Request");
                mpApp.TakeCalls();
                btnReady.Visible = false;
                pnlState.Visible = true;
            }
            catch (Exception pError)
            {
                logContent += PadDateCrLf("Error : " + pError.Message);
                MessageBox.Show(pError.Message);
                MessageBox.Show("Error :" + pError.StackTrace);
            }
            finally
            {
                WriteLog(mpApp.CurrentAgent.AgentId, logContent);
            }
        }

        private void btnHangup_Click(object sender, System.EventArgs e)
        {
            try
            {
                logContent = PadDateCrLf("Placing Hangup Request");
                mpApp.Hangup(mpApp.CurrentCall);
            }
            catch (Exception pError)
            {
                logContent += PadDateCrLf("Error : " + pError.Message);
                MessageBox.Show(pError.Message);
                MessageBox.Show("Error :" + pError.StackTrace);
            }
            finally
            {
                WriteLog(mpApp.CurrentAgent.AgentId, logContent);
            }
        }

        private void btnNextCall_Click(object sender, System.EventArgs e)
        {
            //If current call requires a disposition, prompt user for one
            CDisposition pDisp = null;

            if (mpApp.CurrentService.RequireDisposition)
            {
                //TODO: If not allowed to schedule a callback, remove callback dispositions from selection list
                //TODO: If not allowed to set an exclusion, remove exclusion dispositions from selection list

                FList oDispositionsForm = new FList(mpApp, mpApp.CurrentService.DispositionPlan.Dispositions);
                oDispositionsForm.Text = "Select a disposition";
                oDispositionsForm.ShowDialog();

                if (oDispositionsForm.DialogResult != DialogResult.OK)
                    return;

                pDisp = (CDisposition)oDispositionsForm.SelectedItem;

                //TODO: If selected disposition is a callback then have user request a callback
                //TODO: If selected disposition is an exclusion then have user request an exclusion
            }

            try
            {
                logContent = PadDateCrLf("Placing Disposition Request : " + pDisp.Code + "{" + pDisp.Description + ")");
                mpApp.DisposeCall(mpApp.CurrentCall, pDisp);
            }
            catch (Exception pError)
            {
                logContent += PadDateCrLf("Error : " + pError.Message);
                MessageBox.Show(pError.Message);
                MessageBox.Show("Error :" + pError.StackTrace);
            }
            finally
            {
                WriteLog(mpApp.CurrentAgent.AgentId, logContent);
            }
        }

        private void btnDial_Click(object sender, System.EventArgs e)
        {
            if (mpApp.CurrentState.Description == "Preview" && mpApp.CurrentCall.PhoneNumber != "")
            {
                tmrPreview.Enabled = false;
                mpApp.Dial(mpApp.CurrentCall.PhoneNumber, mpApp.CurrentCall.ServiceID, 0);
                return;
            }
            //else if (mpApp.CurrentState.Description == "Wrap" && mpApp.CurrentCall.PhoneNumber != "")
            //{
            //   // mpApp.Dial(mpApp.CurrentCall.PhoneNumber, mpApp.CurrentCall.ServiceID, 0);
            //    mpApp.Redial(mpApp.CurrentCall.PhoneNumber, mpApp.CurrentCall.ServiceID, 0);
            //    return;
            //}
            else
            {

                FDial pFormDial = new FDial(mpApp, DialMode.dm1stParty);
                pFormDial.Text = "Specify the entity to dial";
                pFormDial.ShowDialog();

                if (pFormDial.DialogResult != DialogResult.OK)
                    return;

                //If dialing an external...
                if (pFormDial.SelectedItem is CExternalRoute || pFormDial.PhoneNumber.Trim() != "")
                {
                    int iServiceId = 0;
                    int iExternalRouteId = 0;

                    if (pFormDial.SelectedItem != null)
                        iExternalRouteId = ((CExternalRoute)pFormDial.SelectedItem).Id;

                    if (mpApp.CurrentCall == null)
                    {
                        //If a service is required and have one to choose from, prompt for one
                        if ((mpApp.CurrentAgent.ShowServiceListForManualDial || mpApp.CurrentAgent.RequireServiceForManualDial) && mpApp.AssignedServices.Count > 1)
                        {
                            ArrayList oExcludeItems = null;

                            //If a service is required then exclude the default service from the selection list
                            if (mpApp.CurrentAgent.RequireServiceForManualDial)
                            {
                                oExcludeItems = new ArrayList();
                                oExcludeItems.Add(mpApp.AssignedServices.GetByKey(0));
                            }

                            FList pFormServices = new FList(mpApp, mpApp.AssignedServices, oExcludeItems);
                            pFormServices.Text = "Select a service";
                            pFormServices.ShowDialog();

                            if (pFormServices.DialogResult != DialogResult.OK)
                                return;

                            iServiceId = ((CService)pFormServices.SelectedItem).ServiceId;
                            txtServiceID.Text = iServiceId.ToString();
                            txtServiceName.Text = mpApp.AssignedServices.GetByKey(iServiceId).ServiceName;
                            if (callStartDtAssigned == "F")
                            {
                                callStartDt = DateTime.Now;
                                callStartDtAssigned = "T";
                            }
                        }
                    }
                    else
                    {
                        iServiceId = mpApp.CurrentCall.ServiceID;
                        txtServiceID.Text = iServiceId.ToString();
                        txtServiceName.Text = mpApp.AssignedServices.GetByKey(iServiceId).ServiceName;
                    }
                    if (pFormDial.PhoneNumber.Trim() != "")
                    {
                        txtPhoneNumber.Text = pFormDial.PhoneNumber;
                    }
                    if (iServiceId != 0)
                    {
                        txtServiceID.Text = iServiceId.ToString();
                    }

                    try
                    {
                        logContent = PadDateCrLf("Placing Dial Request (External)");
                        mpApp.Dial(pFormDial.PhoneNumber, iServiceId, iExternalRouteId);

                        PopupDataFromDB();

                        popupAgentCallHist();
                    }
                    catch (Exception pError)
                    {
                        logContent += PadDateCrLf("Error : " + pError.Message);
                        MessageBox.Show("Error :" + pError.Message);
                    }
                    finally
                    {
                        WriteLog(mpApp.CurrentAgent.AgentId, logContent);
                    }
                }
                //Otherwise(dialing a user)...
                else if (pFormDial.SelectedItem is CUser)
                {
                    try
                    {
                        logContent = PadDateCrLf("Placing Dial Request (Internal / User)");
                        mpApp.Dial(((CUser)pFormDial.SelectedItem).Id);
                    }
                    catch (Exception pError)
                    {
                        logContent += PadDateCrLf("Error : " + pError.Message);
                        //MessageBox.Show(pError.Message);
                        MessageBox.Show("Error :" + pError.Message);
                    }
                    finally
                    {
                        WriteLog(mpApp.CurrentAgent.AgentId, logContent);
                    }
                }
            }

        }

        private void btnHold_Click(object sender, System.EventArgs e)
        {
            try
            {
                if (mpApp.CurrentCall.CurrentState is CStateHeld)
                {
                    logContent = PadDateCrLf("Placing Retrieve Request");
                    mpApp.ReleaseHold();
                }
                else
                {
                    logContent = PadDateCrLf("Placing Hold Request");
                    mpApp.Hold();
                }
            }
            catch (Exception pError)
            {
                logContent += PadDateCrLf("Error : " + pError.Message);
                MessageBox.Show("Error :" + pError.Message);
            }
            finally
            {
                WriteLog(mpApp.CurrentAgent.AgentId, logContent);
            }
        }

        private void btnAvailable_Click(object sender, EventArgs e)
        {
            try
            {
                logContent = PadDateCrLf("Placing Idle / Ready Request");
                mpApp.BecomeAvailable();
            }
            catch (Exception pError)
            {
                logContent += PadDateCrLf("Error : " + pError.Message);
                MessageBox.Show("Error :" + pError.Message);
            }
            finally
            {
                WriteLog(mpApp.CurrentAgent.AgentId, logContent);
            }
        }

        private void btnUnavailable_Click(object sender, EventArgs e)
        {
            try
            {
                FList NotReadyForm = new FList(mpApp, mpApp.NotReadyReasons, null, true, mpApp.CurrentAgent.AllowPark, "Park");
                NotReadyForm.Text = "Choose a NotReady Reason";
                if (NotReadyForm.ShowDialog() == DialogResult.OK)
                {
                    logContent = PadDateCrLf("Placing Not Ready Request");
                    mpApp.BecomeUnavailable((CNotReadyReason)NotReadyForm.SelectedItem, NotReadyForm.OptionIsChecked);
                }
            }
            catch (Exception pError)
            {
                logContent += PadDateCrLf("Error : " + pError.Message);
                MessageBox.Show("Error :" + pError.Message);
            }
            finally
            {
                WriteLog(mpApp.CurrentAgent.AgentId, logContent);
            }
        }

        private void btn3Way_Click(object sender, EventArgs e)
        {
            try
            {
                logContent = PadDateCrLf("Opening 3WAY Dialog");
                F3Way pForm3Way = new F3Way(mpApp);
                pForm3Way.ShowDialog();
            }
            catch (Exception pError)
            {
                logContent += PadDateCrLf("Error : " + pError.Message);
            }
            finally
            {
                WriteLog(mpApp.CurrentAgent.AgentId, logContent);
            }
        }

        private void clearData()
        {
            try
            {
                tmrAutoDisp.Enabled = false;
                tmrCallDuration.Enabled = false;
                CallDuration = 0;
                WrapDur = 0;
                lblCallDuration.Text = "00:00:00";

                lblUDF1.Text = "User Defined 1";
                lblUDF2.Text = "User Defined 2";
                lblUDF3.Text = "User Defined 3";
                lblUDF4.Text = "User Defined 4";
                lblUDF5.Text = "User Defined 5";
                lblUDF6.Text = "User Defined 6";
                lblUDF7.Text = "User Defined 7";
                lblUDF8.Text = "User Defined 8";
                lblUDF9.Text = "User Defined 9";
                lblUDF10.Text = "User Defined 10";
                lblUDF11.Text = "User Defined 11";
                lblUDF12.Text = "User Defined 12";
                lblUDF13.Text = "User Defined 13";
                lblUDF14.Text = "User Defined 14";
                lblUDF15.Text = "User Defined 15";
                lblUDF16.Text = "User Defined 16";
                lblUDF17.Text = "User Defined 17";
                lblUDF18.Text = "User Defined 18";
                lblUDF19.Text = "User Defined 19";
                lblUDF20.Text = "User Defined 20";

                txtUDF1.Text = "";
                txtUDF2.Text = "";
                txtUDF3.Text = "";
                txtUDF4.Text = "";
                txtUDF5.Text = "";
                txtUDF6.Text = "";
                txtUDF7.Text = "";
                txtUDF8.Text = "";
                txtUDF9.Text = "";
                txtUDF10.Text = "";
                txtUDF11.Text = "";
                txtUDF12.Text = "";
                txtUDF13.Text = "";
                txtUDF14.Text = "";
                txtUDF15.Text = "";
                txtUDF16.Text = "";
                txtUDF17.Text = "";
                txtUDF18.Text = "";
                txtUDF19.Text = "";
                txtUDF20.Text = "";

                txtServiceID.Text = "";
                txtServiceName.Text = "";
                txtPhoneNumber.Text = "";
                txtDNIS.Text = "";
                txtSrNo.Text = "";
                txtFolioNumber.Text = "";
                txtInvestorName.Text = "";
                txtstatus.Text = "";
                txtemail.Text = "";
                txtmobileno.Text = "";
                txtphoneres.Text = "";
                txtbrokercode.Text = "";
                txtAmount.Text = "";
                txtaccountnum.Text = "";
                txtaccounttype.Text = "";
                txtbankname.Text = "";
                txtbranchname.Text = "";
                txtIFSCCode.Text = "";
                txtstate.Text = "";
                txtcity.Text = "";
                txtpincode.Text = "";
                txtSIPAmount.Text = "";
                txtsipday.Text = "";
                txtcallremarks.Text = "";
                txtscheme.Text = "";
                txtguardian.Text = "";
                txtsipday.Text = "";
                cmbLanguage.Text = "";
                cmbQuery.Text = "";
                cmbCurrentStatus.Text = "";
                rdoFolio.Checked = false;
                rdoBrokerCode.Checked = false;
                cmbCallCategory.Text = "";
                cmbCallerType.Text = "";
                txtRemarks.Text = "";
                DataTable dt = new DataTable();
                dt.Columns.Add("CallDate");
                dt.Columns.Add("PhoneNo");
                dt.Columns.Add("Agent");
                dt.Columns.Add("CallDur");
                dt.Columns.Add("Disp");
                dt.Columns.Add("Remarks");

                dgvCallHistory.DataSource = dt.Copy();

                dt = null;

                pnlCallback.Enabled = false;
                cmbDispDesc.Enabled = false;
                cmbDispDesc.Items.Clear();
                btnDispose.Enabled = false;

                previewCnt = 0;

                txtFolioNumber.ReadOnly = true;
                txtbrokercode.ReadOnly = true;
            }
            catch (Exception ex)
            {

            }
        }

        private void btnDispose_Click(object sender, EventArgs e)
        {
            try
            {
                logContent = PadDateCrLf("Dispose Call Opted");
                logContent += PadDateCrLf("    Agent State : " + lblState.Text);
                if (lblState.Text.ToUpper() == "WRAP" || lblState.Text.ToUpper() == "PREVIEW")
                {
                    if (txtRemarks.Text.Trim() == "")
                    {
                        MessageBox.Show("Cannot Dispose without entring the Remarks");
                        //tcCallDetails.SelectedTab = tcCallDetails.TabPages[1];
                        txtRemarks.Focus();
                        return;
                    } 
                    else if (mpApp.CurrentCall.CallType == AgentCallType.acACD && (rdoFolio.Checked == false && rdoBrokerCode.Checked == false))
                    {
                        MessageBox.Show("Select Folio Number / Broker Code to Dispose");
                        return;
                    }
                    else if (mpApp.CurrentCall.CallType == AgentCallType.acACD && (rdoFolio.Checked == true && txtFolioNumber.Text == ""))
                    {
                        MessageBox.Show("Cannot Dispose without entering Folio Number");
                        return;
                    }
                    else if (mpApp.CurrentCall.CallType == AgentCallType.acACD && (rdoBrokerCode.Checked == true && txtbrokercode.Text == ""))
                    {
                        MessageBox.Show("Cannot Dispose without entering Broker Code");
                        return;
                    }
                    else if (mpApp.CurrentCall.CallType == AgentCallType.acACD && cmbLanguage.Text == "")
                    {
                        MessageBox.Show("Cannot Dispose without Selecting the Language");
                        cmbLanguage.Focus();
                        return;
                    }

                    else if (mpApp.CurrentCall.CallType == AgentCallType.acACD && cmbQuery.Text == "")
                    {
                        MessageBox.Show("Cannot Dispose without Selecting the Service Type");
                        cmbCallerType.Focus();
                        return;
                    }
                    else if (mpApp.CurrentCall.CallType == AgentCallType.acACD && cmbCallCategory.Text == "")
                    {
                        MessageBox.Show("Cannot Dispose without Selecting the Current Status");
                        cmbCallerType.Focus();
                        return;
                    }
                    else if (mpApp.CurrentCall.CallType == AgentCallType.acACD && cmbCallerType.Text == "")
                    {
                        MessageBox.Show("Cannot Dispose without Selecting the Caller Type");
                        cmbCallerType.Focus();
                        return;
                    }
                    else if (cmbDispDesc.SelectedIndex < 0)
                    {
                        logContent += PadDateCrLf("Select a Disposition");
                        MessageBox.Show("Select the Disposition", "HDFCMF", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    btnDispose.Enabled = false;

                    CDisposition disp = null;
                    disp = (CDisposition)cmbDisp.Items[cmbDispDesc.SelectedIndex];
                    callEndDt = DateTime.Now;
                    String qry = "";

                    logContent += PadDateCrLf("Checking for Lead Record in CRM DB");
                    String searchSrNo = txtSrNo.Text.Trim();
                    if (searchSrNo == "")
                    {
                        searchSrNo = "-1";
                    }

                    qry = "select * from CRM_Data where SrNo=" + searchSrNo;
                    logContent += PadDateCrLf("Query : " + qry);
                    DataSet ds = ExecuteDataSet(Basic_CRM.Properties.Settings.Default["ConnStr"].ToString(), qry);
                    logContent += PadDateCrLf("Result : " + ds.Tables[0].Rows.Count);

                    if (ds.Tables[0].Rows.Count == 0)
                    {
                        logContent += PadDateCrLf("Inserting Lead Record to CRM DB");
                        qry = "INSERT INTO [dbo].[CRM_Data](CallStartDt1, CallEndDt1, AgentID1, AgentName1";
                        qry += ", FOLIO_NO,INVESTOR_FIRST_NAME,TAX_NO,TAX_STATUS,EMAIL,Mobile_Number";
                        qry += ", PHONE_RES,AMOUNT,AC_NO,AC_TYPE,BANK_NAME,BRANCH_NAME";
                        qry += ", IFSC_CODE,STATE_NAME,CITY_NAME,SCHEME_NAME,RECORD_DATE";
                        qry += ", INSTRM_NO,Call_Remarks,PINCODE,TRXN_DESC_SUFFIX,PAYOUT_MEC";
                        qry += ", GUARDIAN_Name,SIP_DAY";
                        qry += ", MessageID,BrokerCode,Type,Language";
                        qry += ", CallType, MessageType,MessageTo,ServiceType";
                        qry += ", CurrentStatus, CallerType,Remarks,AutoEmail,AutoSMS";
                        qry += ", DNIS, ServiceID, ServiceName";
                        qry += ", Remarks1, DispCode1, DispDesc1,DialedNo1)";
                        qry += " VALUES('" + callStartDt.ToString("M/d/yyyy HH:mm:ss") + "','" + callEndDt.ToString("M/d/yyyy HH:mm:ss") + "','" + txtAgentID.Text + "','" + txtAgentName.Text + "'";
                        qry += ",'" + txtFolioNumber.Text + "','" + txtInvestorName.Text + "'";
                        qry += ",'" + txtstatus.Text + "','" + txtemail.Text + "','" + txtmobileno.Text + "'";
                        qry += ",'" + txtphoneres.Text + "','" + txtAmount.Text + "','" + txtaccountnum.Text + "','" + txtaccounttype.Text + "','" + txtbankname.Text + "','" + txtbranchname.Text + "'";
                        qry += ",'" + txtIFSCCode.Text + "','" + txtstate.Text + "','" + txtcity.Text + "','" + txtscheme.Text + "','" + txtSIPAmount.Text + "'";
                        qry += ",'" + txtsipday.Text + "','" + txtcallremarks.Text + "','" + txtpincode.Text + "','";
                        qry += ",'" + txtguardian.Text + "','" + txtsipday.Text + "','" + txtbrokercode.Text + "','" + INBCallType + "','" + cmbLanguage.Text + "'";                       
                        qry += ",'" + cmbCallCategory.Text + "','" + cmbCallerType.Text + "'";
                        qry += ",'" + cmbCurrentStatus.Text + "','" + AutoEmail + "','" + AutoSMS + "'";
                        qry += ",'" + txtDNIS.Text + "','" + txtServiceID.Text + "','" + txtServiceName.Text.Trim() + "'";
                        qry += ",'" + replaceSplChars(txtRemarks.Text) + "','" + disp.Code + "','" + disp.Description + "','" + txtPhoneNumber.Text + "'";
                        qry += ")";
                    }
                    else
                    {
                        logContent += PadDateCrLf("Updating Lead Record to CRM DB");
                        qry = "update CRM_Data set CallStartDt5 = CallStartDt4, CallStartDt4=CallStartDt3, CallStartDt3=CallStartDt2, CallStartDt2=CallStartDt1";
                        qry += ", CallStartDt1='" + callStartDt.ToString("M/d/yyyy HH:mm:ss") + "'";
                        qry += ", CallEndDt5 = CallEndDt4, CallEndDt4=CallEndDt3, CallEndDt3=CallEndDt2, CallEndDt2=CallEndDt1";
                        qry += ", CallEndDt1='" + callEndDt.ToString("M/d/yyyy HH:mm:ss") + "'";
                        qry += ", AgentID5 = AgentID4, AgentID4=AgentID3, AgentID3=AgentID2, AgentID2=AgentID1";
                        qry += ", AgentID1='" + txtAgentID.Text + "'";
                        qry += ", AgentName5 = AgentName4, AgentName4=AgentName3, AgentName3=AgentName2, AgentName2=AgentName1";
                        qry += ", AgentName1='" + txtAgentName.Text + "'";
                        qry += ", DialedNo5 = DialedNo4, DialedNo4=DialedNo3, DialedNo3=DialedNo2, DialedNo2=DialedNo1";
                        qry += ", DialedNo1='" + txtPhoneNumber.Text + "'";
                        qry += ", DispCode5 = DispCode4, DispCode4=DispCode3, DispCode3=DispCode2, DispCode2=DispCode1";
                        qry += ", DispCode1='" + disp.Code + "'";
                        qry += ", DispDesc5 = DispDesc4, DispDesc4=DispDesc3, DispDesc3=DispDesc2, DispDesc2=DispDesc1";
                        qry += ", DispDesc1='" + disp.Description + "'";
                        qry += ", Remarks5 = Remarks4, Remarks4=Remarks3, Remarks3=Remarks2, Remarks2=Remarks1";
                        qry += ", Remarks1='" + replaceSplChars(txtRemarks.Text) + "'";
                        qry += ", DNIS='" + txtDNIS.Text + "', ServiceID='" + txtServiceID.Text + "'";
                        qry += ", FOLIO_NO='" + txtFolioNumber.Text + "',INVESTOR_FIRST_NAME='" + txtInvestorName.Text + "'";
                        qry += ", TAX_STATUS='" + txtstatus.Text + "',EMAIL='" + txtemail.Text + "',Mobile_Number='" + txtmobileno.Text + "'";
                        qry += ", PHONE_RES='" + txtphoneres.Text + "',AMOUNT='" + txtAmount.Text + "',AC_NO='" + txtaccountnum.Text + "'";
                        qry += ", AC_TYPE='" + txtaccounttype.Text + "', BANK_NAME='" + txtbankname.Text + "',BRANCH_NAME='" + txtbranchname.Text + "'";
                        qry += ", IFSC_CODE='" + txtIFSCCode.Text + "',STATE_NAME='" + txtstate.Text + "',CITY_NAME='" + txtcity.Text + "'";
                        qry += ", SCHEME_NAME='" + txtscheme.Text + "',RECORD_DATE='" + txtSIPAmount.Text + "',INSTRM_NO='" + txtsipday.Text + "'";
                        qry += ", Call_Remarks='" + txtcallremarks.Text + "',PINCODE='" + txtpincode.Text + "',TRXN_DESC_SUFFIX='";
                        qry += ", GUARDIAN_Name='" + txtguardian.Text + "',SIP_DAY='" + txtsipday.Text + "'";
                        qry += ", BrokerCode='" + txtbrokercode.Text + "',Type='" + INBCallType + "'";
                        qry += ",ServiceType='" + cmbQuery.Text + "'";
                        qry += ",CurrentStatus='" + cmbCallCategory.Text + "'";
                        qry += ",CallerType='" + cmbCallerType.Text + "'";
                        qry += ",Remarks='" + cmbCurrentStatus.Text + "'";
                        qry += ",AutoEmail='" + AutoEmail + "'";
                        qry += ",AutoSMS='" + AutoSMS + "'";
                        qry += ",ServiceName='" + txtServiceName.Text + "'";
                        qry += " where SrNo='" + txtSrNo.Text + "'";
                    }

                    logContent += PadDateCrLf("Query : " + qry);
                    ExecuteNonQuery(Basic_CRM.Properties.Settings.Default["ConnStr"].ToString(), qry); //System.Configuration.ConfigurationManager.AppSettings["ConnStr"].ToString()
                    logContent += PadDateCrLf("Inserted / Updated");

                    if (disp.IsCallback == true)
                    {
                        mpApp.CurrentAgent.mpCallbackArg.callID = mpApp.CurrentCall.CallID;
                        mpApp.CurrentAgent.mpCallbackArg.callbackName = "PCallBack";
                        mpApp.CurrentAgent.mpCallbackArg.dateTime = dtpCbkDtTm.Value.ToString("M/d/yyyy H:m:ss");
                        if (cbSelfCbk.Checked == true)
                        {
                            mpApp.CurrentAgent.mpCallbackArg.returnToSameAgent = 1;
                        }
                        else
                        {
                            mpApp.CurrentAgent.mpCallbackArg.returnToSameAgent = 0;
                        }

                        if (mpApp.CurrentCall.CallType == AgentCallType.acACD)
                        {
                            mpApp.CurrentAgent.mpCallbackArg.aodServiceID = int.Parse(Basic_CRM.Properties.Settings.Default["InbCbkSvcID"].ToString());
                        }
                        else
                        {
                            mpApp.CurrentAgent.mpCallbackArg.aodServiceID = mpApp.CurrentCall.ServiceID;
                        }

                        mpApp.CurrentAgent.mpCallbackArg.phoneNumber = txtPhoneNumber.Text;
                        if (txtAltPhoneNo.Text.Trim() != "")
                        {
                            mpApp.CurrentAgent.mpCallbackArg.phoneNumber = txtAltPhoneNo.Text.Trim();
                        }
                        logContent += PadDateCrLf("Setting Callback");
                        mpApp.setcallback();
                    }
                    else if (disp.IsExclusion == true)
                    {
                        //Set Exclusion Code goes here
                    }
                    logContent += PadDateCrLf("Disposing Call");
                    mpApp.DisposeCall(mpApp.CurrentCall, disp);
                }
                else
                {
                    logContent += PadDateCrLf("Cannot Dispose Call. Invalid State.");
                    MessageBox.Show(this, "Cannot Dispose Call. Invalid State.", "UnionMF", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    btnDispose.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                logContent += PadDateCrLf("Error : " + ex.Message);
                btnDispose.Enabled = true;
            }
            finally
            {
                WriteLog(mpApp.CurrentAgent.AgentId, logContent);
            }
        }

        private DataSet ExecuteDataSet(String conSql, String strSql)
        {
            DataSet ds = new DataSet();

            try
            {
                SqlConnection sqlConn = new SqlConnection(conSql);
                sqlConn.Open();
                SqlCommand cmd = new SqlCommand(strSql, sqlConn);
                SqlDataAdapter sqlda = new SqlDataAdapter();
                sqlda.SelectCommand = cmd;
                sqlda.Fill(ds);

                return ds;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private int ExecuteNonQuery(String conSql, String strSql)
        {
            try
            {
                SqlConnection sqlConn = new SqlConnection(conSql);
                sqlConn.Open();
                SqlCommand cmd = new SqlCommand(strSql, sqlConn);
                return cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private String replaceSplChars(String val)
        {
            return val.Replace("\'", "\'\'");
        }
        private String PadDateCrLf(String val)
        {
            try
            {
                return DateTime.Now.ToString("dd-MMM-yyyy HH:mm:ss.ms : ") + val + Environment.NewLine;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private void WriteLog(string AgentID, string value)
        {
            string FileName = DateTime.Now.ToString("HH");

            try
            {
                if (!string.IsNullOrEmpty(value.Trim()))
                {
                    if (Basic_CRM.Properties.Settings.Default["EnableLogging"].ToString() == "T")
                    {
                        FileName = FileName + ".log";
                        String FilePath = Application.StartupPath + "\\Logs"; //CommonCRM.Properties.Settings.Default["LoggingPath"].ToString();
                        if (System.IO.Directory.Exists(FilePath) == false)
                        {
                            System.IO.Directory.CreateDirectory(FilePath);
                        }
                        FilePath += "\\" + System.DateTime.Now.ToString("ddMMyyyy");
                        if (System.IO.Directory.Exists(FilePath) == false)
                        {
                            System.IO.Directory.CreateDirectory(FilePath);
                        }
                        FilePath += "\\" + AgentID;
                        if (System.IO.Directory.Exists(FilePath) == false)
                        {
                            System.IO.Directory.CreateDirectory(FilePath);
                        }
                        FileName = FilePath + "\\" + FileName;
                        System.IO.StreamWriter writer = new System.IO.StreamWriter(FileName, true);
                        writer.Write(value);
                        writer.Flush();
                        writer.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                //Nothing to do.
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            txtPhoneNumber.Text = "";
            PopupDataFromDB();

            popupAgentCallHist();
        }

        private void cmbDispDesc_SelectedIndexChanged(object sender, EventArgs e)
        {
            CDisposition tmp = (CDisposition)cmbDisp.Items[cmbDispDesc.SelectedIndex];
            if (tmp.IsCallback == true)
            {
                pnlCallback.Enabled = true;
            }
            else
            {
                pnlCallback.Enabled = false;
            }
        }

        private void fillLanguage()
        {
            try
            {
                cmbLanguage.Items.Clear();

                cmbLanguage.Items.Add("");

                String qry = "SELECT DISTINCT LangType FROM mstLang";
                DataSet ds = ExecuteDataSet(Basic_CRM.Properties.Settings.Default["ConnStr"].ToString(), qry);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        cmbLanguage.Items.Add(ds.Tables[0].Rows[i]["LangType"]);
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
            }
        }

        private void fillRemarks()
        {
            try
            {
                cmbCurrentStatus.Items.Clear();

                cmbCurrentStatus.Items.Add("");

                String qry = "SELECT DISTINCT Remarks FROM Mst_Remarks";
                DataSet ds = ExecuteDataSet(Basic_CRM.Properties.Settings.Default["ConnStr"].ToString(), qry);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        cmbCurrentStatus.Items.Add(ds.Tables[0].Rows[i]["Remarks"]);
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
            }
        }


        private void cmbCustomerReaction_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void tmrPreview_Tick(object sender, EventArgs e)
        {
            if (previewCnt >= int.Parse(Basic_CRM.Properties.Settings.Default["TPDS"].ToString()))
            {
                btnDial_Click(null, null);
                tmrPreview.Enabled = false;
            }
            previewCnt += 1;
        }

        private void rdoFolio_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoFolio.Checked == true)
            {
                INBCallType = "F";
                txtFolioNumber.ReadOnly = false;
                txtbrokercode.Text = "";
                txtbrokercode.ReadOnly = true;
                txtFolioNumber.Focus();
                cmbCallerType.Text = "";
            }
        }

        private void rdoBrokerCode_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoBrokerCode.Checked == true)
            {
                INBCallType = "B";
                txtFolioNumber.Text = "";
                txtFolioNumber.ReadOnly = true;
                txtbrokercode.ReadOnly = false;
                txtbrokercode.Focus();
                cmbCallerType.Text = "Distributor";
            }
        }  

        private void tmrAutoDisp_Tick(object sender, EventArgs e)
        {
            try
            {
                CDisposition disp = null;
                WrapDur += 1;

                if(WrapDur > int.Parse(Basic_CRM.Properties.Settings.Default["MaxWrapSecs"].ToString()))
                {
                    for(int i=0; i < cmbDisp.Items.Count; i++)
                    {
                        disp = (CDisposition)cmbDisp.Items[i];
                        if (disp.Code == Basic_CRM.Properties.Settings.Default["AutoDispCode"].ToString())
                        {
                            mpApp.DisposeCall(mpApp.CurrentCall, disp);
                            tmrAutoDisp.Enabled = false;
                        }
                    }
                }
            }
            catch(Exception ex)
            {

            }
        }

        private void tmrAssignedServices_Tick(object sender, EventArgs e)
        {
            showAssignedServices();
        }

        private void pnlPopup_Paint(object sender, PaintEventArgs e)
        {

        }    

        private void tmrCallDuration_Tick(object sender, EventArgs e)
        {
            CallDuration += 1;
            lblCallDuration.Text = convertSS_HHMMSS(CallDuration);
        }
    }
}
