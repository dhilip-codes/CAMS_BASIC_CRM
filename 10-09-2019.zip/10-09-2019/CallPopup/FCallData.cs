using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using SamplePortalClient;

namespace CallPopup
{
	/// <summary>
	/// Summary description for Form2.
	/// </summary>
	public class FCallData : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox txtUserDefined1;
		private System.Windows.Forms.Label lblUserDefined1;
		private System.Windows.Forms.Label lblUserDefined2;
		private System.Windows.Forms.TextBox txtUserDefined2;
		private System.Windows.Forms.Label lblUserDefined3;
		private System.Windows.Forms.Label lblUserDefined4;
		private System.Windows.Forms.Label lblUserDefined5;
		private System.Windows.Forms.Label lblUserDefined6;
		private System.Windows.Forms.Label lblUserDefined7;
		private System.Windows.Forms.Label lblUserDefined8;
		private System.Windows.Forms.Label lblUserDefined9;
		private System.Windows.Forms.Label lblUserDefined10;
		private System.Windows.Forms.TextBox txtUserDefined9;
		private System.Windows.Forms.TextBox txtUserDefined10;
		private System.Windows.Forms.TextBox txtUserDefined3;
		private System.Windows.Forms.TextBox txtUserDefined4;
		private System.Windows.Forms.TextBox txtUserDefined5;
		private System.Windows.Forms.TextBox txtUserDefined6;
		private System.Windows.Forms.TextBox txtUserDefined7;
		private System.Windows.Forms.TextBox txtUserDefined8;
		private System.Windows.Forms.Label lblUserDefined12;
		private System.Windows.Forms.Label lblUserDefined11;
		private System.Windows.Forms.Label lblUserDefined19;
		private System.Windows.Forms.Label lblUserDefined18;
		private System.Windows.Forms.Label lblUserDefined17;
		private System.Windows.Forms.Label lblUserDefined16;
		private System.Windows.Forms.Label lblUserDefined15;
		private System.Windows.Forms.Label lblUserDefined14;
		private System.Windows.Forms.Label lblUserDefined13;
		private System.Windows.Forms.Label lblUserDefined20;
		private System.Windows.Forms.TextBox txtUserDefined14;
		private System.Windows.Forms.TextBox txtUserDefined13;
		private System.Windows.Forms.TextBox txtUserDefined12;
		private System.Windows.Forms.TextBox txtUserDefined11;
		private System.Windows.Forms.TextBox txtUserDefined20;
		private System.Windows.Forms.TextBox txtUserDefined19;
		private System.Windows.Forms.TextBox txtUserDefined18;
		private System.Windows.Forms.TextBox txtUserDefined17;
		private System.Windows.Forms.TextBox txtUserDefined16;
		private System.Windows.Forms.TextBox txtUserDefined15;
		private System.Windows.Forms.Label lblCallbackMemo;
		private System.Windows.Forms.TextBox txtCallbackMemo;
		private System.Windows.Forms.Button btnSave;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Label lblService;
		private System.Windows.Forms.TextBox txtService;
		private System.Windows.Forms.Label lblDNIS;
		private System.Windows.Forms.TextBox txtDNIS;
		private System.Windows.Forms.Label lblCallerId;
		private System.Windows.Forms.TextBox txtCallerId;
		private System.Windows.Forms.Label lblPhone;
		private System.Windows.Forms.TextBox txtPhone;
		private Panel pnlAnswerCall;
        private Button btnRejectCall;
        private Button btnAcceptCall;
        private Label lblAnswerCallCountDown;
		private CCall mpCall;
		private CApp mpApp;
		private System.Threading.Timer mpUnloadTimer;
        private int miAnswerCallTickCount;
        private System.Threading.Timer mpAnswerCallTimer;
        FList CallRejectionForm;

			/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public FCallData(CCall pCall, CApp pApp)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			mpCall = pCall;
			mpApp = pApp;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.txtUserDefined1 = new System.Windows.Forms.TextBox();
            this.lblUserDefined1 = new System.Windows.Forms.Label();
            this.lblUserDefined2 = new System.Windows.Forms.Label();
            this.txtUserDefined2 = new System.Windows.Forms.TextBox();
            this.lblUserDefined3 = new System.Windows.Forms.Label();
            this.txtUserDefined3 = new System.Windows.Forms.TextBox();
            this.lblUserDefined4 = new System.Windows.Forms.Label();
            this.txtUserDefined4 = new System.Windows.Forms.TextBox();
            this.lblUserDefined5 = new System.Windows.Forms.Label();
            this.txtUserDefined5 = new System.Windows.Forms.TextBox();
            this.lblUserDefined6 = new System.Windows.Forms.Label();
            this.txtUserDefined6 = new System.Windows.Forms.TextBox();
            this.lblUserDefined7 = new System.Windows.Forms.Label();
            this.txtUserDefined7 = new System.Windows.Forms.TextBox();
            this.lblUserDefined8 = new System.Windows.Forms.Label();
            this.txtUserDefined8 = new System.Windows.Forms.TextBox();
            this.lblUserDefined9 = new System.Windows.Forms.Label();
            this.txtUserDefined9 = new System.Windows.Forms.TextBox();
            this.lblUserDefined10 = new System.Windows.Forms.Label();
            this.txtUserDefined10 = new System.Windows.Forms.TextBox();
            this.lblUserDefined20 = new System.Windows.Forms.Label();
            this.txtUserDefined20 = new System.Windows.Forms.TextBox();
            this.lblUserDefined19 = new System.Windows.Forms.Label();
            this.txtUserDefined19 = new System.Windows.Forms.TextBox();
            this.lblUserDefined18 = new System.Windows.Forms.Label();
            this.txtUserDefined18 = new System.Windows.Forms.TextBox();
            this.lblUserDefined17 = new System.Windows.Forms.Label();
            this.txtUserDefined17 = new System.Windows.Forms.TextBox();
            this.lblUserDefined16 = new System.Windows.Forms.Label();
            this.txtUserDefined16 = new System.Windows.Forms.TextBox();
            this.lblUserDefined15 = new System.Windows.Forms.Label();
            this.txtUserDefined15 = new System.Windows.Forms.TextBox();
            this.lblUserDefined14 = new System.Windows.Forms.Label();
            this.txtUserDefined14 = new System.Windows.Forms.TextBox();
            this.lblUserDefined13 = new System.Windows.Forms.Label();
            this.txtUserDefined13 = new System.Windows.Forms.TextBox();
            this.lblUserDefined12 = new System.Windows.Forms.Label();
            this.txtUserDefined12 = new System.Windows.Forms.TextBox();
            this.lblUserDefined11 = new System.Windows.Forms.Label();
            this.txtUserDefined11 = new System.Windows.Forms.TextBox();
            this.txtCallbackMemo = new System.Windows.Forms.TextBox();
            this.lblCallbackMemo = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lblService = new System.Windows.Forms.Label();
            this.txtService = new System.Windows.Forms.TextBox();
            this.lblDNIS = new System.Windows.Forms.Label();
            this.txtDNIS = new System.Windows.Forms.TextBox();
            this.lblCallerId = new System.Windows.Forms.Label();
            this.txtCallerId = new System.Windows.Forms.TextBox();
            this.lblPhone = new System.Windows.Forms.Label();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.pnlAnswerCall = new System.Windows.Forms.Panel();
            this.lblAnswerCallCountDown = new System.Windows.Forms.Label();
            this.btnRejectCall = new System.Windows.Forms.Button();
            this.btnAcceptCall = new System.Windows.Forms.Button();
            this.pnlAnswerCall.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtUserDefined1
            // 
            this.txtUserDefined1.Location = new System.Drawing.Point(127, 83);
            this.txtUserDefined1.Name = "txtUserDefined1";
            this.txtUserDefined1.Size = new System.Drawing.Size(180, 20);
            this.txtUserDefined1.TabIndex = 0;
            this.txtUserDefined1.TextChanged += new System.EventHandler(this.txtUserDefined1_TextChanged);
            // 
            // lblUserDefined1
            // 
            this.lblUserDefined1.Location = new System.Drawing.Point(20, 82);
            this.lblUserDefined1.Name = "lblUserDefined1";
            this.lblUserDefined1.Size = new System.Drawing.Size(100, 21);
            this.lblUserDefined1.TabIndex = 1;
            this.lblUserDefined1.Text = "User Defined";
            this.lblUserDefined1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblUserDefined1.Click += new System.EventHandler(this.lblUserDefined1_Click);
            // 
            // lblUserDefined2
            // 
            this.lblUserDefined2.Location = new System.Drawing.Point(20, 110);
            this.lblUserDefined2.Name = "lblUserDefined2";
            this.lblUserDefined2.Size = new System.Drawing.Size(100, 21);
            this.lblUserDefined2.TabIndex = 3;
            this.lblUserDefined2.Text = "User Defined";
            this.lblUserDefined2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblUserDefined2.Click += new System.EventHandler(this.lblUserDefined2_Click);
            // 
            // txtUserDefined2
            // 
            this.txtUserDefined2.Location = new System.Drawing.Point(127, 111);
            this.txtUserDefined2.Name = "txtUserDefined2";
            this.txtUserDefined2.Size = new System.Drawing.Size(180, 20);
            this.txtUserDefined2.TabIndex = 2;
            this.txtUserDefined2.TextChanged += new System.EventHandler(this.txtUserDefined2_TextChanged);
            // 
            // lblUserDefined3
            // 
            this.lblUserDefined3.Location = new System.Drawing.Point(20, 138);
            this.lblUserDefined3.Name = "lblUserDefined3";
            this.lblUserDefined3.Size = new System.Drawing.Size(100, 21);
            this.lblUserDefined3.TabIndex = 5;
            this.lblUserDefined3.Text = "User Defined";
            this.lblUserDefined3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblUserDefined3.Click += new System.EventHandler(this.lblUserDefined3_Click);
            // 
            // txtUserDefined3
            // 
            this.txtUserDefined3.Location = new System.Drawing.Point(127, 139);
            this.txtUserDefined3.Name = "txtUserDefined3";
            this.txtUserDefined3.Size = new System.Drawing.Size(180, 20);
            this.txtUserDefined3.TabIndex = 4;
            this.txtUserDefined3.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lblUserDefined4
            // 
            this.lblUserDefined4.Location = new System.Drawing.Point(20, 166);
            this.lblUserDefined4.Name = "lblUserDefined4";
            this.lblUserDefined4.Size = new System.Drawing.Size(100, 20);
            this.lblUserDefined4.TabIndex = 7;
            this.lblUserDefined4.Text = "User Defined";
            this.lblUserDefined4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblUserDefined4.Click += new System.EventHandler(this.lblUserDefined4_Click);
            // 
            // txtUserDefined4
            // 
            this.txtUserDefined4.Location = new System.Drawing.Point(127, 166);
            this.txtUserDefined4.Name = "txtUserDefined4";
            this.txtUserDefined4.Size = new System.Drawing.Size(180, 20);
            this.txtUserDefined4.TabIndex = 6;
            this.txtUserDefined4.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // lblUserDefined5
            // 
            this.lblUserDefined5.Location = new System.Drawing.Point(20, 193);
            this.lblUserDefined5.Name = "lblUserDefined5";
            this.lblUserDefined5.Size = new System.Drawing.Size(100, 21);
            this.lblUserDefined5.TabIndex = 9;
            this.lblUserDefined5.Text = "User Defined";
            this.lblUserDefined5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblUserDefined5.Click += new System.EventHandler(this.lblUserDefined5_Click);
            // 
            // txtUserDefined5
            // 
            this.txtUserDefined5.Location = new System.Drawing.Point(127, 194);
            this.txtUserDefined5.Name = "txtUserDefined5";
            this.txtUserDefined5.Size = new System.Drawing.Size(180, 20);
            this.txtUserDefined5.TabIndex = 8;
            this.txtUserDefined5.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // lblUserDefined6
            // 
            this.lblUserDefined6.Location = new System.Drawing.Point(20, 221);
            this.lblUserDefined6.Name = "lblUserDefined6";
            this.lblUserDefined6.Size = new System.Drawing.Size(100, 21);
            this.lblUserDefined6.TabIndex = 11;
            this.lblUserDefined6.Text = "User Defined";
            this.lblUserDefined6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblUserDefined6.Click += new System.EventHandler(this.lblUserDefined6_Click);
            // 
            // txtUserDefined6
            // 
            this.txtUserDefined6.Location = new System.Drawing.Point(127, 222);
            this.txtUserDefined6.Name = "txtUserDefined6";
            this.txtUserDefined6.Size = new System.Drawing.Size(180, 20);
            this.txtUserDefined6.TabIndex = 10;
            this.txtUserDefined6.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // lblUserDefined7
            // 
            this.lblUserDefined7.Location = new System.Drawing.Point(20, 249);
            this.lblUserDefined7.Name = "lblUserDefined7";
            this.lblUserDefined7.Size = new System.Drawing.Size(100, 21);
            this.lblUserDefined7.TabIndex = 13;
            this.lblUserDefined7.Text = "User Defined";
            this.lblUserDefined7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblUserDefined7.Click += new System.EventHandler(this.lblUserDefined7_Click);
            // 
            // txtUserDefined7
            // 
            this.txtUserDefined7.Location = new System.Drawing.Point(127, 250);
            this.txtUserDefined7.Name = "txtUserDefined7";
            this.txtUserDefined7.Size = new System.Drawing.Size(180, 20);
            this.txtUserDefined7.TabIndex = 12;
            this.txtUserDefined7.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // lblUserDefined8
            // 
            this.lblUserDefined8.Location = new System.Drawing.Point(20, 276);
            this.lblUserDefined8.Name = "lblUserDefined8";
            this.lblUserDefined8.Size = new System.Drawing.Size(100, 21);
            this.lblUserDefined8.TabIndex = 15;
            this.lblUserDefined8.Text = "User Defined";
            this.lblUserDefined8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblUserDefined8.Click += new System.EventHandler(this.lblUserDefined8_Click);
            // 
            // txtUserDefined8
            // 
            this.txtUserDefined8.Location = new System.Drawing.Point(127, 277);
            this.txtUserDefined8.Name = "txtUserDefined8";
            this.txtUserDefined8.Size = new System.Drawing.Size(180, 20);
            this.txtUserDefined8.TabIndex = 14;
            this.txtUserDefined8.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // lblUserDefined9
            // 
            this.lblUserDefined9.Location = new System.Drawing.Point(20, 304);
            this.lblUserDefined9.Name = "lblUserDefined9";
            this.lblUserDefined9.Size = new System.Drawing.Size(100, 21);
            this.lblUserDefined9.TabIndex = 17;
            this.lblUserDefined9.Text = "User Defined";
            this.lblUserDefined9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblUserDefined9.Click += new System.EventHandler(this.lblUserDefined9_Click);
            // 
            // txtUserDefined9
            // 
            this.txtUserDefined9.Location = new System.Drawing.Point(127, 305);
            this.txtUserDefined9.Name = "txtUserDefined9";
            this.txtUserDefined9.Size = new System.Drawing.Size(180, 20);
            this.txtUserDefined9.TabIndex = 16;
            this.txtUserDefined9.TextChanged += new System.EventHandler(this.txtUserDefined9_TextChanged);
            // 
            // lblUserDefined10
            // 
            this.lblUserDefined10.Location = new System.Drawing.Point(20, 332);
            this.lblUserDefined10.Name = "lblUserDefined10";
            this.lblUserDefined10.Size = new System.Drawing.Size(100, 21);
            this.lblUserDefined10.TabIndex = 19;
            this.lblUserDefined10.Text = "User Defined";
            this.lblUserDefined10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblUserDefined10.Click += new System.EventHandler(this.lblUserDefined10_Click);
            // 
            // txtUserDefined10
            // 
            this.txtUserDefined10.Location = new System.Drawing.Point(127, 333);
            this.txtUserDefined10.Name = "txtUserDefined10";
            this.txtUserDefined10.Size = new System.Drawing.Size(180, 20);
            this.txtUserDefined10.TabIndex = 18;
            this.txtUserDefined10.TextChanged += new System.EventHandler(this.txtUserDefined10_TextChanged);
            // 
            // lblUserDefined20
            // 
            this.lblUserDefined20.Location = new System.Drawing.Point(327, 333);
            this.lblUserDefined20.Name = "lblUserDefined20";
            this.lblUserDefined20.Size = new System.Drawing.Size(100, 21);
            this.lblUserDefined20.TabIndex = 39;
            this.lblUserDefined20.Text = "User Defined";
            this.lblUserDefined20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblUserDefined20.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtUserDefined20
            // 
            this.txtUserDefined20.Location = new System.Drawing.Point(433, 333);
            this.txtUserDefined20.Name = "txtUserDefined20";
            this.txtUserDefined20.Size = new System.Drawing.Size(180, 20);
            this.txtUserDefined20.TabIndex = 38;
            // 
            // lblUserDefined19
            // 
            this.lblUserDefined19.Location = new System.Drawing.Point(327, 305);
            this.lblUserDefined19.Name = "lblUserDefined19";
            this.lblUserDefined19.Size = new System.Drawing.Size(100, 21);
            this.lblUserDefined19.TabIndex = 37;
            this.lblUserDefined19.Text = "User Defined";
            this.lblUserDefined19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtUserDefined19
            // 
            this.txtUserDefined19.Location = new System.Drawing.Point(433, 305);
            this.txtUserDefined19.Name = "txtUserDefined19";
            this.txtUserDefined19.Size = new System.Drawing.Size(180, 20);
            this.txtUserDefined19.TabIndex = 36;
            // 
            // lblUserDefined18
            // 
            this.lblUserDefined18.Location = new System.Drawing.Point(327, 277);
            this.lblUserDefined18.Name = "lblUserDefined18";
            this.lblUserDefined18.Size = new System.Drawing.Size(100, 21);
            this.lblUserDefined18.TabIndex = 35;
            this.lblUserDefined18.Text = "User Defined";
            this.lblUserDefined18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtUserDefined18
            // 
            this.txtUserDefined18.Location = new System.Drawing.Point(433, 277);
            this.txtUserDefined18.Name = "txtUserDefined18";
            this.txtUserDefined18.Size = new System.Drawing.Size(180, 20);
            this.txtUserDefined18.TabIndex = 34;
            // 
            // lblUserDefined17
            // 
            this.lblUserDefined17.Location = new System.Drawing.Point(327, 250);
            this.lblUserDefined17.Name = "lblUserDefined17";
            this.lblUserDefined17.Size = new System.Drawing.Size(100, 20);
            this.lblUserDefined17.TabIndex = 33;
            this.lblUserDefined17.Text = "User Defined";
            this.lblUserDefined17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtUserDefined17
            // 
            this.txtUserDefined17.Location = new System.Drawing.Point(433, 250);
            this.txtUserDefined17.Name = "txtUserDefined17";
            this.txtUserDefined17.Size = new System.Drawing.Size(180, 20);
            this.txtUserDefined17.TabIndex = 32;
            // 
            // lblUserDefined16
            // 
            this.lblUserDefined16.Location = new System.Drawing.Point(327, 222);
            this.lblUserDefined16.Name = "lblUserDefined16";
            this.lblUserDefined16.Size = new System.Drawing.Size(100, 21);
            this.lblUserDefined16.TabIndex = 31;
            this.lblUserDefined16.Text = "User Defined";
            this.lblUserDefined16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtUserDefined16
            // 
            this.txtUserDefined16.Location = new System.Drawing.Point(433, 222);
            this.txtUserDefined16.Name = "txtUserDefined16";
            this.txtUserDefined16.Size = new System.Drawing.Size(180, 20);
            this.txtUserDefined16.TabIndex = 30;
            // 
            // lblUserDefined15
            // 
            this.lblUserDefined15.Location = new System.Drawing.Point(327, 194);
            this.lblUserDefined15.Name = "lblUserDefined15";
            this.lblUserDefined15.Size = new System.Drawing.Size(100, 21);
            this.lblUserDefined15.TabIndex = 29;
            this.lblUserDefined15.Text = "User Defined";
            this.lblUserDefined15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtUserDefined15
            // 
            this.txtUserDefined15.Location = new System.Drawing.Point(433, 194);
            this.txtUserDefined15.Name = "txtUserDefined15";
            this.txtUserDefined15.Size = new System.Drawing.Size(180, 20);
            this.txtUserDefined15.TabIndex = 28;
            this.txtUserDefined15.TextChanged += new System.EventHandler(this.textBox6_TextChanged_1);
            // 
            // lblUserDefined14
            // 
            this.lblUserDefined14.Location = new System.Drawing.Point(327, 166);
            this.lblUserDefined14.Name = "lblUserDefined14";
            this.lblUserDefined14.Size = new System.Drawing.Size(100, 21);
            this.lblUserDefined14.TabIndex = 27;
            this.lblUserDefined14.Text = "User Defined";
            this.lblUserDefined14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtUserDefined14
            // 
            this.txtUserDefined14.Location = new System.Drawing.Point(433, 166);
            this.txtUserDefined14.Name = "txtUserDefined14";
            this.txtUserDefined14.Size = new System.Drawing.Size(180, 20);
            this.txtUserDefined14.TabIndex = 26;
            // 
            // lblUserDefined13
            // 
            this.lblUserDefined13.Location = new System.Drawing.Point(327, 139);
            this.lblUserDefined13.Name = "lblUserDefined13";
            this.lblUserDefined13.Size = new System.Drawing.Size(100, 20);
            this.lblUserDefined13.TabIndex = 25;
            this.lblUserDefined13.Text = "User Defined";
            this.lblUserDefined13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtUserDefined13
            // 
            this.txtUserDefined13.Location = new System.Drawing.Point(433, 139);
            this.txtUserDefined13.Name = "txtUserDefined13";
            this.txtUserDefined13.Size = new System.Drawing.Size(180, 20);
            this.txtUserDefined13.TabIndex = 24;
            // 
            // lblUserDefined12
            // 
            this.lblUserDefined12.Location = new System.Drawing.Point(327, 111);
            this.lblUserDefined12.Name = "lblUserDefined12";
            this.lblUserDefined12.Size = new System.Drawing.Size(100, 21);
            this.lblUserDefined12.TabIndex = 23;
            this.lblUserDefined12.Text = "User Defined";
            this.lblUserDefined12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtUserDefined12
            // 
            this.txtUserDefined12.Location = new System.Drawing.Point(433, 111);
            this.txtUserDefined12.Name = "txtUserDefined12";
            this.txtUserDefined12.Size = new System.Drawing.Size(180, 20);
            this.txtUserDefined12.TabIndex = 22;
            // 
            // lblUserDefined11
            // 
            this.lblUserDefined11.Location = new System.Drawing.Point(327, 83);
            this.lblUserDefined11.Name = "lblUserDefined11";
            this.lblUserDefined11.Size = new System.Drawing.Size(100, 21);
            this.lblUserDefined11.TabIndex = 21;
            this.lblUserDefined11.Text = "User Defined";
            this.lblUserDefined11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtUserDefined11
            // 
            this.txtUserDefined11.Location = new System.Drawing.Point(433, 83);
            this.txtUserDefined11.Name = "txtUserDefined11";
            this.txtUserDefined11.Size = new System.Drawing.Size(180, 20);
            this.txtUserDefined11.TabIndex = 20;
            // 
            // txtCallbackMemo
            // 
            this.txtCallbackMemo.Location = new System.Drawing.Point(20, 438);
            this.txtCallbackMemo.Multiline = true;
            this.txtCallbackMemo.Name = "txtCallbackMemo";
            this.txtCallbackMemo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtCallbackMemo.Size = new System.Drawing.Size(593, 62);
            this.txtCallbackMemo.TabIndex = 40;
            this.txtCallbackMemo.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // lblCallbackMemo
            // 
            this.lblCallbackMemo.Location = new System.Drawing.Point(20, 415);
            this.lblCallbackMemo.Name = "lblCallbackMemo";
            this.lblCallbackMemo.Size = new System.Drawing.Size(100, 21);
            this.lblCallbackMemo.TabIndex = 41;
            this.lblCallbackMemo.Text = "Callback Memo:";
            this.lblCallbackMemo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(463, 515);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(72, 26);
            this.btnSave.TabIndex = 42;
            this.btnSave.Text = "Save";
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(544, 515);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(72, 26);
            this.btnCancel.TabIndex = 43;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // lblService
            // 
            this.lblService.Location = new System.Drawing.Point(20, 14);
            this.lblService.Name = "lblService";
            this.lblService.Size = new System.Drawing.Size(100, 21);
            this.lblService.TabIndex = 45;
            this.lblService.Text = "Service";
            this.lblService.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtService
            // 
            this.txtService.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtService.Location = new System.Drawing.Point(127, 14);
            this.txtService.Name = "txtService";
            this.txtService.Size = new System.Drawing.Size(180, 20);
            this.txtService.TabIndex = 44;
            // 
            // lblDNIS
            // 
            this.lblDNIS.Location = new System.Drawing.Point(20, 37);
            this.lblDNIS.Name = "lblDNIS";
            this.lblDNIS.Size = new System.Drawing.Size(100, 21);
            this.lblDNIS.TabIndex = 47;
            this.lblDNIS.Text = "DNIS";
            this.lblDNIS.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtDNIS
            // 
            this.txtDNIS.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtDNIS.Location = new System.Drawing.Point(127, 37);
            this.txtDNIS.Name = "txtDNIS";
            this.txtDNIS.Size = new System.Drawing.Size(180, 20);
            this.txtDNIS.TabIndex = 46;
            // 
            // lblCallerId
            // 
            this.lblCallerId.Location = new System.Drawing.Point(327, 35);
            this.lblCallerId.Name = "lblCallerId";
            this.lblCallerId.Size = new System.Drawing.Size(100, 20);
            this.lblCallerId.TabIndex = 51;
            this.lblCallerId.Text = "CallerId";
            this.lblCallerId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtCallerId
            // 
            this.txtCallerId.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtCallerId.Location = new System.Drawing.Point(433, 37);
            this.txtCallerId.Name = "txtCallerId";
            this.txtCallerId.Size = new System.Drawing.Size(180, 20);
            this.txtCallerId.TabIndex = 50;
            // 
            // lblPhone
            // 
            this.lblPhone.Location = new System.Drawing.Point(327, 14);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(100, 21);
            this.lblPhone.TabIndex = 49;
            this.lblPhone.Text = "Phone";
            this.lblPhone.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtPhone
            // 
            this.txtPhone.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.txtPhone.Location = new System.Drawing.Point(433, 14);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(180, 20);
            this.txtPhone.TabIndex = 48;
            // 
            // pnlAnswerCall
            // 
            this.pnlAnswerCall.Controls.Add(this.lblAnswerCallCountDown);
            this.pnlAnswerCall.Controls.Add(this.btnRejectCall);
            this.pnlAnswerCall.Controls.Add(this.btnAcceptCall);
            this.pnlAnswerCall.Location = new System.Drawing.Point(207, 372);
            this.pnlAnswerCall.Name = "pnlAnswerCall";
            this.pnlAnswerCall.Size = new System.Drawing.Size(220, 34);
            this.pnlAnswerCall.TabIndex = 52;
            // 
            // lblAnswerCallCountDown
            // 
            this.lblAnswerCallCountDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAnswerCallCountDown.Location = new System.Drawing.Point(81, 9);
            this.lblAnswerCallCountDown.Name = "lblAnswerCallCountDown";
            this.lblAnswerCallCountDown.Size = new System.Drawing.Size(59, 18);
            this.lblAnswerCallCountDown.TabIndex = 2;
            this.lblAnswerCallCountDown.Text = "000";
            this.lblAnswerCallCountDown.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnRejectCall
            // 
            this.btnRejectCall.Location = new System.Drawing.Point(144, 5);
            this.btnRejectCall.Name = "btnRejectCall";
            this.btnRejectCall.Size = new System.Drawing.Size(72, 26);
            this.btnRejectCall.TabIndex = 1;
            this.btnRejectCall.Text = "Reject";
            this.btnRejectCall.UseVisualStyleBackColor = true;
            this.btnRejectCall.Click += new System.EventHandler(this.btnRejectCall_Click);
            // 
            // btnAcceptCall
            // 
            this.btnAcceptCall.Location = new System.Drawing.Point(5, 5);
            this.btnAcceptCall.Name = "btnAcceptCall";
            this.btnAcceptCall.Size = new System.Drawing.Size(72, 26);
            this.btnAcceptCall.TabIndex = 0;
            this.btnAcceptCall.Text = "Accept";
            this.btnAcceptCall.UseVisualStyleBackColor = true;
            this.btnAcceptCall.Click += new System.EventHandler(this.btnAcceptCall_Click);
            // 
            // FCallData
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(634, 418);
            this.Controls.Add(this.pnlAnswerCall);
            this.Controls.Add(this.lblCallerId);
            this.Controls.Add(this.txtCallerId);
            this.Controls.Add(this.lblPhone);
            this.Controls.Add(this.txtPhone);
            this.Controls.Add(this.lblDNIS);
            this.Controls.Add(this.txtDNIS);
            this.Controls.Add(this.lblService);
            this.Controls.Add(this.txtService);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.lblCallbackMemo);
            this.Controls.Add(this.txtCallbackMemo);
            this.Controls.Add(this.lblUserDefined20);
            this.Controls.Add(this.txtUserDefined20);
            this.Controls.Add(this.lblUserDefined19);
            this.Controls.Add(this.txtUserDefined19);
            this.Controls.Add(this.lblUserDefined18);
            this.Controls.Add(this.txtUserDefined18);
            this.Controls.Add(this.lblUserDefined17);
            this.Controls.Add(this.txtUserDefined17);
            this.Controls.Add(this.lblUserDefined16);
            this.Controls.Add(this.txtUserDefined16);
            this.Controls.Add(this.lblUserDefined15);
            this.Controls.Add(this.txtUserDefined15);
            this.Controls.Add(this.lblUserDefined14);
            this.Controls.Add(this.txtUserDefined14);
            this.Controls.Add(this.lblUserDefined13);
            this.Controls.Add(this.txtUserDefined13);
            this.Controls.Add(this.lblUserDefined12);
            this.Controls.Add(this.txtUserDefined12);
            this.Controls.Add(this.lblUserDefined11);
            this.Controls.Add(this.txtUserDefined11);
            this.Controls.Add(this.lblUserDefined10);
            this.Controls.Add(this.txtUserDefined10);
            this.Controls.Add(this.lblUserDefined9);
            this.Controls.Add(this.txtUserDefined9);
            this.Controls.Add(this.lblUserDefined8);
            this.Controls.Add(this.txtUserDefined8);
            this.Controls.Add(this.lblUserDefined7);
            this.Controls.Add(this.txtUserDefined7);
            this.Controls.Add(this.lblUserDefined6);
            this.Controls.Add(this.txtUserDefined6);
            this.Controls.Add(this.lblUserDefined5);
            this.Controls.Add(this.txtUserDefined5);
            this.Controls.Add(this.lblUserDefined4);
            this.Controls.Add(this.txtUserDefined4);
            this.Controls.Add(this.lblUserDefined3);
            this.Controls.Add(this.txtUserDefined3);
            this.Controls.Add(this.lblUserDefined2);
            this.Controls.Add(this.txtUserDefined2);
            this.Controls.Add(this.lblUserDefined1);
            this.Controls.Add(this.txtUserDefined1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "FCallData";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Call Data";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FCallData_FormClosed);
            this.Load += new System.EventHandler(this.FCallData_Load);
            this.pnlAnswerCall.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

        public void CApp_StateChange(Object pSender, CStateChangeArgs pArgs)
        {
            //Form updates can/should only be performed by the thread that created the form (in this case, the main thread).
            //If this is not the main thread then invoke this method on the main thread and return.
            if (this.InvokeRequired)
            {
                this.Invoke(new StateChangeHandler(this.CApp_StateChange), new Object[] { pSender, pArgs });
                return;
            }

            switch (pArgs.NewState.Id)
            {
                case AgentStateId.asACTIVE:
                case AgentStateId.asACTIVE_INTERNAL:
                    if (mpCall.ResponseRequired && mpAnswerCallTimer != null)
                    {
                        ResetAnswerCallPanel();
 
                        //Hide panel
                        pnlAnswerCall.Visible = false;

                        //Start Unload Timer which fires only once in the next 4 seconds
                        System.Threading.TimerCallback timerDelegate = new System.Threading.TimerCallback(mpUnloadTimer_Fire);
                        mpUnloadTimer = new System.Threading.Timer(timerDelegate, this, 4000, System.Threading.Timeout.Infinite);
                    }
                    break;
                
                //If went to Idle or NotReady (eg, because Call offering was rejected or timed out), close the form
                case AgentStateId.asIDLE:
                case AgentStateId.asNOT_READY:
                    this.Close();
                    break;
            }
         }

		private void FCallData_Load(object sender, System.EventArgs e)
		{
            const int FREQ_GSHARP = 415;
            const int DURATION_EIGHTH = 100000;

            mpApp.StateChange += new StateChangeHandler(this.CApp_StateChange);

			txtService.Text = mpApp.AssignedServices.GetByKey(mpCall.ServiceID).ServiceName;
			txtDNIS.Text = mpCall.Dnis;
			txtPhone.Text = mpCall.PhoneNumber;
			txtCallerId.Text = mpCall.CallerID;

			txtUserDefined1.Text = mpCall.UserDefinedItems[0].value;
			txtUserDefined2.Text = mpCall.UserDefinedItems[1].value;
			txtUserDefined3.Text = mpCall.UserDefinedItems[2].value;
			txtUserDefined4.Text = mpCall.UserDefinedItems[3].value;
			txtUserDefined5.Text = mpCall.UserDefinedItems[4].value;
			txtUserDefined6.Text = mpCall.UserDefinedItems[5].value;
			txtUserDefined7.Text = mpCall.UserDefinedItems[6].value;
			txtUserDefined8.Text = mpCall.UserDefinedItems[7].value;
			txtUserDefined9.Text = mpCall.UserDefinedItems[8].value;
			txtUserDefined10.Text = mpCall.UserDefinedItems[9].value;
			txtUserDefined11.Text = mpCall.UserDefinedItems[10].value;
			txtUserDefined12.Text = mpCall.UserDefinedItems[11].value;
			txtUserDefined13.Text = mpCall.UserDefinedItems[12].value;
			txtUserDefined14.Text = mpCall.UserDefinedItems[13].value;
			txtUserDefined15.Text = mpCall.UserDefinedItems[14].value;
			txtUserDefined16.Text = mpCall.UserDefinedItems[15].value;
			txtUserDefined17.Text = mpCall.UserDefinedItems[16].value;
			txtUserDefined18.Text = mpCall.UserDefinedItems[17].value;
			txtUserDefined19.Text = mpCall.UserDefinedItems[18].value;
			txtUserDefined20.Text = mpCall.UserDefinedItems[19].value;

            foreach (Control ctl in this.Controls)
                if (ctl is TextBoxBase)
                    ((TextBoxBase)ctl).ReadOnly = true;
            
            //If call requires a response, show answer call panel
            if (mpCall.ResponseRequired)
            {
                miAnswerCallTickCount = mpCall.ResponseTimeoutInSecs;

                lblAnswerCallCountDown.Text = miAnswerCallTickCount.ToString("000") ;

                pnlAnswerCall.Visible = true;

                if (mpCall.PlayAudioAlert)
                {
                    Console.WriteLine("Playing beep...");
                    Console.Beep(FREQ_GSHARP, DURATION_EIGHTH);
                }

                //Start Answer Call Timer which fires indefinitely every second
                System.Threading.TimerCallback timerDelegate = new System.Threading.TimerCallback(mpAnswerCallTimer_Fire);
                mpAnswerCallTimer = new System.Threading.Timer(timerDelegate, this, 1000, 1000);
            }

            //Otherwise, hide answer call panel and start Unload Timer
            else
            {
                pnlAnswerCall.Visible = false;

                //Start Unload Timer which fires only once in the next 4 seconds
                System.Threading.TimerCallback timerDelegate = new System.Threading.TimerCallback(mpUnloadTimer_Fire);
                mpUnloadTimer = new System.Threading.Timer(timerDelegate, this, 14000, System.Threading.Timeout.Infinite);
            }

            //Make form the topmost one
            //this.TopMost = true;
		}

        public void mpUnloadTimer_Fire(Object state)
		{
			if (this.InvokeRequired)
			{
                this.Invoke(new System.Threading.TimerCallback(mpUnloadTimer_Fire), new Object[] { state });
                return;
            }

            mpUnloadTimer.Dispose();
			mpUnloadTimer = null;
			this.Close();
		}

        public void mpAnswerCallTimer_Fire(Object state)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new System.Threading.TimerCallback(mpAnswerCallTimer_Fire), new Object[] { state });
                return;
            }

            miAnswerCallTickCount--;

            if (miAnswerCallTickCount < 0)
                ResetAnswerCallPanel();
            else
                lblAnswerCallCountDown.Text = miAnswerCallTickCount.ToString("000");
        }

        private void ResetAnswerCallPanel()
        {
            if (mpAnswerCallTimer != null)
                mpAnswerCallTimer.Dispose();
            mpAnswerCallTimer = null;

            btnAcceptCall.Enabled = false;
            btnRejectCall.Enabled = false;

            //Unload rejections reasons dialog, if loaded
            if (CallRejectionForm != null)
                CallRejectionForm.Close();
            CallRejectionForm = null;
        }

		private void textBox2_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void textBox5_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void textBox6_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void textBox4_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void textBox1_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void textBox3_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void lblUserDefined10_Click(object sender, System.EventArgs e)
		{
		
		}

		private void txtUserDefined10_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void lblUserDefined7_Click(object sender, System.EventArgs e)
		{
		
		}

		private void lblUserDefined8_Click(object sender, System.EventArgs e)
		{
		
		}

		private void lblUserDefined1_Click(object sender, System.EventArgs e)
		{
		
		}

		private void label10_Click(object sender, System.EventArgs e)
		{
		
		}

		private void lblUserDefined2_Click(object sender, System.EventArgs e)
		{
		
		}

		private void lblUserDefined6_Click(object sender, System.EventArgs e)
		{
		
		}

		private void lblUserDefined9_Click(object sender, System.EventArgs e)
		{
		
		}

		private void txtUserDefined9_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void lblUserDefined4_Click(object sender, System.EventArgs e)
		{
		
		}

		private void lblUserDefined3_Click(object sender, System.EventArgs e)
		{
		
		}

		private void txtUserDefined1_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void lblUserDefined5_Click(object sender, System.EventArgs e)
		{
		
		}

		private void txtUserDefined2_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void label1_Click(object sender, System.EventArgs e)
		{
		
		}

		private void textBox6_TextChanged_1(object sender, System.EventArgs e)
		{
		
		}

		private void textBox1_TextChanged_1(object sender, System.EventArgs e)
		{
		
		}

        private void btnCancel_Click(object sender, EventArgs e)
        {

        }

        private void btnAcceptCall_Click(object sender, EventArgs e)
        {
            try
            {
                mpApp.AcceptCall();
            }
            catch (Exception pError)
            {
                Console.WriteLine(pError.StackTrace);
            }
        }

        private void btnRejectCall_Click(object sender, EventArgs e)
        {
            try
            {
                if (mpCall.RejectionReasonRequired)
                {
                    //Prompt user to specify reason
                    if (CallRejectionForm != null)
                        CallRejectionForm.Close();
             
                    CallRejectionForm = new FList(mpApp, mpApp.CallRejectionReasons);
                    CallRejectionForm.Text = "Choose a Call-Rejection Reason";
                    
                    if (CallRejectionForm.ShowDialog() == DialogResult.OK)
                        mpApp.RejectCall((CCallRejectionReason)CallRejectionForm.SelectedItem);
                }
                else
                    mpApp.RejectCall();
            }
            catch (Exception pError)
            {
                Console.WriteLine(pError.StackTrace);
            }
        }

        private void FCallData_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                if (mpUnloadTimer != null)
                    mpUnloadTimer.Dispose();
                mpUnloadTimer = null;

                if (mpAnswerCallTimer != null)
                    mpAnswerCallTimer.Dispose();
                mpAnswerCallTimer = null;

                //Unload rejections reasons dialog, if loaded
                if (CallRejectionForm != null)
                    CallRejectionForm.Close();
                CallRejectionForm = null;

            }
            catch (Exception pError)
            {
                Console.WriteLine(pError.StackTrace);
            }
        }
	}
}
