﻿using System;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using SamplePortalClient.EPEventsWS;
using SamplePortalClient.EPAgentWS;
using SamplePortalClient;

namespace CallPopup
{
    public partial class FLogin : Form
    {
        private CApp mpApp;
        String logContent = "";

        public FLogin(CApp pApp)
        {
            InitializeComponent();
            mpApp = pApp;
        }

        private void FLogin_Load(object sender, EventArgs e)
        {
            try
            {
                txtUserID.Text = "";
                txtPassword.Text = "";
                txtStation.Text = "";
                txtPortal.Text = Basic_CRM.Properties.Settings.Default.Portal;
                logContent = PadDateCrLf("Login Page Loaded");
            }
            catch (Exception ex)
            {
                logContent += "Error : " + ex.Message;
            }
            finally
            {
                WriteLog("", logContent);
            }
        }

        [STAThread]
        public static void Main()
        {
            Console.WriteLine("Initializing App...");
            //CommanTC.WriteLog("Initializing App...", CommanTC.userid, CommanTC.extn);
            CApp pApp = new CApp();

            Console.WriteLine("CurrentState is " + pApp.CurrentState.GetType());
            //CommanTC.WriteLog("CurrentState is : " + pApp.CurrentState.GetType(), CommanTC.userid, CommanTC.extn);

            FLogin pLoginForm = new FLogin(pApp);
            pLoginForm.ShowDialog();

            if (pApp.CurrentState is CStateAuthenticated)
            {
                FToolbar pToolbarForm = new FToolbar(pApp);
                pToolbarForm.ShowDialog();
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            logContent = PadDateCrLf("Login Attempt :");
            logContent += PadDateCrLf("    User ID  : " + txtUserID.Text.Trim());
            logContent += PadDateCrLf("    Password : " + txtPassword.Text.Trim().Length + " Char/s");
            logContent += PadDateCrLf("    Station  : " + txtStation.Text.Trim());
            logContent += PadDateCrLf("    Portal   : " + txtPortal.Text.Trim());

            try
            {
                mpApp.Login(this.txtUserID.Text, this.txtPassword.Text, this.txtStation.Text, this.txtPortal.Text);
                //CommanTC.userid = txtUserID.Text;
                //CommanTC.extn = txtStation.Text;
                this.Close();
            }
            catch (Exception pError)
            {
                Console.WriteLine(pError.StackTrace);
                logContent += PadDateCrLf("Login Failed : " + pError.Message);
                MessageBox.Show(pError.Message, "Login Failed");
                //CommanTC.WriteLog("FToolbar LOgin Error :" + pError.StackTrace, CommanTC.userid, CommanTC.extn);
            }
            finally
            {
                WriteLog(txtUserID.Text.Trim(), logContent);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                logContent = PadDateCrLf("Cancel Opted. Terminating Application.");
                Application.ExitThread();
            }
            catch (Exception ex)
            {
                logContent += PadDateCrLf("Error : " + ex.Message);
            }
            finally
            {
                WriteLog(txtUserID.Text.Trim(), logContent);
            }
        }

        private String PadDateCrLf(String val)
        {
            try
            {
                return DateTime.Now.ToString("dd-MMM-yyyy HH:mm:ss.ms : ") + val + Environment.NewLine;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private void WriteLog(string AgentID, string value)
        {
            string FileName = DateTime.Now.ToString("HH");

            try
            {
                if (!string.IsNullOrEmpty(value.Trim()))
                {
                    if (Basic_CRM.Properties.Settings.Default["EnableLogging"].ToString() == "T")
                    {
                        FileName = FileName + ".log";
                        String FilePath = Application.StartupPath + "\\Logs"; //CommonCRM.Properties.Settings.Default["LoggingPath"].ToString();
                        if (System.IO.Directory.Exists(FilePath) == false)
                        {
                            System.IO.Directory.CreateDirectory(FilePath);
                        }
                        FilePath += "\\" + System.DateTime.Now.ToString("ddMMyyyy");
                        if (System.IO.Directory.Exists(FilePath) == false)
                        {
                            System.IO.Directory.CreateDirectory(FilePath);
                        }
                        if(AgentID.Trim() != "")
                        {
                            FilePath += "\\" + AgentID;
                            if (System.IO.Directory.Exists(FilePath) == false)
                            {
                                System.IO.Directory.CreateDirectory(FilePath);
                            }
                        }
                        FileName = FilePath + "\\" + FileName;
                        System.IO.StreamWriter writer = new System.IO.StreamWriter(FileName, true);
                        writer.Write(value);
                        writer.Flush();
                        writer.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                //Nothing to do.
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
