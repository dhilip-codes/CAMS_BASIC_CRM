using System;
using System.Threading;
using SamplePortalClient.EPAgentWS;
using SamplePortalClient.EPEventsWS;

namespace SamplePortalClient
{
    /// <summary>
    /// Summary description for CApp.
    /// </summary>

    public enum AgentType
    {
        atNarrowBand = 1,
        atInternet = 3
    };

    public enum DialType
    {
        dtInternal = 1,
        dtExternal = 2,
        dtService = 3,
        dtPreview = 3
    };

    internal enum ConsultType
    {
        ctInternal = 1,
        ctExternal = 2,
        ctXferChatToAgent = 3,
        ctXferAGDToAgent = 4
    };

    internal enum TransferType
    {
        ttWarm = 1,
        ttBlind = 2
    };

    public enum ChatEntityType
    {
        ceAgent = 1,
        ceMonitoringSupervisor = 2,
        ceCustomer = 3
    };

    public class CAgent : CServiceManual
    {
        public String LDAPUserId { get { return ldapUserId; } }
        internal String ldapUserId
        {
            get { return mpAgentArg.LDAPUserId; }
            set { mpAgentArg.LDAPUserId = value; }
        }

        public int ClientRole { get { return clientRole; } }
        internal int clientRole
        {
            get { return mpAgentArg.clientRole; }
            set { mpAgentArg.clientRole = value; }
        }

        public int ServerType { get { return serverType; } }
        internal int serverType
        {
            get { return mpAgentArg.serverType; }
            set
            {
                mpAgentArg.serverType = value;
                mpAgentInfoArg.serverType = value;
            }
        }

        public String LoginName { get { return loginName; } }
        internal String loginName
        {
            get { return mpAgentArg.agentLoginName; }
            set
            {
                mpAgentArg.agentLoginName = value;
                mpAgentInfoArg.agentLoginName = value;
            }
        }

        public String Password { get { return password; } }
        internal String password
        {
            get { return mpAgentInfoArg.password; }
            set { mpAgentInfoArg.password = value; }
        }

        public String Station { get { return station; } }
        internal String station
        {
            get { return mpAgentInfoArg.stationId; }
            set { mpAgentInfoArg.stationId = value; }
        }

        public int AgentType { get { return agentType; } }
        internal int agentType
        {
            get { return mpAgentInfoArg.agentType; }
            set { mpAgentInfoArg.agentType = value; }
        }

        public int WorkgroupId { get { return workgroupId; } }
        internal int workgroupId
        {
            get { return mpAgentInfoArg.agentWorkgroupID; }
            set { mpAgentInfoArg.agentWorkgroupID = value; }
        }

        public int ReferenceId { get { return referenceId; } }
        internal int referenceId
        {
            get { return mpAgentInfoArg.referenceID; }
            set { mpAgentInfoArg.referenceID = value; }
        }

        public int AgentIndex { get { return agentIndex; } }
        internal int agentIndex
        {
            get { return mpAgentInfoArg.agentIndex; }
            set { mpAgentInfoArg.agentIndex = value; }
        }

        public int GatewayId { get { return gatewayId; } }
        internal int gatewayId
        {
            get { return mpAgentInfoArg.ntSwitchID; }
            set { mpAgentInfoArg.ntSwitchID = value; }
        }

        public int Site { get { return site; } }
        internal int site = 0;

        public String AWSVersion { get { return awsVersion; } }
        internal String awsVersion = null;

        public String Tenant { get { return tenant; } }
        internal String tenant = null;

        public bool AllowPark { get { return allowPark; } }
        internal bool allowPark;

        public int ParkAlarmSecs { get { return parkAlarmSecs; } }
        internal int parkAlarmSecs;

        public int RouteAccessId { get { return routeAccessId; } }
        internal int routeAccessId;

        public String FirstName { get { return firstName; } }
        internal String firstName;

        public String LastName { get { return lastName; } }
        internal String lastName;

        public String AgentId { get { return mpAgentArg.agentLoginName; } }

        internal UDAgent AgentArg { get { return mpAgentArg; } }
        internal UDAgentInfo AgentInfoArg { get { return mpAgentInfoArg; } }

        internal UDCallback callbackArg { get { return mpCallbackArg; } }
        public UDCallback mpCallbackArg;

        private UDAgentInfo mpAgentInfoArg;
        private UDAgent mpAgentArg;

        internal CAgent()
            : base()
        {
            mpAgentArg = new UDAgent();
            mpAgentInfoArg = new UDAgentInfo();
            mpCallbackArg = new UDCallback();
        }
    }



    public class CApp
    {

        public event StateChangeHandler StateChange;
        public event UnfocusedStateChangeHandler UnfocusedStateChange;

        public event CallStateChangeHandler CallStateChange;
        public event UnfocusedCallStateChangeHandler UnfocusedCallStateChange;

        public event PasscodeHandler Passcode;
        public event LogoutPendingHandler LogoutPending;
        public event ScreenpopHandler Screenpop;

        public event CallActivatedHandler CallActivated;
        public event PhoneStatusHandler PhoneStatus;
        public event ErrorHandler Error;
        public event LoggedInHandler LoggedIn;

        public event ChatEntityHandler ChatEntityAdded;
        public event ChatEntityHandler ChatEntityRemoved;
        public event ChatURLHandler ChatURL;
        public event ChatMessageHandler ChatMessage;

        public CState CurrentState { get { return mpEventManager.CurrentState; } }
        public CAgent CurrentAgent { get { return mpCurrentAgent; } }
        public CCall CurrentCall { get { return mpCallManager.CurrentCall; } }
        public CLogoutReasons LogoutReasons { get { return mpLogoutReasons; } }
        public CNotReadyReasons NotReadyReasons { get { return mpNotReadyReasons; } }
        public CCallRejectionReasons CallRejectionReasons { get { return mpCallRejectionReasons; } }
        public CExternalRoutes ExternalRoutes { get { return mpExternalRoutes; } }
        public CAssignedServices AssignedServices { get { return mpAssignedServices; } }
        public CService CurrentService { get { return (this.CurrentCall == null ? mpCurrentAgent : mpAssignedServices.GetByKey(CurrentCall.serviceID)); } }

        internal CDispositionPlans DispositionPlans { get { return mpDispositionPlans; } }
        internal CPortal Portal { get { return mpPortal; } }
        internal CEventManager EventManager { get { return mpEventManager; } }
        internal CCallManager CallManager { get { return mpCallManager; } }
        internal C3WayCallManager ThreeWayCallManager { get { return mpThreeWayCallManager; } }

        private CEventManager mpEventManager;
        private CPortal mpPortal;
        private CAgent mpCurrentAgent;
        private CCallManager mpCallManager;
        private Timer mpKeepAliveTimer;
        private CLogoutReasons mpLogoutReasons;
        private CNotReadyReasons mpNotReadyReasons;
        private CCallRejectionReasons mpCallRejectionReasons;
        private CAssignedServices mpAssignedServices;
        private CDispositionPlans mpDispositionPlans;
        private CExternalRoutes mpExternalRoutes;
        private C3WayCallManager mpThreeWayCallManager;

        public CApp()
        {
            mpPortal = new CPortal();
            mpEventManager = new CEventManager(this);
            mpCallManager = new CCallManager();
            mpAssignedServices = new CAssignedServices(this);
            mpLogoutReasons = new CLogoutReasons(this);
            mpNotReadyReasons = new CNotReadyReasons(this);
            mpCallRejectionReasons = new CCallRejectionReasons(this);
            mpDispositionPlans = new CDispositionPlans(this);
            mpExternalRoutes = new CExternalRoutes(this);
            mpThreeWayCallManager = new C3WayCallManager();
        }

        private String GetServiceUrl(String sDefaultUrl, String sPortal)
        {
            if (sDefaultUrl == null || sDefaultUrl == "")
                return sDefaultUrl;

            int iStart = sDefaultUrl.IndexOf("//", 0);
            int iEnd = -1;
            if (iStart > -1)
                iEnd = sDefaultUrl.IndexOf("/", iStart + 2);

            if (iStart > -1 && iEnd > -1)
                return sDefaultUrl.Substring(0, iStart + 2) + sPortal + sDefaultUrl.Substring(iEnd);
            else
                return sDefaultUrl;

        }

        public void PlayDigits(String sUser, String pDigits, int callID)
        {
            CAgent pAgent = new CAgent();
            pAgent.ldapUserId = sUser;

            UDAgent ud = pAgent.AgentArg;
            UDDigits dg = new UDDigits();
            dg.callId = callID;
            dg.digits = pDigits;
            mpPortal.WSAgent.playDigits(ud, dg);
        }

        public void Login(String sUser, String sPwd, String sStation, String sPortal)
        {
            String sAgentUrl = GetServiceUrl(mpPortal.WSAgent.Url, sPortal);
            String sEventsUrl = GetServiceUrl(mpPortal.WSEvents.Url, sPortal);

            //Dynamically point each proxy to the portal specified by the user
            mpPortal.WSAgent.Url = sAgentUrl;
            mpPortal.WSEvents.Url = sEventsUrl;

            //Check agent's existence
            CAgent pAgent = new CAgent();
            pAgent.ldapUserId = sUser;

            UDInfo pInfo = new UDInfo();
            pInfo.listType = (int)AgentInfoType.GET_LOGIN_USER;

            User pUser = (User)mpPortal.WSAgent.getInfo(pAgent.AgentArg, pInfo);

            if (pUser == null)
                throw (new Exception("UserId '" + sUser + "' not found"));

            //Authenticate agent
            pAgent.clientRole = pUser.usertypemask;
            pAgent.serverType = 1;
            pAgent.loginName = pUser.userid;

            UDAgentInfo pAgentInfo = new UDAgentInfo();
            pAgent.password = sPwd;

            try
            {
                mpPortal.WSAgent.authenticate(pAgent.AgentArg, pAgent.AgentInfoArg);
            }
            catch (Exception pError)
            {
                throw (new Exception("Invalid password", pError));
            }

            //Set agent's additional properties
            pAgent.station = sStation;
            pAgent.agentType = (int)AgentType.atNarrowBand;
            pAgent.workgroupId = pUser.workgroupid;
            pAgent.routeAccessId = pUser.routeaccessid;
            pAgent.allowPark = Convert.ToBoolean(pUser.park);
            pAgent.parkAlarmSecs = pUser.parkdelay;
            pAgent.firstName = pUser.userfname;
            pAgent.lastName = pUser.userlname;

            //Set agent's general service properties (Agent's service properties are used for validation when there's no current service (eg, in Idle))
            pAgent.serviceId = 0;
            pAgent.serviceType = ServiceType.MANUAL;
            pAgent.serviceName = "Default";
            pAgent.dispositionPlan = null;
            pAgent.dialMask = pUser.outgoingmask;

            mpCurrentAgent = pAgent;

            //Load agent's service settings and add agent to list of assigned services.
            mpAssignedServices.Load(mpCurrentAgent);

            //Load logout reasons
            mpLogoutReasons.Load();

            //Load not ready reasons
            mpNotReadyReasons.Load();

            //Load call rejections reasons
            mpCallRejectionReasons.Load();

            //Load external routes
            mpExternalRoutes.Load();

            mpEventManager.RaiseEvent(AgentEventType.aeAUTHENTICATED, null, false);
        }

        public void Logout(CLogoutReason pLogoutReason)
        {
            if (mpCurrentAgent.AgentIndex > 0)
            {
                if (pLogoutReason == null)
                    throw new ArgumentNullException("pLogoutReason", "You must specify a Logout Reason");

                UDReason oReason = new UDReason();
                oReason.reasonId = pLogoutReason.Id;
                mpPortal.WSAgent.requestLogout(mpCurrentAgent.AgentArg, oReason);
            }


            if (mpCurrentAgent.AgentIndex == 0 || pLogoutReason.Id == CLogoutReason.PANIC_LOGOUT_ID)
            {
                mpEventManager.RaiseEvent(AgentEventType.aeLOGOUT, null);
            }
        }

        public void Hangup(CCall pCall)
        {
            if (pCall == null)
                throw new InvalidOperationException("Invalid request - Hangup. There's no current call to hang up.");

            if (!pCall.FirstPartyCall.CurrentState.EnableHangup)
                throw new InvalidOperationException("Invalid request - Hangup. Request not allowed in current state of current call.");

            UDParm pParam = new UDParm();
            pParam.callId = pCall.CallID;
            mpPortal.WSAgent.hangup(mpCurrentAgent.AgentArg, pParam);
        }

        public void setstartrecording()
        {


            AgentWebServiceService AgentWS = null;
            try
            {
                CCall pcall = mpCallManager.CurrentCall;
                UDAgent ua = new UDAgent();
                ua = mpCurrentAgent.AgentArg;
                string nn = "Blank";
                UDRecorderData param = new UDRecorderData();
                param.requestType = 100;
                param.callID = -1;
                param.recorderStation = mpCurrentAgent.station.ToString();
                param.agentStation = mpCurrentAgent.station.ToString();
                param.recorderId = mpCurrentAgent.AgentId.ToString();
                param.agentId = mpCurrentAgent.AgentId.ToString();
                param.status = "Record";
                param.audio_f = 1;
                param.custName = nn;
                param.phone1 = pcall.phoneNumber;
                param.serviceId = pcall.serviceID;
                mpPortal.WSAgent.record(ua, param);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        public void setstoprecording()
        {
            try
            {
                EPAgentWS.UDRecordState state = new EPAgentWS.UDRecordState();
                CCall pcall = mpCallManager.CurrentCall;
                pcall.callbackRequested = true;
                UDAgent ua = new UDAgent();
                ua = mpCurrentAgent.AgentArg;
                UDRecorderData param = new UDRecorderData();
                param.requestType = 200;
                param.callID = pcall.callID;
                param.audio_f = 6;
                param.seqNumber = state.recordingSeq;
                mpPortal.WSAgent.record(ua, param);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        public void Redial(string PhoneNo, int ServiceID, int ExternalRouteID, int CallID)
        {
            try
            {
                if (PhoneNo == null || PhoneNo.Trim().Length == 0)
                    throw new ArgumentException("You must specify Phone Number", "phone no");

                if (this.CurrentCall != null && this.CurrentCall.callID > 0)
                {
                    CCall pCall = new CCallVoice();
                    pCall.phoneNumber = PhoneNo;
                    pCall.callID = CallID;
                    pCall.serviceID = ServiceID;

                    mpCallManager.PendingManualCall = pCall;
                    UDCall pCallParms = new UDCall();
                    pCallParms.makeCallType = (int)DialType.dtExternal;
                    pCallParms.serviceID = ServiceID;
                    pCallParms.phoneNumber = PhoneNo;
                    //pCallParms.wrapRequiredFlag = 0;
                    mpCallManager.PendingManualCall = pCall;
                    mpPortal.WSAgent.dial(mpCurrentAgent.AgentArg, pCallParms);

                    //UDConsultIn consultParam = new UDConsultIn();
                    //consultParam.callID = 1;
                    //consultParam.consultType = (int)DialType.dtExternal;
                    //consultParam.phoneNumber = PhoneNo;
                    //consultParam.blindXferFlag = 0;
                    //consultParam.serviceID = ServiceID;
                    //mpPortal.WSAgent.consult(mpCurrentAgent.AgentArg, consultParam);

                    //UDChatDialRequest req = new UDChatDialRequest();
                    //req.callId = CallID;
                    //req.phoneNumber = PhoneNo;
                    //mpPortal.WSAgent.chatsvrDialRequest(mpCurrentAgent.AgentArg, req);
                }
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        public void HangupConsultation()
        {
            if (this.CurrentCall == null)
                throw new InvalidOperationException("Invalid request - HangupConsultation. There is no current call.");

            if (!(this.CurrentCall is CCallVoice))
                throw new InvalidOperationException("Invalid request - HangupConsultation. The current call does not support consultations.");

            CCallVoice pCall = (CCallVoice)this.CurrentCall;

            if (pCall.thirdPartyCall.CallID == 0)
                throw new InvalidOperationException("Invalid request - HangupConsultation. There is no current consultation call.");

            if (!pCall.thirdPartyCall.CurrentState.EnableHangup)
                throw new InvalidOperationException("Invalid request - HangupConsultation. Request not allowed in current state of consultation call.");

            UDParm pParam = new UDParm();
            pParam.callId = pCall.thirdPartyCall.CallID;
            mpPortal.WSAgent.hangup(mpCurrentAgent.AgentArg, pParam);
        }

        public void setcallback()
        {
            try
            {
                CCall pcall = mpCallManager.CurrentCall;
                pcall.callbackRequested = true;
                UDAgent ua = new UDAgent();
                ua = mpCurrentAgent.AgentArg;
                UDCallback pcallback = new UDCallback();
                pcallback.callID = pcall.callID;
                //pcallback.aodServiceID = pcall.serviceID;
                pcallback.aodServiceID = mpCurrentAgent.callbackArg.aodServiceID;
                pcallback.callbackName = mpCurrentAgent.callbackArg.callbackName; // "CallBack";
                pcallback.dateTime = mpCurrentAgent.callbackArg.dateTime;
                pcallback.dialMode = mpCurrentAgent.callbackArg.dialMode;
                pcallback.returnToSameAgent = mpCurrentAgent.callbackArg.returnToSameAgent;
                pcallback.phoneNumber = mpCurrentAgent.callbackArg.phoneNumber;
                pcallback.snoozeTimeInMins = mpCurrentAgent.callbackArg.snoozeTimeInMins;
                pcallback.memo = mpCurrentAgent.callbackArg.memo;

                mpPortal.WSAgent.scheduleCallback(ua, pcallback);
            }
            catch (Exception ex)
            {
            }
        }

        public void setExclusion(String PhoneNo)
        {
            try
            {
                CCall pcall = mpCallManager.CurrentCall;
                pcall.callbackRequested = true;
                UDAgent ua = new UDAgent();
                ua = mpCurrentAgent.AgentArg;
                UDExclude pExclude = new UDExclude();
                pExclude.agentIndex = ua.agentIndex;
                pExclude.startDate = DateTime.Now.ToString("M/d/yyyy HH:mm:ss");
                pExclude.endDate = DateTime.Now.AddDays(30).ToString("M/d/yyyy HH:mm:ss");
                pExclude.IAppId = 0;
                pExclude.IType = 0;
                pExclude.value = PhoneNo;

                mpPortal.WSAgent.excludeContact(ua, pExclude);
            }
            catch (Exception ex)
            {
            }
        }

        public void DisposeCall(CCall pCall, CDisposition pDisposition)
        {
            if (pCall == null)
                throw new InvalidOperationException("Invalid request - DisposeCall. You must specify the call to dispose.");

            CService pCurrentService = mpAssignedServices.GetByKey(pCall.serviceID);

            //If disposition required then validate argument
            if (pCurrentService.RequireDisposition && pCurrentService.DispositionPlan != null && pCurrentService.DispositionPlan.Dispositions.Count > 0)
            {
                //Check that a disposition was specified
                if (pDisposition == null)
                    throw new ArgumentNullException("pDisposition", "You must specify a disposition to dispose the current call.");

                //Check that specified disposition is in list
                if (!pCurrentService.DispositionPlan.Dispositions.Contains(pDisposition.Id))
                    throw new ArgumentException("Invalid Disposition. You must specify a disposition from the disposition plan of the current call's service.");

                //If disposition is callback check that callback was requested
                if (pDisposition.IsCallback & !pCall.CallbackRequested)
                    throw new ArgumentException("Invalid Disposition. You must request a callback before disposing the current call with a callback disposition.");

                //If disposition is exclusion check that exclusion was requested
                if (pDisposition.IsExclusion && !pCall.ExclusionRequested)
                    throw new ArgumentException("Invalid Disposition. You must request an exclusion before disposing the current call with an exclusion disposition.");
            }
            //If disposition not required, use the default one
            else
            {
                pDisposition = new CDisposition(64, "[Default]", "", false, false, false);
            }

            //Copy call's user defined fields
            UDCallInfoUserDefinedItemIn[] items = new UDCallInfoUserDefinedItemIn[20];
            for (int i = 0; i < items.Length; i++)
            {
                items[i] = new UDCallInfoUserDefinedItemIn();
                items[i].key = pCall.userDefinedItems[i].key;
                items[i].value = pCall.userDefinedItems[i].value;
            }

            //Dispose the call with its user defined fields and the
            //specified disposition
            UDDisposition pDisp = new UDDisposition();
            pDisp.callId = pCall.CallID;
            pDisp.IDisposition = pDisposition.Id;
            pDisp.saleFlag = pDisposition.IsSale;
            pDisp.callBackFlag = pCall.CallbackRequested;
            pDisp.updatedCallInfoUserDefined = new UDCallInfoUserDefinedIn();
            pDisp.updatedCallInfoUserDefined.userDefinedItems = items;

            mpPortal.WSAgent.callOutcome(mpCurrentAgent.AgentArg, pDisp);

            //If call was successfully disposed then remove it from list
            mpCallManager.RemoveByKey(pCall.CallID);
        }

        public void ActivateCall(CCall pCall)
        {
            mpEventManager.ActivateCall(pCall);
        }

        public void TakeCalls()
        {
            mpPortal.Register(mpCurrentAgent.AgentArg, mpCurrentAgent.AgentInfoArg);
        }

        public void Dial(String UserId)
        {
            if (UserId == null || UserId.Trim().Length == 0)
                throw new ArgumentException("You must specify a UserId", "UserId");

            //Create manual call and save it waiting for dialing event
            CCall pCall = new CCallVoice();
            mpCallManager.PendingManualCall = pCall;

            UDCall pCallParams = new UDCall();
            pCallParams.makeCallType = (int)DialType.dtInternal;
            pCallParams.userID = UserId;

            mpPortal.WSAgent.dial(mpCurrentAgent.AgentArg, pCallParams);
        }

        public void Dial(String PhoneNumber, int ServiceId, int ExternalRouteId)
        {
            if (PhoneNumber == null || PhoneNumber.Trim().Length == 0)
                throw new ArgumentException("You must specify a PhoneNumber", "PhoneNumber");

            CCall pCall;
            UDCall pCallParams = new UDCall();

            //If dialing a preview, retrieve preview call and update its phone number
            if (this.CurrentCall != null && this.CurrentCall.CurrentState is CStatePreview)
            {
                pCall = this.CurrentCall;
                //Overwrite preview's phone number with number specified by user
                //and use service of preview call
                pCall.phoneNumber = PhoneNumber;
                pCallParams.makeCallType = (int)DialType.dtPreview;
                pCallParams.callID = this.CurrentCall.callID;
            }
            else if (this.CurrentCall != null)
            {
                //Wrap Mode Dialing
                pCall = this.CurrentCall;
                pCall.serviceID = ServiceId;
                pCall.phoneNumber = PhoneNumber;
                mpCallManager.PendingManualCall = pCall;
                pCallParams.makeCallType = (int)DialType.dtExternal;
                mpCallManager.PendingManualCall = pCall;
                pCallParams.callID = pCall.callID;
            }
            //Otherwise, create manual call and save it waiting for dialing event
            else
            {
                //Create manual call with number and service specified by user
                pCall = new CCallVoice();
                pCall.serviceID = ServiceId;
                pCall.phoneNumber = PhoneNumber;
                mpCallManager.PendingManualCall = pCall;
                pCallParams.makeCallType = (int)DialType.dtExternal;
            }

            pCallParams.externalRouteID = ExternalRouteId;
            pCallParams.serviceID = pCall.ServiceID;
            pCallParams.phoneNumber = pCall.PhoneNumber;
            pCallParams.userID = mpCurrentAgent.AgentId;

            mpPortal.WSAgent.dial(mpCurrentAgent.AgentArg, pCallParams);
        }

       


        public void Hold()
        {
            if (this.CurrentCall == null)
                throw new InvalidOperationException("Invalid request - Hold. There's no current call to hold.");

            if (!(this.CurrentCall.FirstPartyCall.CurrentState is CStateActive))
                throw new InvalidOperationException("Invalid request - Hold. Request not allowed in current state of current call.");

            UDParm oParam = new UDParm();
            oParam.callId = this.CurrentCall.CallID;
            mpPortal.WSAgent.hold(mpCurrentAgent.AgentArg, oParam);
        }

        public void HoldConsultation()
        {
            if (this.CurrentCall == null)
                throw new InvalidOperationException("Invalid request - HoldConsultation. There is no current call.");

            if (!(this.CurrentCall is CCallVoice))
                throw new InvalidOperationException("Invalid request - HoldConsultation. The current call does not support consultations.");

            CCallVoice pCall = (CCallVoice)this.CurrentCall;

            if (pCall.thirdPartyCall.CallID == 0)
                throw new InvalidOperationException("Invalid request - HoldConsultation. There is no current consultation call.");

            if (!(pCall.thirdPartyCall.CurrentState is CStateActive))
                throw new InvalidOperationException("Invalid request - HoldConsultation. Request not allowed in current state of consultation call.");

            UDParm pParam = new UDParm();
            pParam.callId = pCall.thirdPartyCall.CallID;
            mpPortal.WSAgent.hold(mpCurrentAgent.AgentArg, pParam);
        }

        public void ReleaseHold()
        {
            if (this.CurrentCall == null)
                throw new InvalidOperationException("Invalid request - ReleaseHold. There's no current call on which to release a hold.");

            if (!(this.CurrentCall.FirstPartyCall.CurrentState is CStateHeld))
                throw new InvalidOperationException("Invalid request - ReleaseHold. Request not allowed in current state of current call.");

            UDParm oParam = new UDParm();
            oParam.callId = this.CurrentCall.CallID;
            mpPortal.WSAgent.retrieveHold(mpCurrentAgent.AgentArg, oParam);
        }

        public void ReleaseHoldOnConsultation()
        {
            if (this.CurrentCall == null)
                throw new InvalidOperationException("Invalid request - ReleaseHoldOnConsultation. There is no current call.");

            if (!(this.CurrentCall is CCallVoice))
                throw new InvalidOperationException("Invalid request - ReleaseHoldOnConsultation. The current call does not support consultations.");

            CCallVoice pCall = (CCallVoice)this.CurrentCall;

            if (pCall.thirdPartyCall.CallID == 0)
                throw new InvalidOperationException("Invalid request - ReleaseHoldOnConsultation. There is no current consultation call.");

            if (!(pCall.thirdPartyCall.CurrentState is CStateHeld))
                throw new InvalidOperationException("Invalid request - ReleaseHoldOnConsultation. Request not allowed in current state of consultation call.");

            UDParm pParam = new UDParm();
            pParam.callId = pCall.thirdPartyCall.CallID;
            mpPortal.WSAgent.retrieveHold(mpCurrentAgent.AgentArg, pParam);
        }


        public void Redial(string PhoneNo, int ServiceID, int ExternalRouteID)
        {
            try
            {
                if (PhoneNo == null || PhoneNo.Trim().Length == 0)
                    throw new ArgumentException("You must specify Phone Number", "phone no");
                CCall pCall;
                UDCall pCallParms = new UDCall();
                if (this.CurrentCall != null && this.CurrentCall.callID > 0)
                {
                    pCall = this.CurrentCall;
                    pCall.phoneNumber = PhoneNo;
                    pCall.serviceID = ServiceID;
                    mpCallManager.PendingManualCall = pCall;

                    pCallParms.makeCallType = (int)DialType.dtExternal;
                    pCallParms.externalRouteID = ExternalRouteID;
                    pCallParms.serviceID = pCall.serviceID;
                    pCallParms.phoneNumber = pCall.phoneNumber;
                    pCallParms.callID = pCall.callID;
                    mpPortal.WSAgent.dial(mpCurrentAgent.AgentArg, pCallParms);
                }
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }
        public void BecomeUnavailable(CNotReadyReason pNotReadyReason, bool Park)
        {
            if (pNotReadyReason == null)
                throw new ArgumentNullException("pNotReadyReason", "You must specify a NotReady Reason");

            UDReason oReason = new UDReason();
            oReason.reasonId = pNotReadyReason.Id;
            oReason.toParkState = Park;
            mpPortal.WSAgent.requestUnavailable(mpCurrentAgent.AgentArg, oReason);
        }

        public void BecomeAvailable()
        {
            mpPortal.WSAgent.available(mpCurrentAgent.AgentArg);
        }

        private void Consult(UDConsultIn consultParams)
        {
            CCall pCall = this.CurrentCall;

            //Copy call's user defined fields
            UDCallInfoUserDefinedItemIn[] items = new UDCallInfoUserDefinedItemIn[20];
            for (int i = 0; i < items.Length; i++)
            {
                items[i] = new UDCallInfoUserDefinedItemIn();
                items[i].key = pCall.userDefinedItems[i].key;
                items[i].value = pCall.userDefinedItems[i].value;
            }

            consultParams.callID = pCall.CallID;
            consultParams.userDefinedData = new UDCallInfoUserDefinedIn();
            consultParams.userDefinedData.userDefinedItems = items;

            mpPortal.WSAgent.consult(mpCurrentAgent.AgentArg, consultParams);
        }

        /// <summary>
        /// Consult the specified user
        /// </summary>
        public void Consult(CUser user)
        {
            if (user == null)
                throw new ArgumentException("You must specify a user.", "user");

            if (this.CurrentCall == null)
                throw new InvalidOperationException("Invalid request - Consult. There is no current call.");

            if (this.CurrentCall.CallID == 0)
                throw new InvalidOperationException("Invalid request - Consult. There is no current call.");

            if (!(this.CurrentCall is CCallVoice))
                throw new InvalidOperationException("Invalid request - Consult. The current call does not support consultations.");

            if (!(this.CurrentCall.CurrentState.EnableConsult))
                throw new InvalidOperationException("Invalid request - Consult. Request not allowed in current state of current call.");

            //Save the information about the consultation to the current 3rdParty call in case we need to refer to it later.
            CCallVoice pCall = (CCallVoice)this.CurrentCall;
            ((C3WayCall3rdParty)pCall.ThirdPartyCall).consultationEntity = user;
            ((C3WayCall3rdParty)pCall.ThirdPartyCall).consultationPhoneNumber = "";
            //Point the PendingConsultation reference to the current 3rdParty call
            mpThreeWayCallManager.PendingConsultationCall = (C3WayCall3rdParty)pCall.ThirdPartyCall;

            //Send the request
            UDConsultIn oParams = new UDConsultIn();
            oParams.consultType = (int)ConsultType.ctInternal;
            oParams.blindXferFlag = Convert.ToInt32(false);
            oParams.userID = user.Id;

            Consult(oParams);
        }

        /// <summary>
        /// Consult the specified service
        /// </summary>
        public void Consult(CSimpleService service)
        {
            if (service == null)
                throw new ArgumentException("You must specify a service.", "service");

            if (this.CurrentCall == null)
                throw new InvalidOperationException("Invalid request - Consult. There is no current call.");

            if (this.CurrentCall.CallID == 0)
                throw new InvalidOperationException("Invalid request - Consult. There is no current call.");

            if (!(this.CurrentCall is CCallVoice))
                throw new InvalidOperationException("Invalid request - Consult. The current call does not support consultations.");

            if (!(this.CurrentCall.CurrentState.EnableConsult))
                throw new InvalidOperationException("Invalid request - Consult. Request not allowed in current state of current call.");

            //Save the information about the consultation to the current 3rdParty call in case we need to refer to it later.
            CCallVoice pCall = (CCallVoice)this.CurrentCall;
            ((C3WayCall3rdParty)pCall.ThirdPartyCall).consultationEntity = service;
            ((C3WayCall3rdParty)pCall.ThirdPartyCall).consultationPhoneNumber = "";
            //Point the PendingConsultation reference to the current 3rdParty call
            mpThreeWayCallManager.PendingConsultationCall = (C3WayCall3rdParty)pCall.ThirdPartyCall;

            //Send the request
            UDConsultIn oParams = new UDConsultIn();
            oParams.consultType = (int)ConsultType.ctInternal;
            oParams.blindXferFlag = Convert.ToInt32(false);
            oParams.serviceID = service.ServiceId;

            Consult(oParams);
        }

        /// <summary>
        /// Consult the specified phone number
        /// </summary>
        public void Consult(String phoneNumber, CExternalRoute externalRoute)
        {
            if (phoneNumber == null)
                throw new ArgumentException("You must specify a phone number.", "phoneNumber");

            if (phoneNumber.Trim() == "")
                throw new ArgumentException("You must specify a phone number.", "phoneNumber");

            if (this.CurrentCall == null)
                throw new InvalidOperationException("Invalid request - Consult. There is no current call.");

            if (this.CurrentCall.CallID == 0)
                throw new InvalidOperationException("Invalid request - Consult. There is no current call.");

            if (!(this.CurrentCall is CCallVoice))
                throw new InvalidOperationException("Invalid request - Consult. The current call does not support consultations.");

            if (!(this.CurrentCall.CurrentState.EnableConsult))
                throw new InvalidOperationException("Invalid request - Consult. Request not allowed in current state of current call.");


            //Save the information about the consultation to the current 3rdParty call in case we need to refer to it later.
            CCallVoice pCall = (CCallVoice)this.CurrentCall;
            ((C3WayCall3rdParty)pCall.ThirdPartyCall).consultationEntity = externalRoute;
            ((C3WayCall3rdParty)pCall.ThirdPartyCall).consultationPhoneNumber = phoneNumber;
            //Point the PendingConsultation reference to the current 3rdParty call
            mpThreeWayCallManager.PendingConsultationCall = (C3WayCall3rdParty)pCall.ThirdPartyCall;


            UDConsultIn oParams = new UDConsultIn();
            oParams.consultType = (int)ConsultType.ctExternal;
            oParams.blindXferFlag = Convert.ToInt32(false);
            oParams.phoneNumber = phoneNumber;
            if (externalRoute != null)
                oParams.externalRouteID = externalRoute.Id;

            Consult(oParams);
        }

        /// <summary>
        /// Consult the specified phone number
        /// </summary>
        public void Consult(String phoneNumber)
        {
            Consult(phoneNumber, null);
        }

        /// <summary>
        /// Transfer the current call to the specified user
        /// </summary>
        public void Transfer(CUser user)
        {
            if (user == null)
                throw new ArgumentException("You must specify a user.", "user");

            if (this.CurrentCall == null)
                throw new InvalidOperationException("Invalid request - Transfer. There is no current call.");

            if (this.CurrentCall.CallID == 0)
                throw new InvalidOperationException("Invalid request - Transfer. There is no current call.");

            if (!this.CurrentCall.CurrentState.EnableTransfer)
                throw new InvalidOperationException("Invalid request - Transfer. Request not allowed in current state of current call.");

            //[Blind] Transfer to User is actually requested via the consult method with blindXferFlag=true.
            //
            //Save the information about the consultation to the current 3rdParty call in case we need to refer to it later.
            // If condition Added By Azim M 03 MAR 2017
            if (this.CurrentCall.MediaType != AgentMediaType.amINBOUND_CHAT)
            {
                CCallVoice pCall = (CCallVoice)this.CurrentCall;
                ((C3WayCall3rdParty)pCall.ThirdPartyCall).consultationEntity = user;
                ((C3WayCall3rdParty)pCall.ThirdPartyCall).consultationPhoneNumber = "";
                //Point the PendingConsultation reference to the current 3rdParty call
                mpThreeWayCallManager.PendingConsultationCall = (C3WayCall3rdParty)pCall.ThirdPartyCall;
            }
            //End
            UDConsultIn oParams = new UDConsultIn();

            //Set consultType corresponding to calltype of current call 
            switch (this.CurrentCall.MediaType)
            {
                case AgentMediaType.amINBOUND_AGD:
                    oParams.consultType = (int)ConsultType.ctXferAGDToAgent;
                    break;

                case AgentMediaType.amINBOUND_CHAT:
                    oParams.consultType = (int)ConsultType.ctXferChatToAgent;
                    break;

                default:
                    oParams.consultType = (int)ConsultType.ctInternal;
                    break;
            }

            oParams.blindXferFlag = Convert.ToInt32(true);
            oParams.userID = user.Id;

            Consult(oParams);
        }

        /// <summary>
        /// Transfer the current call to the specified phone number
        /// </summary>
        public void Transfer(String phoneNumber)
        {
            Transfer(phoneNumber, null);
        }

        /// <summary>
        /// Transfer the current call to the specified phone number
        /// </summary>
        public void Transfer(String phoneNumber, CExternalRoute externalRoute)
        {
            if (phoneNumber == null)
                throw new ArgumentException("You must specify a phone number.", "phoneNumber");

            if (phoneNumber.Trim() == "")
                throw new ArgumentException("You must specify a phone number.", "phoneNumber");

            if (this.CurrentCall == null)
                throw new InvalidOperationException("Invalid request - Transfer. There is no current call.");

            if (this.CurrentCall.CallID == 0)
                throw new InvalidOperationException("Invalid request - Transfer. There is no current call.");

            if (!this.CurrentCall.CurrentState.EnableTransfer)
                throw new InvalidOperationException("Invalid request - Transfer. Request not allowed in current state of current call.");


            //[Blind] Transfer to external is actually requested via the consult method with blindXferFlag=true
            //
            //Save the information about the consultation to the current 3rdParty call in case we need to refer to it later.
            CCallVoice pCall = (CCallVoice)this.CurrentCall;
            ((C3WayCall3rdParty)pCall.ThirdPartyCall).consultationEntity = externalRoute;
            ((C3WayCall3rdParty)pCall.ThirdPartyCall).consultationPhoneNumber = phoneNumber;
            //Point the PendingConsultation reference to the current 3rdParty call
            mpThreeWayCallManager.PendingConsultationCall = (C3WayCall3rdParty)pCall.ThirdPartyCall;


            UDConsultIn oParams = new UDConsultIn();
            oParams.consultType = (int)ConsultType.ctExternal;
            oParams.blindXferFlag = Convert.ToInt32(true);
            oParams.phoneNumber = phoneNumber;
            if (externalRoute != null)
                oParams.externalRouteID = externalRoute.Id;

            Consult(oParams);
        }

        private void Transfer(UDTransfer xferParams)
        {
            CCall pCall = this.CurrentCall;

            //Copy call's user defined fields
            UDCallInfoUserDefinedItemIn[] items = new UDCallInfoUserDefinedItemIn[20];
            for (int i = 0; i < items.Length; i++)
            {
                items[i] = new UDCallInfoUserDefinedItemIn();
                items[i].key = pCall.userDefinedItems[i].key;
                items[i].value = pCall.userDefinedItems[i].value;
            }

            xferParams.originalCallID = this.CurrentCall.CallID;
            xferParams.callInfoUserDefined = new UDCallInfoUserDefinedIn();
            xferParams.callInfoUserDefined.userDefinedItems = items;

            mpPortal.WSAgent.transfer(mpCurrentAgent.AgentArg, xferParams);
        }

        /// <summary>
        /// Transfer the current call to the specified service
        /// </summary>
        public void Transfer(CSimpleService service)
        {
            if (service == null)
                throw new ArgumentException("You must specify a service.", "service");

            if (this.CurrentCall == null)
                throw new InvalidOperationException("Invalid request - Transfer. There is no current call.");

            if (this.CurrentCall.CallID == 0)
                throw new InvalidOperationException("Invalid request - Transfer. There is no current call.");

            if (!this.CurrentCall.CurrentState.EnableTransfer)
                throw new InvalidOperationException("Invalid request - Transfer. Request not allowed in current state of current call.");

            UDTransfer oParams = new UDTransfer();
            oParams.serviceID = service.ServiceId;
            oParams.transferType = (int)TransferType.ttBlind;

            Transfer(oParams);
        }

        /// <summary>
        /// Transfer the current call to the consulted/conferenced party
        /// </summary>
        public void Transfer()
        {
            if (this.CurrentCall == null)
                throw new InvalidOperationException("Invalid request - Transfer. There is no current call.");

            if (this.CurrentCall.CallID == 0)
                throw new InvalidOperationException("Invalid request - Transfer. There is no current call.");

            if (!(this.CurrentCall is CCallVoice))
                //This error message makes more sense for this request than "...current call does not support consultations..."
                throw new InvalidOperationException("Invalid request - Transfer. There is no current consultation call.");

            CCallVoice pCall = (CCallVoice)this.CurrentCall;

            if (pCall.thirdPartyCall.CallID == 0)
                throw new InvalidOperationException("Invalid request - Transfer. There is no current consultation call.");

            if (!this.CurrentCall.CurrentState.EnableTransfer)
                throw new InvalidOperationException("Invalid request - Transfer. Request not allowed in current state of current call.");

            UDTransfer oParams = new UDTransfer();
            oParams.serviceID = pCall.ServiceID;
            oParams.thirdParyCallID = pCall.ThirdPartyCall.CallID;
            //If not in Conference, the Conference CallID will be 0 which is fine - the Transfer to the consulted party will still be made.
            oParams.conferenceCallID = pCall.ConferenceCall.CallID;

            oParams.transferType = (int)TransferType.ttWarm;

            Transfer(oParams);
        }

        /// <summary>
        /// Conference-in the consulted party
        /// </summary>
        public void Conference()
        {
            if (this.CurrentCall == null)
                throw new InvalidOperationException("Invalid request - Conference. There is no current call.");

            if (this.CurrentCall.CallID == 0)
                throw new InvalidOperationException("Invalid request - Conference. There is no current call.");

            if (!(this.CurrentCall is CCallVoice))
                //This error message makes more sense for this request than "...current call does not support consultations..."
                throw new InvalidOperationException("Invalid request - Conference. There is no current consultation call.");

            CCallVoice pCall = (CCallVoice)this.CurrentCall;

            if (pCall.thirdPartyCall.CallID == 0)
                throw new InvalidOperationException("Invalid request - Conference. There is no current consultation call.");

            if (!this.CurrentCall.CurrentState.EnableConference)
                throw new InvalidOperationException("Invalid request - Conference. Request not allowed in current state of current call.");

            UDConferenceIn oParams = new UDConferenceIn();
            oParams.callID = this.CurrentCall.CallID;
            oParams.consultCallID = ((CCallVoice)this.CurrentCall).ThirdPartyCall.CallID;

            mpPortal.WSAgent.conference(mpCurrentAgent.AgentArg, oParams);
        }

        /// <summary>
        /// Accept the current call
        /// </summary>
        public void AcceptCall()
        {
            //TODO: Validate request

            UDAnswerCall oAnswer = new UDAnswerCall();
            oAnswer.result = Convert.ToInt32(false);
            oAnswer.agentIndex = mpCurrentAgent.AgentIndex;
            oAnswer.callID = mpCallManager.CurrentCall.CallID;

            mpPortal.WSAgent.answerCall(mpCurrentAgent.AgentArg, oAnswer);
        }

        /// <summary>
        /// Reject the current call with the specified reason
        /// </summary>
        public void RejectCall(CCallRejectionReason pRejectionReason)
        {
            //TODO: Validate request

            UDAnswerCall oAnswer = new UDAnswerCall();
            oAnswer.result = Convert.ToInt32(true);
            oAnswer.agentIndex = mpCurrentAgent.AgentIndex;
            oAnswer.callID = mpCallManager.CurrentCall.CallID;
            if (pRejectionReason != null)
                oAnswer.rejectReason = pRejectionReason.Id;

            mpPortal.WSAgent.answerCall(mpCurrentAgent.AgentArg, oAnswer);
        }

        /// <summary>
        /// Reject the current call
        /// </summary>
        public void RejectCall()
        {
            RejectCall(null);
        }

        public CAgents GetAgents()
        {
            CAgents oAgents = new CAgents(this);
            oAgents.Load(this.CurrentService.serviceId);
            return oAgents;
        }

        public CSupervisors GetSupervisors()
        {
            CSupervisors oSups = new CSupervisors(this);
            oSups.Load(this.CurrentService.serviceId);
            return oSups;
        }

        public CServices GetServices()
        {
            CServices oSvcs = new CServices(this);
            switch (this.CurrentService.ServiceType)
            {
                case ServiceType.CTI:
                case ServiceType.AGD:
                case ServiceType.CHAT:
                    oSvcs.Load(this.CurrentService.ServiceType);
                    break;
                default:
                    oSvcs.Load();
                    break;
            }

            return oSvcs;
        }

        public void SendChatMessage(CCallChat pCall, String sMessage)
        {

            //TODO: Validate request
            if (pCall == null)
                throw new InvalidOperationException("Invalid request - SendChatMessage. You must specify a call.");

            UDChatMessage oMessageParams = new UDChatMessage();
            //TODO: If there's also a voice call, the callid of the chat call may not be that of the current call.
            oMessageParams.callId = pCall.CallID;
            oMessageParams.text = sMessage;

            mpPortal.WSAgent.chatSendMessage(mpCurrentAgent.AgentArg, oMessageParams);
        }

        public void SendChatURL(CCallChat pCall, String sURL)
        {
            //TODO: Validate request
            if (pCall == null)
                throw new InvalidOperationException("Invalid request - SendChatURL. You must specify a call.");

            //Must send URLs with http or customer's web app won't handle them properly
            //Only check for http in case user specified https
            if (!(sURL.StartsWith("http", StringComparison.OrdinalIgnoreCase)))
                sURL = "http://" + sURL;

            UDChatURL oURLParams = new UDChatURL();
            //TODO: If there's also a voice call, the callid of the chat call may not be that of the current call.
            oURLParams.callId = pCall.CallID;
            oURLParams.url = sURL;

            mpPortal.WSAgent.chatSendURL(mpCurrentAgent.AgentArg, oURLParams);
        }

        internal void ConnectToChatServer(CCallChat pCall)
        {
            try
            {
                UDChatConnect oConnectParams = new UDChatConnect();
                oConnectParams.callId = pCall.CallID;
                oConnectParams.serviceId = pCall.ServiceID;
                oConnectParams.chatserverIP = pCall.ChatServerIP;
                oConnectParams.chatserverCSLPort = pCall.ChatServerPort;
                oConnectParams.entityType = (int)ChatEntityType.ceAgent;
                oConnectParams.firstName = mpCurrentAgent.FirstName;
                oConnectParams.lastName = mpCurrentAgent.LastName;

                mpPortal.WSAgent.chatConnect(mpCurrentAgent.AgentArg, oConnectParams);
            }
            catch (Exception pError)
            {
                Console.WriteLine(pError.StackTrace);
            }
        }

        internal bool EnableKeepAlives
        {
            set
            {
                if (value && mpKeepAliveTimer == null)
                {
                    //Start sending KeepAlives
                    TimerCallback timerDelegate = new TimerCallback(SendKeepAlive);
                    mpKeepAliveTimer = new Timer(timerDelegate, this, 60000, 60000);
                }
                else if (!value && mpKeepAliveTimer != null)
                {
                    mpKeepAliveTimer.Dispose();
                    mpKeepAliveTimer = null;
                }
            }
        }

        private void SendKeepAlive(Object state)
        {
            try
            {
                mpPortal.WSAgent.keepAlive(CurrentAgent.AgentArg);
            }
            catch (Exception pError)
            {
                Console.WriteLine(pError.StackTrace);
            }
        }

        internal void OnStateChange(CStateChangeArgs pArgs)
        {
            if (StateChange != null)
                StateChange(this, pArgs);
        }

        internal void OnUnfocusedStateChange(CUnfocusedStateChangeArgs pArgs)
        {
            if (UnfocusedStateChange != null)
                UnfocusedStateChange(this, pArgs);
        }

        internal void OnCallStateChange(CCallStateChangeArgs pArgs)
        {
            if (CallStateChange != null)
                CallStateChange(this, pArgs);
        }

        internal void OnUnfocusedCallStateChange(CUnfocusedCallStateChangeArgs pArgs)
        {
            if (UnfocusedCallStateChange != null)
                UnfocusedCallStateChange(this, pArgs);
        }

        internal void OnPasscode(CPasscodeArgs pArgs)
        {
            if (Passcode != null)
                Passcode(this, pArgs);
        }

        internal void OnLogoutPending()
        {
            if (LogoutPending != null)
                LogoutPending(this);
        }

        internal void OnScreenpop(CScreenpopArgs pArgs)
        {
            if (Screenpop != null)
                Screenpop(this, pArgs);
        }

        internal void OnCallActivated(CCallActivatedArgs pArgs)
        {
            if (CallActivated != null)
                CallActivated(this, pArgs);
        }

        internal void OnPhoneStatus(CPhoneStatusArgs pArgs)
        {
            if (PhoneStatus != null)
                PhoneStatus(this, pArgs);
        }

        internal void OnError(CErrorArgs pArgs)
        {
            if (Error != null)
                Error(this, pArgs);
        }

        internal void OnLoggedIn()
        {
            if (LoggedIn != null)
                LoggedIn(this);
        }

        internal void OnChatEntityAdded(CChatEntityArgs pArgs)
        {
            if (ChatEntityAdded != null)
                ChatEntityAdded(this, pArgs);
        }

        internal void OnChatEntityRemoved(CChatEntityArgs pArgs)
        {
            if (ChatEntityRemoved != null)
                ChatEntityRemoved(this, pArgs);
        }

        internal void OnChatURL(CChatURLArgs pArgs)
        {
            if (ChatURL != null)
                ChatURL(this, pArgs);
        }

        internal void OnChatMessage(CChatMessageArgs pArgs)
        {
            if (ChatMessage != null)
                ChatMessage(this, pArgs);
        }

        internal bool ServiceExists(int ServiceId)
        {
            UDInfo oInfo = new UDInfo();
            oInfo.listType = (int)AgentInfoType.GET_CHECK_SERVICE_EXISTS;
            oInfo.serviceId = ServiceId;
            GetIdDesc oItem = (GetIdDesc)mpPortal.WSAgent.getInfo(mpCurrentAgent.AgentArg, oInfo);
            return Convert.ToBoolean(oItem.id);
        }
    }
}
