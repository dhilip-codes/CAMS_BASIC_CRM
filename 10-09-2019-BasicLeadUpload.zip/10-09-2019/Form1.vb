﻿Imports System.Data.OleDb
Imports System.IO
Imports System.Data.SqlClient
Imports System.Security.Cryptography.X509Certificates
Imports System.Net.Security
Imports System.Net
Imports System.Xml
Imports System.Text

Public Class frmNDNCDataScrubbing
    Private Sub frmNDNCDataScrubbing_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblCallableCnt.Text = 0
        txtDestination.Text = Application.StartupPath & "\Export"
        WriteLog(DateTime.Now.ToString("HH"), "Application Started" + Environment.NewLine)
    End Sub

    Private Sub btnSelectSource_Click(sender As Object, e As EventArgs) Handles btnSelectSource.Click
        Try
            With ofdSource
                .Filter = "CSV Files (*.csv)|*.csv|Excel Files (*.xlsx)|*.xlsx"
                .InitialDirectory = AppDomain.CurrentDomain.BaseDirectory
                Dim ret As DialogResult = .ShowDialog()
                If ret = Windows.Forms.DialogResult.OK Then
                    txtSource.Text = .FileName
                    Dim dt As DataTable

                    Dim tmp As String() = txtSource.Text.Split("\")
                    Dim fileExt As String = tmp(tmp.Length - 1).Split(".")(1)
                    If fileExt.ToUpper() = "XLSX" Then
                        dt = ExcelToDataTable(txtSource.Text)
                        dgvSourceData.DataSource = dt.Copy

                        dt.Clear()
                        dt = Nothing
                    ElseIf fileExt.ToUpper() = "CSV" Then
                        dt = CSVToDataTable(txtSource.Text)
                        dgvSourceData.DataSource = dt.Copy

                        dt.Clear()
                        dt = Nothing
                    Else
                        MessageBox.Show("Ïnvalid File Selected. Choose another file.", "Select Source", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End If
                End If
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, "btnSelectSource_Click : ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnCreateDialerUpload_Click(sender As Object, e As EventArgs) Handles btnCreateDialerUpload.Click
        btnCreateDialerUpload.Enabled = False

        Dim dtSource As DataTable = dgvSourceData.DataSource
        Dim dtCallable As New DataTable
        Dim uploadDt As String = DateTime.Now.ToString("yyyyMMdd")

        dtCallable.Columns.Add("SrNo")
        'Code added by AMD on 10th Feb 2018
        dtCallable.Columns.Add("UploadDate")
        'End
        For cols As Integer = 0 To dtSource.Columns.Count - 1
            dtCallable.Columns.Add(dtSource.Columns(cols).ColumnName)
        Next

        Try
            For i As Integer = 0 To dgvSourceData.Rows.Count - 1
                With dgvSourceData
                    Dim fieldNames As String = "", fieldValues As String = ""

                    For j = 0 To dgvSourceData.Columns.Count - 1
                        Dim colName As String = dgvSourceData.Columns.Item(j).Name
                        fieldNames += "[" + colName + "]"
                        fieldValues += "'" + .Item(colName, i).Value.ToString().Replace(vbLf, "").Replace(vbCr, "").Replace(vbCrLf, "") + "'"
                        If j < dgvSourceData.Columns.Count - 1 Then
                            fieldNames += ","
                            fieldValues += ","
                        End If
                    Next

                    'Inserting Data to CRM and fetching the Identity Value
                    Dim qry As String = "insert into CRM_Data("
                    qry += fieldNames + ", UploadDate"
                    qry += ") values("
                    qry += fieldValues + ", '" + uploadDt + "'"
                    qry += ")"

                    Dim tmp As getIdentityResp = GetIdentity(My.Settings.ConStr, qry)
                    'End

                    If tmp.Status = 1 Then 'Record Inserted to CRM DB
                        lblCallableCnt.Text += 1
                        lblCallableCnt.Refresh()
                        Me.Refresh()

                        With dtCallable
                            .Rows.Add()
                            .Rows(.Rows.Count - 1).Item("SrNo") = tmp.IdentityVal
                            'Code added by AMD on 10th Feb 2018
                            .Rows(.Rows.Count - 1).Item("UploadDate") = uploadDt
                            'End
                            For j = 0 To dgvSourceData.Columns.Count - 1
                                Dim colName As String = dgvSourceData.Columns.Item(j).Name
                                .Rows(.Rows.Count - 1).Item(colName) = dgvSourceData.Item(colName, i).Value
                            Next
                        End With
                    Else
                        'Insert to CRM DB Failed
                    End If
                End With
            Next

            'Displaying New Data in forontend
            dgvCallableData.DataSource = dtCallable.Copy
            'End

            'Exporting New Data to CSV and Fixed Width file
            Dim tmp1 As String() = txtSource.Text.Split("\")
            Dim destFile As String
            'destFile = tmp1.GetValue(tmp1.Length - 1).ToString.Split(".")(0) + DateTime.Now.ToString("HHmmss") + ".csv"
            'DataTableToCSV(DateTime.Now.ToString("ddMMyyyy"), destFile, dtCallable.Copy)
            destFile = tmp1.GetValue(tmp1.Length - 1).ToString.Split(".")(0) + "_" + DateTime.Now.ToString("HHmmss") + ".raw"
            DataTableToFixWidth(DateTime.Now.ToString("ddMMyyyy"), destFile, dtCallable.Copy)
            'End
        Catch ex As Exception
            MessageBox.Show(ex.Message, "btnCreateDialerUpload_Click : ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            MessageBox.Show("Process Complete", "BasicCRM", MessageBoxButtons.OK, MessageBoxIcon.Information)
            btnCreateDialerUpload.Enabled = True
        End Try
    End Sub

    Private Function ExcelToDataTable(SrcFile As String) As DataTable
        Dim dt As New DataTable

        Try
            Dim oledbConn As OleDbConnection = New OleDbConnection(My.Settings.ExcelConStr.Replace("~src~", SrcFile))
            oledbConn.Open()
            Dim cmd As OleDbCommand = New OleDbCommand("SELECT * FROM [Sheet1$]", oledbConn)
            Dim oleda As OleDbDataAdapter = New OleDbDataAdapter()
            oleda.SelectCommand = cmd
            oleda.Fill(dt)

            Return dt
        Catch ex As Exception
            MessageBox.Show(ex.Message, "ExcelToDataTable : ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

    Private Function CSVToDataTable(SrcFile As String) As DataTable
        Dim dt As New DataTable
        Dim dr As DataRow

        Try
            Dim sr As StreamReader = IO.File.OpenText(SrcFile)
            Dim data As String = sr.ReadToEnd()
            Dim dataArr() As String = data.Split(Environment.NewLine)
            For i As Integer = 0 To dataArr.GetUpperBound(0) - 1
                If i = 0 Then
                    For j = 0 To dataArr(i).Split(My.Settings.CSVSep).Length - 1
                        'dt.Columns.Add(dataArr(i).Split(",")(0))
                        'dt.Columns.Add(dataArr(i).Split(",")(1))
                        dt.Columns.Add(dataArr(i).Split(My.Settings.CSVSep)(j))
                    Next
                Else
                    dr = dt.NewRow
                    For j = 0 To dataArr(i).Split(My.Settings.CSVSep).Length - 1
                        'dr(0) = dataArr(i).Split(",")(0)
                        'dr(1) = dataArr(i).Split(",")(1)
                        dr(j) = dataArr(i).Split(My.Settings.CSVSep)(j)
                    Next
                    dt.Rows.Add(dr)
                End If
            Next

            Return dt
        Catch ex As Exception
            MessageBox.Show(ex.Message, "CSVToDataTable : ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

    Private Function DataTableToCSV(Category As String, FileName As String, dt As DataTable) As Integer
        Try
            Dim destFile As String = txtDestination.Text & "\" & Category
            If IO.Directory.Exists(destFile) = False Then
                IO.Directory.CreateDirectory(destFile)
            End If

            destFile += "\" & FileName
            If IO.File.Exists(destFile) = False Then
                Dim fs As FileStream = IO.File.Create(destFile)
                fs.Close()
                fs.Dispose()
            End If

            Dim filecontent As String = ""
            For i As Integer = 0 To dt.Columns.Count - 1
                filecontent += dt.Columns(i).ColumnName
                If i < dt.Columns.Count - 1 Then
                    filecontent += ","
                End If
            Next
            'filecontent += ",NAME"
            filecontent += Environment.NewLine

            For j As Integer = 0 To dt.Rows.Count - 1
                For k As Integer = 0 To dt.Columns.Count - 1
                    filecontent += dt.Rows(j).Item(k)
                    If k < dt.Columns.Count - 1 Then
                        filecontent += ","
                    End If
                Next
                'filecontent += "," + dt.Rows(j).Item(dt.Columns.Count - 1)
                filecontent += Environment.NewLine
            Next

            Dim sw As IO.StreamWriter = IO.File.AppendText(destFile)
            sw.Write(filecontent)
            sw.Close()
            sw.Dispose()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "DataTableToCSV : ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

    Private Function getColumnWidth(colName As String) As Integer
        Try
            Select Case colName
                Case "SrNo"
                    Return 18
                Case "EMAIL"
                    Return 100
                Case "INVESTOR_FIRST_NAME", "GUARDIAN_Name"
                    Return 75
                Case "BANK_NAME", "BRANCH_NAME", "STATE_NAME", "CITY_NAME", "SCHEME_NAME", "CALL_REMARKS"
                    Return 50
                Case "TAX_STATUS", "AC_NO", "SIP_Amount", "SIP_DAY"
                    Return 25
                Case "BrokerCode", "FOLIO_NO", "AC_TYPE", "IFSC_CODE", "UploadDate"
                    Return 20
                Case "PAN_NO", "Mobile_Number", "PHONE_RES"
                    Return 15
                Case "AMOUNT", "PINCODE"
                    Return 10
                Case Else
                    Return 0
            End Select
        Catch ex As Exception
            MessageBox.Show(ex.Message, "getColumnWidth : ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        colName = colName.ToUpper()
    End Function

    Private Function DataTableToFixWidth(Category As String, FileName As String, dt As DataTable) As Integer
        Try
            Dim destFile As String = txtDestination.Text & "\" & Category
            If IO.Directory.Exists(destFile) = False Then
                IO.Directory.CreateDirectory(destFile)
            End If

            destFile += "\" & FileName
            If IO.File.Exists(destFile) = False Then
                Dim fs As FileStream = IO.File.Create(destFile)
                fs.Close()
                fs.Dispose()
            End If

            Dim filecontent As String = ""

            'For i As Integer = 0 To dt.Columns.Count - 1
            '    filecontent += dt.Columns(i).ColumnName
            '    filecontent += Space(getColumnWidth(dt.Columns(i).ColumnName) - dt.Columns(i).ColumnName.Length)
            '    'If i < dt.Columns.Count - 1 Then
            '    '    filecontent += ","
            '    'End If
            'Next
            'filecontent += Environment.NewLine

            For j As Integer = 0 To dt.Rows.Count - 1
                For k As Integer = 0 To dt.Columns.Count - 1
                    filecontent += dt.Rows(j).Item(k).ToString.Replace(vbLf, "")
                    filecontent += Space(getColumnWidth(dt.Columns(k).ColumnName) - dt.Rows(j).Item(k).ToString.Replace(vbLf, "").Length)
                    'If k < dt.Columns.Count - 1 Then
                    '    filecontent += ","
                    'End If
                Next
                filecontent += Environment.NewLine
            Next

            Dim sw As IO.StreamWriter = IO.File.AppendText(destFile)
            sw.Write(filecontent)
            sw.Close()
            sw.Dispose()

            Return 0
        Catch ex As Exception
            MessageBox.Show(ex.Message, "DataTableToFixWidth : ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

    Private Function CheckDNC(PhoneNo As String) As Integer
        Try
            Dim sqlConn As SqlConnection
            If (PhoneNo.Length > 10) Then
                PhoneNo = PhoneNo.Substring(PhoneNo.Length - 10, 10)
            End If
            Dim dt As New DataTable

            Try
                sqlConn = New SqlConnection(My.Settings.ConStr)
                sqlConn.Open()
                Dim cmd As SqlCommand = New SqlCommand("SELECT * FROM [NDNC_DB].[dbo].[NDNC_DATA] where Phone_Numbers = '" + PhoneNo + "'", sqlConn)
                Dim sqlda As SqlDataAdapter = New SqlDataAdapter()
                sqlda.SelectCommand = cmd
                sqlda.Fill(dt)

                Return dt.Rows.Count
            Catch ex As Exception
                Throw ex
            Finally
                sqlConn.Close()
                sqlConn.Dispose()
            End Try
        Catch ex As Exception
            MessageBox.Show(ex.Message, "CheckDNC : ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Function

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Application.ExitThread()
    End Sub

    Private Function PadDateCrLf(val As String) As String
        Try
            Return DateTime.Now.ToString("dd-MMM-yyyy HH:mm:ss.ms : ") + val + Environment.NewLine
        Catch ex As Exception
            Throw
        End Try
    End Function

    Private Function AcceptAllCertifications(sender As Object, certification As X509Certificate, chain As X509Chain, sslPolicyErrors As SslPolicyErrors) As Boolean
        Return True
    End Function

    Public Function sendSOAPMessage(soapURL As String, soapMsg As String, soapAction As String) As String
        Try
            'logger.WriteLog4Net("data received for sending (Request) - action : " + soapAction + " & Soap Message : " + soapMsg, null);
            ServicePointManager.ServerCertificateValidationCallback = New System.Net.Security.RemoteCertificateValidationCallback(AddressOf AcceptAllCertifications)
            Dim request As HttpWebRequest = WebRequest.Create(soapURL)

            If My.Settings.UseProxy = "T" Then
                Dim proxy As IWebProxy = New WebProxy(My.Settings.ProxyHost, Integer.Parse(My.Settings.ProxyPort))
                proxy.Credentials = New NetworkCredential(My.Settings.ProxyUser, My.Settings.ProxyPwd)
                request.Proxy = proxy
            Else
                request.UseDefaultCredentials = True
            End If

            request.Method = "POST"
            request.ContentType = "text/xml; charset=UTF-8"
            request.Headers.Add("SOAPAction", soapAction)
            'request.UseDefaultCredentials = false
            'request.Credentials = New NetworkCredential(ConfigurationManager.AppSettings["ProxyUser"].ToString(), ConfigurationManager.AppSettings["ProxyPwd"].ToString());
            request.Credentials = CredentialCache.DefaultCredentials
            Dim soapEnvelopeXml As XmlDocument = New XmlDocument
            soapEnvelopeXml.LoadXml(soapMsg)
            Using stream As Stream = request.GetRequestStream()
                soapEnvelopeXml.Save(stream)
            End Using
            'logger.WriteLog4Net("data send for (Request)- action : " + soapAction + " & Soap Message : " + soapMsg, null);
            request.Timeout = 100000
            Using response As WebResponse = request.GetResponse()
                Using rd As StreamReader = New StreamReader(response.GetResponseStream())
                    Dim soapResult As String = rd.ReadToEnd()
                    Console.WriteLine(soapResult)
                    'logger.WriteLog4Net("data received from POM for (Response) : " + soapResult, null);
                    Return soapResult
                End Using
            End Using
        Catch e As System.Net.WebException
            Dim pageContent As String = New StreamReader(e.Response.GetResponseStream()).ReadToEnd()
            'Console.WriteLine(pageContent);
            'logger.WriteLog4Net("WebException : ", e);
            Return pageContent
        Catch ex As Exception
            'logger.WriteLog4Net("Exception : ", ex)
            Throw
        End Try
    End Function

    Public Function postData(postURL As String, postMsg As String) As String
        Try
            Dim request As HttpWebRequest = WebRequest.Create(postURL)

            If My.Settings.UseProxy = "T" Then
                Dim proxy As IWebProxy = New WebProxy(My.Settings.ProxyHost, Integer.Parse(My.Settings.ProxyPort))
                proxy.Credentials = New NetworkCredential(My.Settings.ProxyUser, My.Settings.ProxyPwd)
                request.Proxy = proxy
            End If

            Dim data As Byte() = Encoding.ASCII.GetBytes(postMsg)

            request.Method = "POST"
            request.ContentType = "application/x-www-form-urlencoded"
            request.ContentLength = data.Length

            Using stream As Stream = request.GetRequestStream()
                stream.Write(data, 0, data.Length)
            End Using

            Dim response As HttpWebResponse = request.GetResponse()
            Dim responseString As String = New StreamReader(response.GetResponseStream()).ReadToEnd()

            Return responseString
        Catch ex As Exception
            Throw
        End Try
    End Function

    Private Function ExecuteDataSet(conSql As String, strSql As String) As DataSet
        Dim ds As DataSet = New DataSet()

        Try
            Dim sqlConn As SqlConnection = New SqlConnection(conSql)
            sqlConn.Open()
            Dim cmd As SqlCommand = New SqlCommand(strSql, sqlConn)
            Dim sqlda As SqlDataAdapter = New SqlDataAdapter()
            sqlda.SelectCommand = cmd
            sqlda.Fill(ds)

            Return ds
        Catch ex As Exception
            Throw
        End Try
    End Function

    Private Function ExecuteNonQuery(conSql As String, strSql As String) As Integer
        Try
            Dim sqlConn As SqlConnection = New SqlConnection(conSql)
            sqlConn.Open()
            Dim cmd As SqlCommand = New SqlCommand(strSql, sqlConn)
            Return cmd.ExecuteNonQuery()
        Catch ex As Exception
            Throw
        End Try
    End Function

    Private Function GetIdentity(conSql As String, strSql As String) As getIdentityResp
        Dim ret As New getIdentityResp
        Dim ds As DataSet = New DataSet()
        Try
            Dim sqlConn As SqlConnection = New SqlConnection(conSql)
            sqlConn.Open()
            Dim cmd As SqlCommand = New SqlCommand(strSql, sqlConn)
            Dim cnt As Integer = cmd.ExecuteNonQuery()
            If cnt > 0 Then
                Dim qry As String = "select @@identity"
                Dim cmd2 As SqlCommand = New SqlCommand(qry, sqlConn)
                Dim sqlda As SqlDataAdapter = New SqlDataAdapter()
                sqlda.SelectCommand = cmd2
                sqlda.Fill(ds)
                If ds.Tables(0).Rows.Count > 0 Then
                    ret.Status = 1
                    ret.IdentityVal = ds.Tables(0).Rows(0).Item(0)
                Else
                    ret.Status = 0
                End If
            Else
                ret.Status = 0
                ret.ErrorDesc = "Insert Failed."
            End If

            Return ret
        Catch ex As Exception
            MessageBox.Show(ex.Message, "GetIdentity : ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

    Private Sub WriteLog(FileName As String, value As String)
        Try
            If (value.Trim() <> "") Then
                If My.Settings.EnableLogging = "T" Then
                    FileName = FileName + ".log"
                    Dim FilePath As String = Application.StartupPath + "\Logs" 'My.Settings.LoggingPath
                    If System.IO.Directory.Exists(FilePath) = False Then
                        System.IO.Directory.CreateDirectory(FilePath)
                    End If
                    FilePath += "\\" + System.DateTime.Now.ToString("ddMMyyyy")
                    If System.IO.Directory.Exists(FilePath) = False Then
                        System.IO.Directory.CreateDirectory(FilePath)
                    End If
                    FileName = FilePath + "\\" + FileName
                    Dim writer As System.IO.StreamWriter = New System.IO.StreamWriter(FileName, True)
                    writer.Write(value)
                    writer.Flush()
                    writer.Close()
                End If
            End If
        Catch ex As Exception
            'Nothing to do.
        End Try
    End Sub
End Class

Class getIdentityResp
    Property Status As Integer
    Property ErrorDesc As String
    Property IdentityVal As String
End Class
