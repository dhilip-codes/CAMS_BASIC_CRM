﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmNDNCDataScrubbing
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblSelectSource = New System.Windows.Forms.Label()
        Me.txtSource = New System.Windows.Forms.TextBox()
        Me.btnSelectSource = New System.Windows.Forms.Button()
        Me.dgvSourceData = New System.Windows.Forms.DataGridView()
        Me.btnCreateDialerUpload = New System.Windows.Forms.Button()
        Me.lblCallableDataHeader = New System.Windows.Forms.Label()
        Me.dgvCallableData = New System.Windows.Forms.DataGridView()
        Me.lblDestination = New System.Windows.Forms.Label()
        Me.txtDestination = New System.Windows.Forms.TextBox()
        Me.ofdSource = New System.Windows.Forms.OpenFileDialog()
        Me.lblCallableCnt = New System.Windows.Forms.Label()
        Me.btnClose = New System.Windows.Forms.Button()
        CType(Me.dgvSourceData, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvCallableData, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblSelectSource
        '
        Me.lblSelectSource.AutoSize = True
        Me.lblSelectSource.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSelectSource.Location = New System.Drawing.Point(2, 10)
        Me.lblSelectSource.Name = "lblSelectSource"
        Me.lblSelectSource.Size = New System.Drawing.Size(89, 15)
        Me.lblSelectSource.TabIndex = 0
        Me.lblSelectSource.Text = "Select Source :"
        '
        'txtSource
        '
        Me.txtSource.Location = New System.Drawing.Point(114, 7)
        Me.txtSource.Name = "txtSource"
        Me.txtSource.ReadOnly = True
        Me.txtSource.Size = New System.Drawing.Size(611, 21)
        Me.txtSource.TabIndex = 1
        '
        'btnSelectSource
        '
        Me.btnSelectSource.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSelectSource.Location = New System.Drawing.Point(743, 4)
        Me.btnSelectSource.Name = "btnSelectSource"
        Me.btnSelectSource.Size = New System.Drawing.Size(48, 27)
        Me.btnSelectSource.TabIndex = 2
        Me.btnSelectSource.Text = "..."
        Me.btnSelectSource.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnSelectSource.UseVisualStyleBackColor = True
        '
        'dgvSourceData
        '
        Me.dgvSourceData.AllowUserToAddRows = False
        Me.dgvSourceData.AllowUserToDeleteRows = False
        Me.dgvSourceData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvSourceData.Location = New System.Drawing.Point(6, 38)
        Me.dgvSourceData.Name = "dgvSourceData"
        Me.dgvSourceData.ReadOnly = True
        Me.dgvSourceData.Size = New System.Drawing.Size(785, 187)
        Me.dgvSourceData.TabIndex = 3
        Me.dgvSourceData.TabStop = False
        '
        'btnCreateDialerUpload
        '
        Me.btnCreateDialerUpload.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCreateDialerUpload.Location = New System.Drawing.Point(318, 232)
        Me.btnCreateDialerUpload.Name = "btnCreateDialerUpload"
        Me.btnCreateDialerUpload.Size = New System.Drawing.Size(157, 27)
        Me.btnCreateDialerUpload.TabIndex = 4
        Me.btnCreateDialerUpload.Text = "Create Dialer &Upload"
        Me.btnCreateDialerUpload.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnCreateDialerUpload.UseVisualStyleBackColor = True
        '
        'lblCallableDataHeader
        '
        Me.lblCallableDataHeader.BackColor = System.Drawing.Color.White
        Me.lblCallableDataHeader.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCallableDataHeader.ForeColor = System.Drawing.Color.Red
        Me.lblCallableDataHeader.Location = New System.Drawing.Point(6, 266)
        Me.lblCallableDataHeader.Name = "lblCallableDataHeader"
        Me.lblCallableDataHeader.Size = New System.Drawing.Size(785, 15)
        Me.lblCallableDataHeader.TabIndex = 5
        Me.lblCallableDataHeader.Text = "Preview of Dialer Upload Data"
        Me.lblCallableDataHeader.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'dgvCallableData
        '
        Me.dgvCallableData.AllowUserToAddRows = False
        Me.dgvCallableData.AllowUserToDeleteRows = False
        Me.dgvCallableData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvCallableData.Location = New System.Drawing.Point(6, 288)
        Me.dgvCallableData.Name = "dgvCallableData"
        Me.dgvCallableData.ReadOnly = True
        Me.dgvCallableData.Size = New System.Drawing.Size(785, 187)
        Me.dgvCallableData.TabIndex = 7
        Me.dgvCallableData.TabStop = False
        '
        'lblDestination
        '
        Me.lblDestination.AutoSize = True
        Me.lblDestination.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDestination.Location = New System.Drawing.Point(6, 485)
        Me.lblDestination.Name = "lblDestination"
        Me.lblDestination.Size = New System.Drawing.Size(76, 15)
        Me.lblDestination.TabIndex = 9
        Me.lblDestination.Text = "Destination :"
        '
        'txtDestination
        '
        Me.txtDestination.Location = New System.Drawing.Point(93, 482)
        Me.txtDestination.Name = "txtDestination"
        Me.txtDestination.ReadOnly = True
        Me.txtDestination.Size = New System.Drawing.Size(698, 21)
        Me.txtDestination.TabIndex = 10
        '
        'lblCallableCnt
        '
        Me.lblCallableCnt.BackColor = System.Drawing.Color.White
        Me.lblCallableCnt.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCallableCnt.ForeColor = System.Drawing.Color.Blue
        Me.lblCallableCnt.Location = New System.Drawing.Point(730, 266)
        Me.lblCallableCnt.Name = "lblCallableCnt"
        Me.lblCallableCnt.Size = New System.Drawing.Size(61, 15)
        Me.lblCallableCnt.TabIndex = 12
        Me.lblCallableCnt.Text = "0"
        Me.lblCallableCnt.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnClose
        '
        Me.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnClose.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(706, 510)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(85, 27)
        Me.btnClose.TabIndex = 13
        Me.btnClose.Text = "&Close"
        Me.btnClose.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'frmNDNCDataScrubbing
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnClose
        Me.ClientSize = New System.Drawing.Size(797, 546)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.lblCallableCnt)
        Me.Controls.Add(Me.txtDestination)
        Me.Controls.Add(Me.lblDestination)
        Me.Controls.Add(Me.dgvCallableData)
        Me.Controls.Add(Me.lblCallableDataHeader)
        Me.Controls.Add(Me.btnCreateDialerUpload)
        Me.Controls.Add(Me.dgvSourceData)
        Me.Controls.Add(Me.btnSelectSource)
        Me.Controls.Add(Me.txtSource)
        Me.Controls.Add(Me.lblSelectSource)
        Me.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "frmNDNCDataScrubbing"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Basic CRM -  Data Massageing Tool"
        CType(Me.dgvSourceData, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvCallableData, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblSelectSource As System.Windows.Forms.Label
    Friend WithEvents txtSource As System.Windows.Forms.TextBox
    Friend WithEvents btnSelectSource As System.Windows.Forms.Button
    Friend WithEvents dgvSourceData As System.Windows.Forms.DataGridView
    Friend WithEvents btnCreateDialerUpload As System.Windows.Forms.Button
    Friend WithEvents lblCallableDataHeader As System.Windows.Forms.Label
    Friend WithEvents dgvCallableData As System.Windows.Forms.DataGridView
    Friend WithEvents lblDestination As System.Windows.Forms.Label
    Friend WithEvents txtDestination As System.Windows.Forms.TextBox
    Friend WithEvents ofdSource As System.Windows.Forms.OpenFileDialog
    Friend WithEvents lblCallableCnt As System.Windows.Forms.Label
    Friend WithEvents btnClose As Button
End Class
